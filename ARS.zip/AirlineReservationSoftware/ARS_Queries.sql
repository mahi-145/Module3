CREATE TABLE Users(
UserName VARCHAR2(40),
Password VARCHAR2(20) NOT NULL,
email varchar2(100),
MobileNo Varchar2(10),
Role VARCHAR2(10));

drop table Users;

SELECT * FROM USERS;

CREATE TABLE Airport(
AirportName VARCHAR2(60),
Abbrevation VARCHAR2(5),
Location VARCHAR2(40));

drop table location;

insert into airport values('Rajiv Gandhi Terminus','BMY','Mumbai');


CREATE TABLE location(
location VARCHAR(40), 
state varchar2(40),
zipCode varchar2(8));

drop table flightinformation;

CREATE TABLE FlightInformation(
FlightNo VARCHAR2(5) CONSTRAINT flight_pk PRIMARY KEY,
AirLine VARCHAR2(20),
Source VARCHAR2(20),
Destination VARCHAR2(15),
DepartureDate DATE,
ArrivalDate DATE,
DepartureTime VARCHAR2(15),
ArrivalTime VARCHAR2(15),
EconomySeats NUMBER,
EconomySeatsFare NUMBER(10,5),
BusinessSeats NUMBER,
BusinessSeatsFare NUMBER(10,5),
FIRSTAVAIL NUMBER,
BSEATSAVAIL NUMBER);

ALTER TABLE FLIGHTINFORMATION ADD CONSTRAINT PK_FLIGHTNO PRIMARY KEY(FLIGHTNO);

ALTER TABLE FLIGHTINFORMATION MODIFY(BusinessSeatsFare NUMBER(10,5));
ALTER TABLE FLIGHTINFORMATION MODIFY(Destination VARCHAR2(15));
ALTER TABLE FLIGHTINFORMATION MODIFY(DepartureTime VARCHAR2(15));
ALTER TABLE FLIGHTINFORMATION MODIFY(ArrivalTime VARCHAR2(15));
ALTER TABLE FLIGHTINFORMATION MODIFY(Airline VARCHAR2(20));

ALTER TABLE FLIGHTINFORMATION ADD FIRSTAVAIL NUMBER;
ALTER TABLE FLIGHTINFORMATION ADD BSEATSAVAIL NUMBER;

TRUNCATE TABLE FLIGHTINFORMATION;
SELECT * FROM FLIGHTINFORMATION;

INSERT INTO FLIGHTINFORMATION VALUES('F1J01','Jet Airways','MUMBAI','BANGALORE',to_date('2017-02-15','yyyy-MM-dd'),to_date('2017-02-17','yyyy-MM-dd'),'9','7',5,10,20,23);

SELECT SYSDATE FROM DUAL;


CREATE TABLE BookingInformation(
BookingId VARCHAR2(5),
custName VARCHAR2(90),
CustEmail VARCHAR2(90),
NoOfPassengers NUMBER,
ClassType VARCHAR2(10),
TotalFare NUMBER(10,5),
SeatNumber VARCHAR2(90),
creditCardInfo varchar2(16),
SrcCity VARCHAR2(30),
DestCity VARCHAR2(30),
FlightNo VARCHAR2(5) CONSTRAINT FK_FLIGHTNO REFERENCES FlightInformation(FlightNo) on delete set null);

ALTER TABLE BookingInformation MODIFY(TotalFare NUMBER(10,5));
ALTER TABLE BookingInformation MODIFY(SeatNumber VARCHAR2(50));
truncate table BookingInformation;

INSERT INTO BookingInformation VALUES('JT101','hari11@ymail.com',5,'business',250,3,'reddy','MUMBAI','BANGALORE','F1J01');

drop table BookingInformation;
drop table FLIGHTINFORMATION;

select * from BOOKINGINFORMATION;

SELECT custEmail,noOfPassengers,classType,totalFare,seatNumber,creditCardInfo,srcCity,destCity FROM BookingInformation where bookingId='JT101';


select * from airport;
SELECT * FROM FLIGHTINFORMATION;

INSERT INTO location(location,state,zipCode) VALUES ('Mumbai', 'Maharastra', '400501');
SELECT STATE,ZIPCODE,AIRPORTNAME 
FROM AIRPORT
JOIN LOCATION USING(LOCATION);

select * from location;

CREATE SEQUENCE BookingInformation_bookingId
START WITH 100
INCREMENT BY 1
NOCYCLE;

DROP SEQUENCE BookingInformation_bookingId;

INSERT INTO BookingInformation VALUES('BK101','harsha@ymail.com',5,'business',12000.0,'7,8,9,10','reddy','MUMBAI','BANGALORE','FJ665');
