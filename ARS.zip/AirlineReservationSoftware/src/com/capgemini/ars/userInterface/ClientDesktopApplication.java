package com.capgemini.ars.userInterface;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.ars.entities.Airport;
import com.capgemini.ars.entities.BookingInformation;
import com.capgemini.ars.entities.Flight;
import com.capgemini.ars.entities.Location;
import com.capgemini.ars.entities.Users;
import com.capgemini.ars.exceptions.AirportException;
import com.capgemini.ars.exceptions.BookingInformationException;
import com.capgemini.ars.exceptions.FlightException;
import com.capgemini.ars.exceptions.UserException;
import com.capgemini.ars.services.AirlineServices;
import com.capgemini.ars.services.AirlineServicesImpl;
import com.capgemini.ars.validations.EntryFormValidations;

public class ClientDesktopApplication {
	private static Logger myLogger =  Logger.getLogger("Airline Reservation Software");
	public static void main(String[] args) throws UserException, FlightException{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		EntryFormValidations valid =new EntryFormValidations();
		PropertyConfigurator.configure("config/log4j.properties");
		try {
			AirlineServices service=new AirlineServicesImpl();
		exit:
		while(true){
			System.out.println("*****Welcome To Airline Reservation System*****");
			System.out.println("1.Login");
			System.out.println("2.New User? Register Now.");
			System.out.println("3.Exit");
			System.out.println("Enter your Choice: ");
			int choice=Integer.parseInt(br.readLine());
			if(choice<1 || choice>3){
				System.out.println("Choice out of range. Try again.");
				continue;
			}
			
			switch(choice)
			{
			case 1: System.out.println("************Login*************");
				while(true)
					{
						System.out.println("**Login as User/Admin/Executive***");
						System.out.println("Enter User Name:");
						String uname = br.readLine();
						System.out.println("Enter Password:");
						String password = br.readLine();
						boolean isExists = service.getParticularUser(uname, password);
						String category;
						if(isExists){
							category = service.getUserCategory(uname);
							if(category.equals("Admin")) adminModule(uname);
							else if(category.equals("User")) userModule(uname);
							else if(category.equals("Executive")) executiveModule(uname);
						}
						else {
							myLogger.info("Login failed due to incorrect username/password");
							System.out.println("Username/password are incorrect please try again...");
						}
						break;						
					}
				    break;
				    
			case 2:out:
				while(true){
						System.out.println("----------Register as User / Admin/ Executive----------");
						System.out.println("Select one of the Below Categoies : ");
						System.out.println("1. Adminstrator");
						System.out.println("2. Executive");
						System.out.println("3. User/Customer");
						System.out.println("4. Back");
						System.out.println("Enter your choice:");
						int catchoice = Integer.parseInt(br.readLine());
						if(choice<1 || choice>4){
							System.out.println("Choice out of range. Try again.");
							continue;
						}
						switch(catchoice){
						case 1: System.out.println("Enter the CSK before you register for admin");
								String csk = br.readLine();
								if(csk.equals("capgemini")){
									String auname;
									while(true){
										System.out.println("Enter User Name :");
										auname = br.readLine();
										 boolean isUserNameValid = valid.isUnameValid(auname);
										 if(isUserNameValid==true)
										    	break;
									}
									System.out.println("Enter Password:");
									String apwrd = br.readLine();
									String aemail;
									while(true){
										System.out.println("Enter Email ID :");
										aemail = br.readLine();
										  boolean isEmailValid = valid.isEmailIdValid(aemail);
										  if(isEmailValid==true)
										    	break;
									}
									String amobile;
									while(true){
										System.out.println("Enter Mobile Number:");
										amobile = br.readLine();
										 boolean isMobileValid = valid.isMobileValid(amobile);
										 if(isMobileValid==true)
										    	break;
									}
									Users userObj = new Users(auname,apwrd,aemail,amobile,"Admin");
									@SuppressWarnings("unused")
									int uid = service.addUser(userObj);
									System.out.println("Congrats ! you are successfully Registered as Admin...");
									myLogger.info("Admin regsitered  Successfull");
								}
								break;
						case 2:	System.out.println("Enter the CSK before you register for Executive");
								String ecsk = br.readLine();
								if(ecsk.equals("capgeminiexecutive")){
									String auname;
									while(true){
										System.out.println("Enter User Name :");
										auname = br.readLine();
										boolean isUserNameValid = valid.isUnameValid(auname);
										if(isUserNameValid==true)
										    	break;

									}
									System.out.println("Enter Password:");
									String apwrd = br.readLine();
									String aemail;
									while(true){
										System.out.println("Enter Email ID :");
										aemail = br.readLine();
										boolean isEmailValid = valid.isEmailIdValid(aemail);
										if(isEmailValid==true)
										    	break;
									}
									String amobile;
									while(true){
										System.out.println("Enter Mobile Number:");
										amobile = br.readLine();
										boolean isMobileValid = valid.isMobileValid(amobile);
										 if(isMobileValid==true)
										    	break;
									}
									Users userObj = new Users(auname,apwrd,aemail,amobile,"Executive");
									@SuppressWarnings("unused")
									int uid = service.addUser(userObj);
									System.out.println("Congrats ! you are successfully Registered as Executive ...");
									myLogger.info("Executive regsitered  Successfull");
								}
								break;
						case 3:	String auname;
								while(true){
									System.out.println("Enter User Name :");
									auname = br.readLine();
									boolean isUserNameValid = valid.isUnameValid(auname);
									if(isUserNameValid==true)
									    	break;
								}
								System.out.println("Enter Password:");
								String apwrd = br.readLine();
								String aemail;
								while(true){
									System.out.println("Enter Email ID :");
									aemail = br.readLine();
									boolean isEmailValid = valid.isEmailIdValid(aemail);
									if(isEmailValid==true)
									    	break;
								}
								String amobile;
								while(true){
									System.out.println("Enter Mobile Number:");
									amobile = br.readLine();
									boolean isMobileValid = valid.isMobileValid(amobile);
									 if(isMobileValid==true)
									    	break;
								}
								Users userObj = new Users(auname,apwrd,aemail,amobile,"User");
								@SuppressWarnings("unused")
								int uid = service.addUser(userObj);	
								System.out.println("Congrats ! you are successfully Registered as Member...");
								myLogger.info("Customer regsitered  Successfull");
								break;
						case 4: break out;
						}
					}
			case 6:continue;
			case 3: System.out.println("Exit");
					break exit;
			}
		}
		System.out.println("Thanks for using our software.");
		} catch (Exception e) {
			throw new FlightException("Unable to open Login Page");
		} 
	}
	
	public static void adminModule(String uname) throws NumberFormatException, IOException, FlightException, AirportException, BookingInformationException{
		System.out.println("Adiminstration Department");
		myLogger.info("Admin Login Successfull");
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		AirlineServices service=new AirlineServicesImpl();
		while(true){
			System.out.println("------------Administration Module------------");
			System.out.println("1. Create Locations");
			System.out.println("2. Create Airports");
			System.out.println("3. Create Flights");
			System.out.println("4. Schedule a Flight / Update Timings of Flight");
			System.out.println("5. Delete Flight");
			System.out.println("+++++++++++++Generate Consolidated reports+++++++++");
			System.out.println("6. Generate report of passengers for a particular flight");
			System.out.println("7. Generate List of Flights Report");
			System.out.println("8. Logout");
			System.out.println("Enter your choice : ");
			int ch = Integer.parseInt(br.readLine());
			if(ch<1 || ch>8){
				System.out.println("Choice out of range. Try again.");
				continue;
			}
			switch(ch){
				case 1: System.out.println("_________Locations___________");
				 		System.out.println("Enter city :");
				 		String city = br.readLine();
				 		System.out.println("Enter State in which"+city+"is located :");
				 		String state = br.readLine();
				 		System.out.println("Enter postal Zipcode:");
				 		String zip = br.readLine();
				 		Location l = new Location(city,state,zip);
				 		service.addLocations(l);
				 		System.out.println("Location added Successfully");
				 		myLogger.info("location addedd  Successfull");
				 		break;
				case 2: System.out.println("***********Airports************");
				 		System.out.println("Enter Airport Name :");
				 		String name = br.readLine();
				 		System.out.println("Enter Abbrevation Code for Airport"+name+":");
				 		String abb = br.readLine();
				 		System.out.println("Enter City in which "+name+" located in:");
				 		String c =br.readLine();
				 		Airport ar = new Airport(name,abb,c);
				 		service.addAirportDetails(ar);
				 		System.out.println("Airport created successfully");
				 		myLogger.info("Airport created  Successfull");
				 		break;
				case 3: System.out.println("************Flights************");
						System.out.println("Enter Airways Name:");
						String airways = br.readLine();
						System.out.println("Enter Flight Number:");
						String fno = br.readLine();
						System.out.println("Enter Cirt of departure: ");
						String dep = br.readLine();
						System.out.println("Enter Destination City: ");
						String dest = br.readLine();
						System.out.println("Enter Date of Journey (dd/mm/yyyy):");
						String deptdate = br.readLine();
						DateTimeFormatter dtf =  DateTimeFormatter.ofPattern("dd/MM/yyyy");
						LocalDate Departuredate = LocalDate.parse(deptdate, dtf);
						System.out.println("Enter Date of Arrival:");
						String arrdate = br.readLine();
						LocalDate Arrivaldate = LocalDate.parse(arrdate, dtf);
						System.out.println("Enter depart time (in 24 hr format): ");
						String deptime = br.readLine();
						System.out.println("Enter Arrival Estimated time (in 24 hr format): ");
						String arrtime = br.readLine();
						System.out.println("Enter the number of Economy class Seats :");
						int firstSeats = Integer.parseInt(br.readLine());
						int firstAvail = firstSeats;
						System.out.println("Enter the Economy class seat fare per seat: ");
						float firstSeatsfare = Float.parseFloat(br.readLine());
						System.out.println("Enter the number of Business Class Seats :");
						int bSeats = Integer.parseInt(br.readLine());
						int bSeatsAvail = bSeats;
						System.out.println("Enter the Business class seat fare per seat: ");
						float bSeatsfare = Float.parseFloat(br.readLine());
						Flight aft = new Flight(fno,airways,dep,dest,Date.valueOf(Departuredate),Date.valueOf(Arrivaldate),deptime,arrtime,firstSeats,firstSeatsfare,bSeats,bSeatsfare,firstAvail,bSeatsAvail);
						service.addNewFlight(aft);
						System.out.println("Flight inserted successfully");
						myLogger.info("Flight Inserted Successfull");
						break;
				case 4: System.out.println("------------------Update Flight Schedule---------------");
						System.out.println("Enter the flight number: ");
						String upfno = br.readLine();
				 		System.out.println("Enter date of Journey:");
				 		String updatedJourney = br.readLine();
				 		DateTimeFormatter dtf1 =  DateTimeFormatter.ofPattern("dd/MM/yyyy");
						LocalDate journeyDate = LocalDate.parse(updatedJourney, dtf1);
						System.out.println("Enter Time of departure :");
						String journeyTime = br.readLine();
						System.out.println("Enter date of arrival :");
						String updatedArrivalDate = br.readLine();
						LocalDate arrivalDate = LocalDate.parse(updatedArrivalDate, dtf1);
						System.out.println("Enter Time of Arrival :");
						String arrivalTime = br.readLine();
					    service.updateFlightScheduleArrivalDate(upfno, Date.valueOf(arrivalDate));
					    service.updateFlightScheduleDepartureDate(upfno,Date.valueOf(journeyDate));
					    service.updateFlightScheduleArrTime(upfno, arrivalTime);
					    service.updateFlightScheduleDepartureTime(upfno, journeyTime);
					    System.out.println("Flight Schedule updated succesfully");
					    myLogger.info("Flight Schedule Updated Successfull");
					    break;
				case 5: System.out.println("-------Delete a Flight Record---------");
				 		System.out.println("Enter the Flight No to Remove:");
				 		String dfno = br.readLine();
				 		if(service.deleteFlight(dfno)){
				 			System.out.println(dfno+" is removed successfully");
				 			myLogger.info("Flight Removed Successfully");
				 		}
				 		else{
				 			System.out.println("Sorry ! please try with a valid flight no");
				 			myLogger.info("Flight deletion failed");
				 		}
				 		break;
				case 6: System.out.println("~~~~~~~~~~~~~Passengers Report~~~~~~~~~~~~~~");
						System.out.println("Enter a Flight Number :");
						String rfno = br.readLine();
						ArrayList<BookingInformation> bList=service.getAllBookingInformation(rfno);
						bList.forEach(b->System.out.println(b));
						myLogger.info("Passenger report generated successfully");
						break;
				case 7: System.out.println("~~~~~~~~~~~~~Flights Report~~~~~~~~~~~~~~~~");
						ArrayList<Flight> fList=service.getAllFlightsInformation();
						fList.forEach(flight->System.out.println(flight));
						myLogger.info("Flights report generated successfully");
						break;
				case 8: System.out.println("Sucessfully logged out....");
						myLogger.info("Admin Logged Out  Successfully");
						return;
			}
		}
	}
	
	public static void userModule(String uname) throws FlightException, IOException, BookingInformationException{
		Flight f = new Flight();
		myLogger.info("User Login Successfull");
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		AirlineServices service=new AirlineServicesImpl();
		while(true){
			System.out.println("------------Welcome To Airway Reservation System------------");
			System.out.println("1. Make my Trip(Search for Flights)");
			System.out.println("2. Plan My Trip (Book Now)");
			System.out.println("3. View My e-Ticket");
			System.out.println("4. Manage My Trip (Cancellation)");
			System.out.println("5. Logout");
			System.out.println("Enter your choice : ");
			int ch = Integer.parseInt(br.readLine());
			if(ch<1 || ch>5){
				System.out.println("Choice out of range. Try again.");
				continue;
			}
			switch(ch){
			case 1: System.out.println("|||||||||||Search wizard|||||||||||||||");
					System.out.println("Enter Source :");
					String src =br.readLine();
					System.out.println("Enter Destination");
					String dest = br.readLine();
					ArrayList<Flight> fList=service.searchFlightInformation(src,dest);
					fList.forEach(fl->System.out.println(fl));
					myLogger.info("Flight Searching retrieved Successfull search records");
					break;
			case 2: System.out.println("~~~~~~~~~~~~~~Book My Trip~~~~~~~~~~~~~~~~~~~");
					System.out.println("Enter Your Full name");
					String name =br.readLine();
					System.out.println("Enter email id");
					String email =br.readLine();
					System.out.println("Enter number of passengers: ");
					int nop =Integer.parseInt(br.readLine());
					System.out.println("Enter class type: ");
					String classType =br.readLine();
					System.out.println("Enter credit card info: ");
					String cci =br.readLine();
					System.out.println("Enter src city: ");
					String src1 =br.readLine();
					System.out.println("Enter dest city: ");
					String dest1 =br.readLine();
					//service.searchFlightInformation(src1, dest1);
					ArrayList<Flight> fList1=service.searchFlightInformation(src1,dest1);
					fList1.forEach(flight->System.out.println(flight));
					System.out.println("Specify the Flight Number :");
					String bfno = br.readLine();
					String s=null;
					f = service.getParticularFlight(bfno);
					
					float totalFare=0;
					if(bfno.equals(f.getFlightno()))
					{
						System.out.println("in booking");
						if(classType.equalsIgnoreCase("Economy")){
							if(f.bookFirstSeats(nop))
							{
								int upLim=f.getFirstSeats()-f.getFirstAvail();
								int lowLim=(upLim-nop)+1;
								int i;
								s=""+lowLim;
								for(i=lowLim+1;i<=upLim;i++)
								{
									s=s+","+i;
								}
								System.out.println(s);
								totalFare = nop*f.getFirstSeatFare();
								System.out.println(totalFare);
							}
							else
							{
								System.out.println("Sorry. No Seats Available");
							}
						}
						if(classType.equalsIgnoreCase("Business")){
							if(f.bookBussSeats(nop))
							{
								int upLim=f.getBussSeats()-f.getbSeatsAvail();
								int lowLim=(upLim-nop)+1;
								int i;
								s=""+lowLim;
								for(i=lowLim+1;i<=upLim;i++)
								{
									s=s+","+i;
								}
								System.out.println(s);
								totalFare = nop*f.getBussSeatsFare();
								System.out.println(totalFare);
							}
							else
							{
								System.out.println("Sorry. No Seats Available");
							}
						}
						if(service.updateFlightSeatsCNF(f)){
							System.out.println("Successfully Booked");
							myLogger.info("Tickets booked Successfully");
						}
						else {
							System.out.println("Booking Failed...");
							myLogger.info("Ticket Booking failed");
						}
					}
					else System.out.println("Invalid Value");
					BookingInformation obj=new BookingInformation(name, email, nop, classType, totalFare, s, cci, src1, dest1,bfno);
					String bid=service.addNewBookingInformation(obj);
					System.out.println("Your ticket has been booked with id:"+bid);
					break;
			case 3: System.out.println("_____________View Your Ticket Details________");
					System.out.println("Enter your Booking Id :");
					String vbid = br.readLine();
					BookingInformation b = service.getBookingInformation(vbid);
					System.out.println(b);
					myLogger.info("Ticket Generated Successfull");
					break;
			case 4: System.out.println("~~~~~~~~~~~~~Cancellation~~~~~~~~~~~~~~~~~~~");
					System.out.println("Enter Your Booking Id :");
					String cbid = br.readLine();
					
						
						BookingInformation fno=service.getBookingInformation(cbid);
						Flight updateF = new Flight();
						updateF=service.getParticularFlight(fno.getFlightno());
						String classType1=fno.getClassType();
						if(classType1.equalsIgnoreCase("Economy")){
							if(updateF.cancelFirstSeats(fno.getNoOfPassengers()))
							{
								
								System.out.println("Your tickets have been cancelled with refund amount of "+(fno.getTotalFare()-500));
							}
							else
							{
								System.out.println("Sorry!!!. Cancellation failed");
							}
						}
						if(classType1.equalsIgnoreCase("Business")){
							if(updateF.cancelBussSeats(fno.getNoOfPassengers()))
							{
								
								System.out.println("Your tickets have been cancelled with refund amount of "+(fno.getTotalFare()-1000));
							}
							else
							{
								System.out.println("Sorry!!!. Cancellation failed");
							}
						}
						if(service.updateFlightSeatsCNF(updateF)){
							System.out.println("Successfully Cancelled");
							myLogger.info("Ticket Cancelled Successfully");
						}
						else{
							System.out.println("Cancellation Failed...");
							myLogger.info("Tickets cancellation failed");
						}
						System.out.println(service.deleteBookingInformation(cbid));
					break;
			case 5: System.out.println("Sucessfully logged out....");
					myLogger.info("User logged out  Successfully");
					return;
			
			}
		}		
	}
	
	public static void executiveModule(String uname) throws NumberFormatException, IOException, FlightException{
		myLogger.info("Executive Login in Successfull");
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		AirlineServices service=new AirlineServicesImpl();
		while(true){
			System.out.println("------------Flight Executive Wizard------------");
			System.out.println("1. View Flight Occupancy for a Particular Flight");
			System.out.println("2. Logout");
			System.out.println("Enter your choice : ");
			int ch = Integer.parseInt(br.readLine());
			if(ch<1 || ch>2){
				System.out.println("Choice out of range. Try again.");
				continue;
			}
			switch(ch){
			case 1: System.out.println("~~~~~~~~~~~~~Occupancy Wizard~~~~~~~~~~~~~~~~~~~");
					System.out.println("Enter Particular Source :");
					String source = br.readLine();
					System.out.println("Enter Particular Destination :");
					String destiny = br.readLine();
					ArrayList<Flight> fList1=service.searchFlightInformation(source,destiny);
					fList1.forEach(flight->System.out.println(flight));
					System.out.println("Specify the Flight Number :");
					String flightNumber = br.readLine();
					Flight f = service.getParticularFlight(flightNumber);
					System.out.println("--------Economy Class------------");
					System.out.println("Total Number of Economy Class Seats : "+f.getFirstSeats());
					System.out.println("Total Number of Economy class Seats Available : "+f.getFirstAvail());
					System.out.println("Total Number of Seats Booked in Economy Class: "+(f.getFirstSeats()-f.getFirstAvail()));
					System.out.println("--------Business Class------------");
					System.out.println("Total Number of Business Class Seats : "+f.getBussSeats());
					System.out.println("Total Number of Business class Seats Available : "+f.getbSeatsAvail());
					System.out.println("Total Number of Seats Booked in Business Class: "+(f.getBussSeats()-f.getbSeatsAvail()));
					myLogger.info("Flight ocupancy records retrieved successfully");
					break;
			case 2: System.out.println("Sucessfully logged out....");
					myLogger.info("Executive Logged out Successfully");
					return;			
			}
		}		
	}	
}
