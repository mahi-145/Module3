package com.capgemini.ars.validations;

import java.util.regex.Pattern;

public class EntryFormValidations {
	public boolean isNameValid(String name)
	{
		String regex="[A-Z]{1}[A-Za-z ]{3,19}";
		boolean b = Pattern.matches(regex, name);
		return b;
	}
	public boolean isUnameValid(String uname){
		String regex="[a-z]{1}[A-Za-z]{3,12}";
		boolean b = Pattern.matches(regex, uname);
		return b;
	}
	public boolean isEmailIdValid(String mail)
	{
		String regex="[A-Za-z._0-9]+@[a-z]+.com";
		boolean b=Pattern.matches(regex, mail);
		return b;
	}
	
	public boolean isMobileValid(String mob)
	{
		String regex="[0-9]{10,20}";
		boolean b=Pattern.matches(regex, mob);
		return b;
	}
}
