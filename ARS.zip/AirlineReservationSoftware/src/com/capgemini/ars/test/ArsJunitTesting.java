package com.capgemini.ars.test;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.ars.entities.BookingInformation;
import com.capgemini.ars.entities.Flight;
import com.capgemini.ars.entities.Users;
import com.capgemini.ars.exceptions.BookingInformationException;
import com.capgemini.ars.exceptions.FlightException;
import com.capgemini.ars.exceptions.UserException;
import com.capgemini.ars.services.AirlineServices;
import com.capgemini.ars.services.AirlineServicesImpl;

public class ArsJunitTesting {
	static AirlineServices service;
	
	@BeforeClass
	public static void setUpBeforeClass() throws FlightException
	{
		try
		{
			service = new AirlineServicesImpl();
		} 

		catch (FlightException e)
		{
			throw new FlightException("Unale to create setup from Juit Testing...");
		}
	}
	
	@Test
	public void loginTesting() throws UserException{
		Users user = new Users();
		user.setUserName("Sai Chand");
		user.setPassword("ars");
		String uname = user.getUserName();
		String password = user.getPassword();
		boolean expected = true;
		boolean actual = service.getParticularUser(uname, password);
		Assert.assertEquals(expected, actual);
	}
	
	@Test
	public void ticketBookedOrNotTest() throws UserException, BookingInformationException{
		BookingInformation book = new BookingInformation();
		book.setBookingId("BI117");
		BookingInformation obj = service.getBookingInformation(book.getBookingId());
		String expected = obj.getCustName();
		String actual = "Krishna Kumar kakarla";
		Assert.assertEquals(expected, actual);
	}
	
	@Test
	public void flightTest() throws FlightException{
		Flight f1 = new Flight();
		f1.setDep_city("Chennai");
		f1.setArr_city("Mumbai");
		Flight f2 = service.getParticularFlight("FS665");
		String expected = f2.getArr_city();
		String actual = f1.getArr_city();
		Assert.assertEquals(expected, actual);
	}
}
