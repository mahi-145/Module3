package com.capgemini.ars.test;

import java.util.ArrayList;

import com.capgemini.ars.DAO.AirlineReservationDAO;
import com.capgemini.ars.DAO.AirlineReservationDAOImpl;
import com.capgemini.ars.entities.BookingInformation;
import com.capgemini.ars.exceptions.BookingInformationException;

public class TestDAO {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//System.out.println("hai");
		/**
		try {
			boolean flag=false;
			AirlineReservationDAO obj=new AirlineReservationDAOImpl();
			BookingInformation obj2=obj.getBookingInformation("a101");
			System.out.println(obj2);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		**/
		///**
		try {
			boolean flag=false;
			AirlineReservationDAO obj=new AirlineReservationDAOImpl();
			flag=obj.deleteBookingInformation("a101");
			System.out.println(flag);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//**/
		/**
		BookingInformation obj=new BookingInformation("pede", 100, "econo", 456, 23, "darling", "HYD", "VSKP");
		try {
			AirlineReservationDAO obj=new AirlineReservationDAOImpl();
			obj2.addNewBookingInformation(obj);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		**/
		/**
		ArrayList<BookingInformation> arr=new ArrayList<>();
		try {
			
			AirlineReservationDAO obj=new AirlineReservationDAOImpl();
			arr=obj2.getAllBookingInformation();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(arr);
		**/
		/**
		try {
			
			AirlineReservationDAO obj=new AirlineReservationDAOImpl();
			boolean arr=obj2.updateBookingInformation("ab", "custemail", "dede"); //update is removed
			System.out.println(arr);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		**/
		
		

	}

}
