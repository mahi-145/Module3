package com.capgemini.ars.services;

import java.sql.Date;
import java.util.ArrayList;

import com.capgemini.ars.entities.Airport;
import com.capgemini.ars.entities.BookingInformation;
import com.capgemini.ars.entities.Flight;
import com.capgemini.ars.entities.Location;
import com.capgemini.ars.entities.Users;
import com.capgemini.ars.exceptions.AirportException;
import com.capgemini.ars.exceptions.BookingInformationException;
import com.capgemini.ars.exceptions.FlightException;
import com.capgemini.ars.exceptions.UserException;

public interface AirlineServices {
	//admin part - flights creation,deletion,reports etc..
		int addNewFlight(Flight aft) throws FlightException;
		ArrayList<Flight> getAllFlightsInformation() throws FlightException;
		int updateFlightEconomySeatCNF(String flightno) throws FlightException;
		int updateFlightBusinessSeatCCL(String flightno) throws FlightException;
		int updateFlightBusinessSeatCNF(String flightno) throws FlightException;
		int updateFlightEconomySeatCCL(String flightno) throws FlightException;
		int updateFlightScheduleDepartureDate(String flightno, Date deptdate) throws FlightException;
		int updateFlightScheduleArrivalDate(String flightno, Date arrdate) throws FlightException;
		int updateFlightScheduleDepartureTime(String flightno, String depttime) throws FlightException;
		int updateFlightScheduleArrTime(String flightno, String arrtime) throws FlightException;
		boolean deleteFlight(String flightno) throws FlightException;
		boolean updateFlightSeatsCNF(Flight f) throws FlightException;
		Flight getParticularFlight(String fno) throws FlightException;
		
		//Booking info management - harsha
		String addNewBookingInformation(BookingInformation bookInfo) throws BookingInformationException;
		BookingInformation getBookingInformation(String bookingId) throws BookingInformationException;
		ArrayList<BookingInformation> getAllBookingInformation(String fno) throws BookingInformationException;
		//boolean updateBookingInformation(String bookingId,String field,String value) throws BookingInformationException;
		
		//public boolean updateBookingInformation(String bookingId,int field,int value) throws BookingInformationException;
		boolean deleteBookingInformation(String id) throws BookingInformationException;
		
		// User management - mounica
		public int addUser(Users user) throws UserException;
		public ArrayList<Users> getAllUsers() throws UserException;
		boolean getParticularUser(String uname, String password) throws UserException;
		String getUserCategory(String uname) throws UserException;
		ArrayList<Flight> searchFlightInformation(String src, String destination) throws FlightException;
		
		//Flight airport location - deedeepya
		void addAirportDetails(Airport a) throws AirportException;
		String deleteAirportDetails(String airportName) throws AirportException;
		public ArrayList<Airport> getAllAirports() throws AirportException;
		String updateAirportDetails(String airportName, String feild,String value) throws AirportException;
		void addLocations(Location loc) throws AirportException;
		String deleteLocation(String location) throws AirportException;
		public ArrayList<Location> getAllLocations() throws AirportException;
}
