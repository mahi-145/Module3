package com.capgemini.ars.services;

import java.sql.Date;
import java.util.ArrayList;

import com.capgemini.ars.DAO.AirlineReservationDAO;
import com.capgemini.ars.DAO.AirlineReservationDAOImpl;
import com.capgemini.ars.entities.Airport;
import com.capgemini.ars.entities.BookingInformation;
import com.capgemini.ars.entities.Flight;
import com.capgemini.ars.entities.Location;
import com.capgemini.ars.entities.Users;
import com.capgemini.ars.exceptions.AirportException;
import com.capgemini.ars.exceptions.BookingInformationException;
import com.capgemini.ars.exceptions.FlightException;
import com.capgemini.ars.exceptions.UserException;

public class AirlineServicesImpl implements AirlineServices {
	private AirlineReservationDAO dao;
	
	public AirlineServicesImpl() throws FlightException {
		// TODO Auto-generated constructor stub
		dao=new AirlineReservationDAOImpl();
	}

	@Override
	public int addNewFlight(Flight aft) throws FlightException {
		// TODO Auto-generated method stub
		return dao.addNewFlight(aft);
	}

	@Override
	public ArrayList<Flight> getAllFlightsInformation() throws FlightException {
		// TODO Auto-generated method stub
		return dao.getAllFlightsInformation();
	}

	
	@Override
	public int updateFlightEconomySeatCCL(String flightno)
			throws FlightException {
		// TODO Auto-generated method stub
		return dao.updateFlightEconomySeatCCL(flightno);
	}

	@Override
	public String addNewBookingInformation(BookingInformation bookInfo)
			throws BookingInformationException {
		// TODO Auto-generated method stub
		return dao.addNewBookingInformation(bookInfo);
	}

	@Override
	public BookingInformation getBookingInformation(String bookingId)
			throws BookingInformationException {
		// TODO Auto-generated method stub
		return dao.getBookingInformation(bookingId);
	}

	@Override
	public ArrayList<BookingInformation> getAllBookingInformation(String fno)
			throws BookingInformationException {
		// TODO Auto-generated method stub
		return dao.getAllBookingInformation(fno);
	}

	@Override
	public boolean deleteBookingInformation(String id)
			throws BookingInformationException {
		// TODO Auto-generated method stub
		return dao.deleteBookingInformation(id);
	}

	@Override
	public int addUser(Users user) throws UserException {
		// TODO Auto-generated method stub
		return dao.addUser(user);
	}

	@Override
	public ArrayList<Users> getAllUsers() throws UserException {
		// TODO Auto-generated method stub
		return dao.getAllUsers();
	}

	@Override
	public void addAirportDetails(Airport a) throws AirportException {
		// TODO Auto-generated method stub
		dao.addAirportDetails(a);
	}

	@Override
	public String deleteAirportDetails(String airportName)
			throws AirportException {
		// TODO Auto-generated method stub
		return dao.deleteAirportDetails(airportName);
	}

	@Override
	public ArrayList<Airport> getAllAirports() throws AirportException {
		// TODO Auto-generated method stub
		return dao.getAllAirports();
	}

	@Override
	public String updateAirportDetails(String airportName, String feild,
			String value) throws AirportException {
		// TODO Auto-generated method stub
		return dao.updateAirportDetails(airportName, feild, value);
	}

	@Override
	public void addLocations(Location loc) throws AirportException {
		// TODO Auto-generated method stub
		dao.addLocations(loc);
	}

	@Override
	public String deleteLocation(String location) throws AirportException {
		// TODO Auto-generated method stub
		return dao.deleteLocation(location);
	}

	@Override
	public ArrayList<Location> getAllLocations() throws AirportException {
		// TODO Auto-generated method stub
		return dao.getAllLocations();
	}

	@Override
	public boolean getParticularUser(String uname, String password)
			throws UserException {
		// TODO Auto-generated method stub
		return dao.getParticularUser(uname, password);
	}

	@Override
	public String getUserCategory(String uname) throws UserException {
		// TODO Auto-generated method stub
		return dao.getUserCategory(uname);
	}

	@Override
	public ArrayList<Flight> searchFlightInformation(String src,
			String destination) throws FlightException {
		// TODO Auto-generated method stub
		return dao.searchFlightInformation(src, destination);
	}

	@Override
	public int updateFlightScheduleDepartureDate(String flightno, Date deptdate)
			throws FlightException {
		// TODO Auto-generated method stub
		return dao.updateFlightScheduleDepartureDate(flightno, deptdate);
	}

	@Override
	public int updateFlightScheduleArrivalDate(String flightno, Date arrdate)
			throws FlightException {
		// TODO Auto-generated method stub
		return dao.updateFlightScheduleArrivalDate(flightno, arrdate);
	}

	@Override
	public int updateFlightScheduleDepartureTime(String flightno,
			String depttime) throws FlightException {
		// TODO Auto-generated method stub
		return dao.updateFlightScheduleDepartureTime(flightno, depttime);
	}

	@Override
	public int updateFlightScheduleArrTime(String flightno, String arrtime)
			throws FlightException {
		// TODO Auto-generated method stub
		return dao.updateFlightScheduleArrTime(flightno, arrtime);
	}

	@Override
	public boolean deleteFlight(String flightno) throws FlightException {
		// TODO Auto-generated method stub
		return dao.deleteFlight(flightno);
	}

	@Override
	public Flight getParticularFlight(String fno) throws FlightException {
		// TODO Auto-generated method stub
		return dao.getParticularFlight(fno);
	}

	@Override
	public boolean updateFlightSeatsCNF(Flight f) throws FlightException {
		// TODO Auto-generated method stub
		return dao.updateFlightSeatsCNF(f);
	}

	@Override
	public int updateFlightEconomySeatCNF(String flightno)
			throws FlightException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateFlightBusinessSeatCCL(String flightno)
			throws FlightException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateFlightBusinessSeatCNF(String flightno)
			throws FlightException {
		// TODO Auto-generated method stub
		return 0;
	}
}
