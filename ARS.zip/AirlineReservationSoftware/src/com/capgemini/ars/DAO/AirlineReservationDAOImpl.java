package com.capgemini.ars.DAO;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.capgemini.ars.entities.Airport;
import com.capgemini.ars.entities.BookingInformation;
import com.capgemini.ars.entities.Flight;
import com.capgemini.ars.entities.Location;
import com.capgemini.ars.entities.Users;
import com.capgemini.ars.exceptions.AirportException;
import com.capgemini.ars.exceptions.BookingInformationException;
import com.capgemini.ars.exceptions.FlightException;
import com.capgemini.ars.exceptions.UserException;
import com.capgemini.ars.utlities.DatasourceFactory;

public class AirlineReservationDAOImpl implements AirlineReservationDAO {
	private DataSource datasource;
	
	private static Logger myLogger =  Logger.getLogger("AirlineReservationSoftware");		
	public AirlineReservationDAOImpl() throws FlightException {
		DatasourceFactory factory = new DatasourceFactory();
		datasource = factory.getDataSource();
	}

	@Override
	public int addNewFlight(Flight aft) throws FlightException {
		// TODO Auto-generated method stub
		String qry = "INSERT INTO FLIGHTINFORMATION VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		try(
				Connection connect = datasource.getConnection();
				PreparedStatement stmt = connect.prepareStatement(qry);
				){
			stmt.setString(1, aft.getFlightno()); //Generate from Sequence
			stmt.setString(2, aft.getAirline());
			stmt.setString(3, aft.getDep_city());
			stmt.setString(4, aft.getArr_city());
			stmt.setDate(5, aft.getDep_date());
			stmt.setDate(6, aft.getArr_date());
			stmt.setString(7, aft.getDep_time());
			stmt.setString(8, aft.getArr_time());
			stmt.setInt(9, aft.getFirstSeats());
			stmt.setFloat(10, aft.getFirstSeatFare());
			stmt.setInt(11, aft.getBussSeats());
			stmt.setFloat(12, aft.getBussSeatsFare());
			stmt.setInt(13, aft.getFirstAvail());
			stmt.setInt(14, aft.getbSeatsAvail());
			stmt.executeUpdate();
			return 0;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new FlightException("Exception from addNewFlight()",e);
		}
	}

	@Override
	public ArrayList<Flight> getAllFlightsInformation() throws FlightException {
		// TODO Auto-generated method stub
		Flight obj=null;
		ArrayList<Flight> FlightInfoList=new ArrayList<>(); 
		String qry="SELECT FlightNo,AirLine,Source,Destination,DepartureDate,ArrivalDate,DepartureTime,ArrivalTime,EconomySeats,EconomySeatsFare,BusinessSeats,BusinessSeatsFare FROM FLIGHTINFORMATION";
		try(
				Connection connect = datasource.getConnection();
				Statement stat=connect.createStatement();
				ResultSet rs=stat.executeQuery(qry);
				)
		{			
			while(rs.next())
			{
				String FlightNo=rs.getString(1);
				String AirLine=rs.getString(2);
				String Source=rs.getString(3);
				String Destination=rs.getString(4);
				Date DepartureDate=rs.getDate(5);
				Date ArrivalDate=rs.getDate(6);
				String DepartureTime=rs.getString(7);
				String ArrivalTime=rs.getString(8);
				int EconomySeats=rs.getInt(9);
				int EconomySeatsFare=rs.getInt(10);
				int BusinessSeats=rs.getInt(11);
				int BusinessSeatsFare=rs.getInt(12);
				
				obj=new Flight(FlightNo,AirLine,Source,Destination,DepartureDate,ArrivalDate,DepartureTime,ArrivalTime,EconomySeats,EconomySeatsFare,BusinessSeats,BusinessSeatsFare);
				FlightInfoList.add(obj);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			throw new FlightException("Exception from displayBookingInformation()",e);
		}
		return FlightInfoList;
	}
	
	@Override
	public Flight getParticularFlight(String fno) throws FlightException {
		// TODO Auto-generated method stub
		Flight obj=null;
		ResultSet rs=null;
		//ArrayList<Flight> FlightInfoList=new ArrayList<>(); 
		String qry="SELECT FlightNo,AirLine,Source,Destination,DepartureDate,ArrivalDate,DepartureTime,ArrivalTime,Economyseats,EconomySeatsFare,businessseats,BusinessSeatsFare,FIRSTAVAIL,BSEATSAVAIL FROM FLIGHTINFORMATION WHERE FLIGHTNO LIKE ?";
		try(
				Connection connect = datasource.getConnection();
				PreparedStatement pps = connect.prepareStatement(qry);
				)
		{
			pps.setString(1, fno);
			rs = pps.executeQuery();
			while(rs.next())
			{
				String FlightNo=rs.getString(1);
				String AirLine=rs.getString(2);
				String Source=rs.getString(3);
				String Destination=rs.getString(4);
				Date DepartureDate=rs.getDate(5);
				Date ArrivalDate=rs.getDate(6);
				String DepartureTime=rs.getString(7);
				String ArrivalTime=rs.getString(8);
				int EconomySeats=rs.getInt(9);
				int EconomySeatsFare=rs.getInt(10);
				int BusinessSeats=rs.getInt(11);
				int BusinessSeatsFare=rs.getInt(12);
				int firstSeatsAvail = rs.getInt(13);
				int bSeatsAvail = rs.getInt(14);
				
				obj=new Flight(FlightNo,AirLine,Source,Destination,DepartureDate,ArrivalDate,DepartureTime,ArrivalTime,EconomySeats,EconomySeatsFare,BusinessSeats,BusinessSeatsFare,firstSeatsAvail,bSeatsAvail);
				//FlightInfoList.add(obj);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			throw new FlightException("Exception from displayBookingInformation()",e);
		}
		return obj;
	}
	
	
	@Override
	public ArrayList<Flight> searchFlightInformation(String src,String destination) throws FlightException {
		// TODO Auto-generated method stub
		Flight obj=null;
		ResultSet rs=null;
		ArrayList<Flight> FlightInfoList=new ArrayList<>(); 
		String qry="SELECT FlightNo,AirLine,Source,Destination,DepartureDate,ArrivalDate,DepartureTime,ArrivalTime,Economyseats,EconomySeatsFare,businessseats,BusinessSeatsFare FROM FLIGHTINFORMATION WHERE SOURCE LIKE ? AND DESTINATION LIKE ?";
		try(
				Connection connect = datasource.getConnection();
				PreparedStatement pps = connect.prepareStatement(qry);
				)
		{
			pps.setString(1, src);
			pps.setString(2, destination);
			rs = pps.executeQuery();
			while(rs.next())
			{
				String FlightNo=rs.getString(1);
				String AirLine=rs.getString(2);
				String Source=rs.getString(3);
				String Destination=rs.getString(4);
				Date DepartureDate=rs.getDate(5);
				Date ArrivalDate=rs.getDate(6);
				String DepartureTime=rs.getString(7);
				String ArrivalTime=rs.getString(8);
				int EconomySeats=rs.getInt(9);
				int EconomySeatsFare=rs.getInt(10);
				int BusinessSeats=rs.getInt(11);
				int BusinessSeatsFare=rs.getInt(12);
				
				obj=new Flight(FlightNo,AirLine,Source,Destination,DepartureDate,ArrivalDate,DepartureTime,ArrivalTime,EconomySeats,EconomySeatsFare,BusinessSeats,BusinessSeatsFare);
				FlightInfoList.add(obj);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			throw new FlightException("Exception from displayBookingInformation()",e);
		}
		return FlightInfoList;
	}
	
	@Override
	public boolean deleteFlight(String flightno)
			throws FlightException {
		String qry="DELETE FROM FLIGHTINFORMATION WHERE flightno LIKE ?";
		
		try(
				Connection connect = datasource.getConnection();
				PreparedStatement pStat=connect.prepareStatement(qry);
				)
		{
			
			pStat.setString(1, flightno);
			int flag=pStat.executeUpdate();
			//System.out.println(a);
			//ResultSet rs=pStat.executeQuery(qry);
			
			if(flag==1)
				return true;
			else return false;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new FlightException("Exception from deleteFlightInformation()",e);
		}
				
	}
	
	@Override
	public int updateFlightScheduleDepartureDate(String flightno,Date deptdate) {
		String query = "UPDATE FLIGHTINFORMATION SET DepartureDate=?  WHERE FLIGHTNO LIKE ?";
		try(
				Connection connect = datasource.getConnection();
				PreparedStatement preparedStatement = connect.prepareStatement(query);
		)
		{
			preparedStatement.setDate(1, deptdate);
			preparedStatement.setString(2,flightno); 
		int count = preparedStatement.executeUpdate(); // returns the no. of records affected.
		return count;
		}
		catch (SQLException e)
		{
			try {
				throw new FlightException("Exception from updateCustomerDetails()",e);
			} catch (FlightException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		return 0;
	}
	
	@Override
	public int updateFlightScheduleArrivalDate(String flightno,Date arrdate) {
		String query = "UPDATE FLIGHTINFORMATION SET ArrivalDate=?  WHERE FLIGHTNO LIKE ?";
		try(
				Connection connect = datasource.getConnection();
				PreparedStatement preparedStatement = connect.prepareStatement(query);
		)
		{
			preparedStatement.setDate(1, arrdate);
			preparedStatement.setString(2,flightno); 
		int count = preparedStatement.executeUpdate(); // returns the no. of records affected.
		return count;
		}
		catch (SQLException e)
		{
			try {
				throw new FlightException("Exception from updateCustomerDetails()",e);
			} catch (FlightException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		return 0;
	}
	
	@Override
	public int updateFlightScheduleDepartureTime(String flightno,String depttime) {
		String query = "UPDATE FLIGHTINFORMATION SET DepartureTime=?  WHERE FLIGHTNO LIKE ?";
		try(
				Connection connect = datasource.getConnection();
				PreparedStatement preparedStatement = connect.prepareStatement(query);
		)
		{
			preparedStatement.setString(1, depttime);
			preparedStatement.setString(2,flightno); 
		int count = preparedStatement.executeUpdate(); // returns the no. of records affected.
		return count;
		}
		catch (SQLException e)
		{
			try {
				throw new FlightException("Exception from updateCustomerDetails()",e);
			} catch (FlightException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		return 0;
	}
	
	@Override
	public int updateFlightScheduleArrTime(String flightno,String arrtime) {
		String query = "UPDATE FLIGHTINFORMATION SET DepartureTime=?  WHERE FLIGHTNO LIKE ?";
		try(
				Connection connect = datasource.getConnection();
				PreparedStatement preparedStatement = connect.prepareStatement(query);
		)
		{
			preparedStatement.setString(1, arrtime);
			preparedStatement.setString(2,flightno); 
		int count = preparedStatement.executeUpdate(); // returns the no. of records affected.
		return count;
		}
		catch (SQLException e)
		{
			try {
				throw new FlightException("Exception from updateCustomerDetails()",e);
			} catch (FlightException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		return 0;
	}

	@Override
	public boolean updateFlightSeatsCNF(Flight f) throws FlightException {
		String query = "UPDATE FLIGHTINFORMATION SET FIRSTAVAIL=?,BSEATSAVAIL=?  WHERE FLIGHTNO LIKE ?";
		try(
				Connection connect = datasource.getConnection();
				PreparedStatement preparedStatement = connect.prepareStatement(query);
		)
		{
			preparedStatement.setInt(1, f.getFirstAvail());
			preparedStatement.setInt(2,f.getbSeatsAvail());
			preparedStatement.setString(3, f.getFlightno());
		int count = preparedStatement.executeUpdate(); // returns the no. of records affected.
		 if(count>0){
			 return true;
		 }
		 else return false;
		}
		catch (SQLException e)
		{
				throw new FlightException("Exception from cnfirmed seats update");
			
		}
		
	}
	
	@Override
	public int updateFlightEconomySeatCCL(String flightno) {
		String query = "UPDATE FLIGHTINFORMATION SET EconomySeats=EconomySeats+1  WHERE FLIGHTNO LIKE '?'";
		try(
				Connection connect = datasource.getConnection();
				PreparedStatement preparedStatement = connect.prepareStatement(query);
		)
		{
			preparedStatement.setString(1,flightno); 
		int count = preparedStatement.executeUpdate(); // returns the no. of records affected.
		return count;
		}
		catch (SQLException e)
		{
			try {
				throw new FlightException("Exception from updateCustomerDetails()",e);
			} catch (FlightException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		return 0;
	}

	/*@Override
	public int updateFlightBusinessSeatCNF(String flightno) {
		String query = "UPDATE FLIGHTINFORMATION SET BusinessSeats=BusinessSeats-1  WHERE FLIGHTNO LIKE '?'";
		try(
				Connection connect = datasource.getConnection();
				PreparedStatement preparedStatement = connect.prepareStatement(query);
		)
		{
			preparedStatement.setString(1,flightno); 
		int count = preparedStatement.executeUpdate(); // returns the no. of records affected.
		return count;
		}
		catch (SQLException e)
		{
			try {
				throw new FlightException("Exception from updateCustomerDetails()",e);
			} catch (FlightException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		return 0;
	}

	@Override
	public int updateFlightBusinessSeatCCL(String flightno) {
		String query = "UPDATE FLIGHTINFORMATION SET BusinessSeats=BusinessSeats+1  WHERE FLIGHTNO LIKE '?'";
		try(
				Connection connect = datasource.getConnection();
				PreparedStatement preparedStatement = connect.prepareStatement(query);
		)
		{
			preparedStatement.setString(1,flightno); 
		int count = preparedStatement.executeUpdate(); // returns the no. of records affected.
		return count;
		}
		catch (SQLException e)
		{
			try {
				throw new FlightException("Exception from updateCustomerDetails()",e);
			} catch (FlightException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		return 0;
	}*/
	
	// booking - harsha	
	@Override
	public String addNewBookingInformation(BookingInformation bookInfo) throws BookingInformationException {
		// TODO Auto-generated method stub
		String bookingId="BI"; //to write generator
		String qry="INSERT INTO BookingInformation VALUES(?,?,?,?,?,?,?,?,?,?,?)";
		try(
				Connection connect = datasource.getConnection();
				PreparedStatement pStat=connect.prepareStatement(qry);
				)
		{
			int key=getNextId();
			bookingId=bookingId+Integer.toString(key);
			pStat.setString(1, bookingId);
			pStat.setString(2, bookInfo.getCustName());
			pStat.setString(3, bookInfo.getCustEmail());
			pStat.setInt(4, bookInfo.getNoOfPassengers());
			pStat.setString(5, bookInfo.getClassType());
			pStat.setFloat(6, bookInfo.getTotalFare());
			pStat.setString(7, bookInfo.getSeatNumber());
			pStat.setString(8, bookInfo.getCreditCardInfo());
			pStat.setString(9, bookInfo.getSrcCity());
			pStat.setString(10, bookInfo.getDestCity());
			pStat.setString(11,bookInfo.getFlightno());
			pStat.executeUpdate();
						
			return bookingId;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new BookingInformationException("Exception from addNewBookingInformation()",e);
		}
		
	}

	@Override
	public BookingInformation getBookingInformation(String bookingId)
			throws BookingInformationException {
		BookingInformation obj=null;
		ResultSet rs=null;
		String qry="SELECT custName,custEmail,noOfPassengers,classType,totalFare,seatNumber,creditCardInfo,srcCity,destCity,flightno FROM BookingInformation where bookingId=?";
		try(
				Connection connect = datasource.getConnection();
				PreparedStatement pStat=connect.prepareStatement(qry);
				
				)
		{
			pStat.setString(1, bookingId);
			rs=pStat.executeQuery();
			if(rs.next())
			{
				String custName = rs.getString(1);
				String custEmail=rs.getString(2);
				int noOfPassengers=rs.getInt(3);
				String classType=rs.getString(4);
				int totalFare=rs.getInt(5);
				String seatNumber=rs.getString(6);
				String creditCardInfo=rs.getString(7);
				String srcCity=rs.getString(8);
				String destCity=rs.getString(9);
				String flightno = rs.getString(10);
				obj=new BookingInformation(bookingId,custName,custEmail, noOfPassengers, classType, totalFare, seatNumber, creditCardInfo, srcCity, destCity,flightno);				
			}			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			throw new BookingInformationException("Exception from getBookingInformation()",e);
		} finally {
			
			try {
				if(rs!=null)
					rs.close();
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
		return obj;
	}
	
	@Override
	public ArrayList<BookingInformation> getAllBookingInformation(String fno) throws BookingInformationException {
		// TODO Auto-generated method stub
		BookingInformation obj=null;
		ResultSet rs = null;
		ArrayList<BookingInformation> bookInfoList=new ArrayList<>(); 
		String qry="SELECT bookingId,custName,custEmail,noOfPassengers,classType,totalFare,seatNumber,creditCardInfo,srcCity,destCity,flightno FROM BookingInformation WHERE FLIGHTNO=?";
		try(
				Connection connect = datasource.getConnection();
				PreparedStatement pps = connect.prepareStatement(qry);
				)
		{
			pps.setString(1, fno);
			rs = pps.executeQuery();
			while(rs.next())
			{
				String bookingId=rs.getString(1);
				String custName = rs.getString(2);
				String custEmail=rs.getString(3);
				int noOfPassengers=rs.getInt(4);
				String classType=rs.getString(5);
				int totalFare=rs.getInt(6);
				String seatNumber=rs.getString(7);
				String creditCardInfo=rs.getString(8);
				String srcCity=rs.getString(9);
				String destCity=rs.getString(10);
				String flightno = rs.getString(11);
				
				obj=new BookingInformation(bookingId,custName,custEmail, noOfPassengers, classType, totalFare, seatNumber, creditCardInfo, srcCity, destCity,flightno);
				bookInfoList.add(obj);
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			throw new BookingInformationException("Exception from displayBookingInformation()",e);
		}
	
		return bookInfoList;
		

	}
	
	/**
	@Override
	public boolean updateBookingInformation(String bookingId,String field,String value)
			throws BookingInformationException {
		String qry="UPDATE BOOKINGINFORMATION SET ?=? WHERE bookingId=?";
		
		try(
				Connection connect = datasource.getConnection();
				PreparedStatement pStat=conn.prepareStatement(qry);
				)
		{
			//pStat.setString(1, field);
			pStat.setString(1, value);
			pStat.setString(2, bookingId);
			int flag=pStat.executeQuery();
			if(flag==1)
				return true;
			else return false;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			throw new BookingInformationException("Exception from updateBookingInformation()",e);
		}
			
	}
	

	@Override
	public boolean updateBookingInformation(String bookingId, int field,
			int value) throws BookingInformationException {
		// TODO Auto-generated method stub
        String qry="UPDATE emp_master SET ?=? WHERE bookingId=?";
		
		try(
				Connection connect = datasource.getConnection();
				PreparedStatement pStat=conn.prepareStatement(qry);
				)
		{
			pStat.setInt(1, field);
			pStat.setInt(2, value);
			pStat.setString(3, bookingId);
			int flag=pStat.executeUpdate();
			if(flag==1)
				return true;
			else return false;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			throw new BookingInformationException("Exception from updateBookingInformation()",e);
		}

	}
	**/

	@Override
	public boolean deleteBookingInformation(String bookingId)
			throws BookingInformationException {
		String qry="DELETE FROM BookingInformation WHERE bookingId=?";
		
		try(
				Connection connect = datasource.getConnection();
				PreparedStatement pStat=connect.prepareStatement(qry);
				)
		{
			
			pStat.setString(1, bookingId);
			int flag=pStat.executeUpdate();
			//System.out.println(a);
			//ResultSet rs=pStat.executeQuery(qry);
			
			if(flag==1)
				return true;
			else return false;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new BookingInformationException("Exception from deleteBookingInformation()",e);
		}
				
	}
	
	public int getNextId() throws BookingInformationException
	{
		
		String qry="SELECT BookingInformation_bookingId.nextval from dual";
		try(
				Connection connect = datasource.getConnection();
				Statement st=connect.createStatement();
				ResultSet rs=st.executeQuery(qry);
			)
		{
			if(rs.next())
				return rs.getInt(1);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			throw new BookingInformationException("Exception from getNextId()",e);
		}
		return 0;
	}
	
	//mounika - ums
	public int addUser(Users user) throws UserException {
		String qry = "INSERT INTO users values(?,?,?,?,?)";
		//PreparedStatement pstmt = null;
		int result=0;
		
		try(
				Connection connect = datasource.getConnection();
				PreparedStatement pstmt = connect.prepareStatement(qry);
				)
		{
			pstmt.setString(1, user.getUserName());
			pstmt.setString(2, user.getPassword());
			pstmt.setString(3, user.getEmail());
			pstmt.setString(4, user.getMobileNo());
			pstmt.setString(5, user.getRole());
			result = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		//throw new UserException("Exception from addUser()");
		}
		return result;
	}
	
	
	public ArrayList<Users> getAllUsers() throws UserException{
		String qry="SELECT userName,password,email,mobileNo,role FROM users";
		ArrayList<Users> userList=new ArrayList<>();
		try(
				Connection connect = datasource.getConnection();
				Statement stmt=connect.createStatement();
				ResultSet rs=stmt.executeQuery(qry);
				
				){
			while(rs.next()){
				
				String userName=rs.getString(1);
				String password=rs.getString(2);
				String email=rs.getString(3);
				String mobileNo=rs.getString(4);
				String role=rs.getString(5);
				Users user=new Users(userName,password,email,mobileNo,role);
				userList.add(user);
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new UserException("Exception from getAllUsers()");
			}
		return userList;
		
	}
	
	@Override
	public boolean getParticularUser(String uname,String password) throws UserException{
		String qry="SELECT USERNAME FROM USERS WHERE PASSWORD LIKE ?";
		ResultSet rs = null;
		//System.out.println(mobid*2);
		try(
				Connection connect = datasource.getConnection();
				PreparedStatement pps = connect.prepareStatement(qry);
				){
			pps.setString(1, password);
			rs = pps.executeQuery();
			rs.next();
			String id = rs.getString(1);
			//System.out.println(id);
			if(id.equals(uname)) return true;
			else return false;
		} catch (SQLException e) {
			throw new UserException("Exception from getSpecificRecord()",e);
		}
	}
	
	@Override
	public String getUserCategory(String uname) throws UserException{
		String qry="SELECT ROLE FROM USERS WHERE USERNAME LIKE ?";
		ResultSet rs = null;
		try(
				Connection connect = datasource.getConnection();
				PreparedStatement pps = connect.prepareStatement(qry);
				){
			pps.setString(1, uname);
			rs = pps.executeQuery();
			rs.next();
			String category = rs.getString(1);
			//System.out.println(id);
			return category;
		} catch (SQLException e) {
			throw new UserException("Exception from getSpecificRecord()",e);
		}
	}
	// flight - airport locations
	@Override
	public void addAirportDetails(Airport a) throws AirportException {
		
		String qry = "INSERT INTO airport(airportName,abbrevation ,location) VALUES (?, ?, ?)";
		
		try(
				Connection connect = datasource.getConnection();
				PreparedStatement pStmt = connect.prepareStatement(qry);
				){
			
			pStmt.setString(1, a.getAirportName());
			pStmt.setString(2, a.getAbbrevation());
			pStmt.setString(3, a.getLocation());
			
			pStmt.executeUpdate();
			System.out.println("true");
			
			
		} catch (SQLException e) {
			
			throw new AirportException("Exception from addAirportDetails()",e);
		}
	}
	
	@Override
	public String deleteAirportDetails(String airportName) throws AirportException {
		String qry = "DELETE FROM airport WHERE airportName=?";
		
		try(
				Connection connect = datasource.getConnection();
				PreparedStatement pStmt = connect.prepareStatement(qry);
				){
			
			pStmt.setString(1, airportName);
			pStmt.executeUpdate();
			
			
		} catch (SQLException e) {
			
			throw new AirportException("Exception from deleteAirportDetails()",e);
		}
		return "successfully deleted";
		
	}
	@Override
	public ArrayList<Airport> getAllAirports() throws AirportException {
		// TODO Auto-generated method stub
		String qry="SELECT airportName,abbrevation,location FROM airport";
		ArrayList<Airport> aList=new ArrayList<>();
		
		try
		(
				Connection connect = datasource.getConnection();
				Statement st=connect.createStatement();	//try with resources closes the 2 resources(Statement,resultSet)
				ResultSet rs=st.executeQuery(qry);	//
				)
				{
					while(rs.next())
					{
						String airportname=rs.getString(1);
						String abbrevation=rs.getString(2);
						String location=rs.getString(3);
						Airport a=new Airport(airportname,abbrevation,location);
						aList.add(a);
					}
				} catch (SQLException e) {
					
					throw new AirportException("Exception from getAllAirports()");
				}
		return aList;
		
	}
	@Override
	public String updateAirportDetails(String airportName,String feild, String value)
			throws AirportException {
		// TODO Auto-generated method stub
		String qry = "UPDATE FROM airport SET ?=? WHERE airportName=?";
		
		try(
				Connection connect = datasource.getConnection();
				PreparedStatement pStmt = connect.prepareStatement(qry);
				){
			
			pStmt.setString(1, feild);
			pStmt.setString(2, value);
			pStmt.setString(3, airportName);
			pStmt.executeUpdate();
			
			
		} catch (SQLException e) {
			
			throw new AirportException("Exception from updateAirportDetails()",e);
		}
		return "successfully updated";
		
	}
	

	@Override
	public void addLocations(Location loc) throws AirportException {
		// TODO Auto-generated method stub
		String qry1 = "INSERT INTO location(location,state,zipCode) VALUES (?, ?, ?)";
		
		
		try(
				Connection connect = datasource.getConnection();
				PreparedStatement pStmt = connect.prepareStatement(qry1);
					
				){
			
			pStmt.setString(1, loc.getLocation());
			pStmt.setString(2, loc.getState());
			pStmt.setString(3, loc.getZipCode());
			
			pStmt.executeUpdate();
			
			
		} catch (SQLException e) {
			
			throw new AirportException("Exception from addAirportDetails()",e);
		}
		
	}

	@Override
	public String deleteLocation(String location) throws AirportException {
		// TODO Auto-generated method stub
		String qry = "DELETE FROM airport WHERE airportName=?";
		
		try(
				Connection connect = datasource.getConnection();
				PreparedStatement pStmt = connect.prepareStatement(qry);
				){
			
			pStmt.setString(1, location);
			pStmt.executeUpdate();
			
			
		} catch (SQLException e) {
			
			throw new AirportException("Exception from deleteLocation()",e);
		}
		return "successfully deleted";
		
	}

	@Override
	public ArrayList<Location> getAllLocations() throws AirportException {
		// TODO Auto-generated method stub
		String qry="SELECT location,state,zipCode FROM location";
		ArrayList<Location> aList=new ArrayList<>();
		try
		(
				Connection connect = datasource.getConnection();
				Statement st=connect.createStatement();	//try with resources closes the 2 resources(Statement,resultSet)
				ResultSet rs=st.executeQuery(qry);	//
				)
				{
					while(rs.next())
					{
						String location=rs.getString(1);
						String state=rs.getString(2);
						String zipCode=rs.getString(3);
						Location loc=new Location(location,state,zipCode);
						aList.add(loc);
					}
				} catch (SQLException e) {
					
					throw new AirportException("Exception from getAllLocations()");
				}
		return aList;
	}
}
