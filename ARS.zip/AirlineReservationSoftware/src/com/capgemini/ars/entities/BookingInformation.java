package com.capgemini.ars.entities;

public class BookingInformation {
	private String bookingId;
	private String custName;
	private String custEmail;
	private int noOfPassengers;
	private String classType;
	private float totalFare;
	private String seatNumber;
	private String creditCardInfo;
	private String srcCity;
	private String destCity;
	private String flightno;
	
	
	
	public BookingInformation() {
		
	}



	public BookingInformation(String bookingId,String custName, String custEmail,
			int noOfPassengers, String classType, float totalFare,
			String seatNumber, String creditCardInfo, String srcCity,
			String destCity, String flightno) {
		super();
		this.bookingId = bookingId;
		this.custName = custName;
		this.custEmail = custEmail;
		this.noOfPassengers = noOfPassengers;
		this.classType = classType;
		this.totalFare = totalFare;
		this.seatNumber = seatNumber;
		this.creditCardInfo = creditCardInfo;
		this.srcCity = srcCity;
		this.destCity = destCity;
		this.flightno = flightno;
	}
	
	
	
	public String getCustName() {
		return custName;
	}



	public void setCustName(String custName) {
		this.custName = custName;
	}




	public BookingInformation(String custName,String custEmail, int noOfPassengers,
			String classType, float totalFare2, String seatNumber,
			String creditCardInfo, String srcCity, String destCity,
			String flightno) {
		super();
		this.custName= custName;
		this.custEmail = custEmail;
		this.noOfPassengers = noOfPassengers;
		this.classType = classType;
		this.totalFare = totalFare2;
		this.seatNumber = seatNumber;
		this.creditCardInfo = creditCardInfo;
		this.srcCity = srcCity;
		this.destCity = destCity;
		this.flightno = flightno;
	}



	public String getFlightno() {
		return flightno;
	}



	public void setFlightno(String flightno) {
		this.flightno = flightno;
	}



	public String getBookingId() {
		return bookingId;
	}
	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}
	public String getCustEmail() {
		return custEmail;
	}
	public void setCustEmail(String custEmail) {
		this.custEmail = custEmail;
	}
	public int getNoOfPassengers() {
		return noOfPassengers;
	}
	public void setNoOfPassengers(int noOfPassengers) {
		this.noOfPassengers = noOfPassengers;
	}
	public String getClassType() {
		return classType;
	}
	public void setClassType(String classType) {
		this.classType = classType;
	}
	public float getTotalFare() {
		
		return totalFare;
	}
	public void setTotalFare(int totalFare) {
		
		this.totalFare = totalFare;
	}
	public String getSeatNumber() {
		
		return seatNumber;
	}
	public void setSeatNumber(String seatNumber) {
		this.seatNumber = seatNumber;
	}
	public String getCreditCardInfo() {
		return creditCardInfo;
	}
	public void setCreditCardInfo(String creditCardInfo) {
		this.creditCardInfo = creditCardInfo;
	}
	public String getSrcCity() {
		return srcCity;
	}
	public void setSrcCity(String srcCity) {
		this.srcCity = srcCity;
	}
	public String getDestCity() {
		return destCity;
	}
	public void setDestCity(String destCity) {
		this.destCity = destCity;
	}
	
	
	


	@Override
	public String toString() {
		return "BookingInformation [bookingId=" + bookingId + ", custName="
				+ custName + ", custEmail=" + custEmail + ", noOfPassengers="
				+ noOfPassengers + ", classType=" + classType + ", totalFare="
				+ totalFare + ", seatNumber=" + seatNumber
				+ ", creditCardInfo=" + creditCardInfo + ", srcCity=" + srcCity
				+ ", destCity=" + destCity + ", flightno=" + flightno + "]";
	}



	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((bookingId == null) ? 0 : bookingId.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BookingInformation other = (BookingInformation) obj;
		if (bookingId == null) {
			if (other.bookingId != null)
				return false;
		} else if (!bookingId.equals(other.bookingId))
			return false;
		return true;
	}
	

	
	
	

}
