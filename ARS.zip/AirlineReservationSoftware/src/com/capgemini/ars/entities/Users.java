package com.capgemini.ars.entities;

public class Users {

	private String userName;
	private String password;
	private String email;
	private String mobileNo;
	private String role;
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	
	public Users(){
	}
	
	public Users(String userName, String password, String email,
			String mobileNo, String role) {
		super();
		this.userName = userName;
		this.password = password;
		this.email = email;
		this.mobileNo = mobileNo;
		this.role = role;
	}
	@Override
	public String toString() {
		return "Users [userName=" + userName + ", password=" + password
				+ ", email=" + email + ", mobileNo=" + mobileNo + ", role="
				+ role + "]";
	}
}
