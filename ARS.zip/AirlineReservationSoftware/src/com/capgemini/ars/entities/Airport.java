package com.capgemini.ars.entities;

import java.io.Serializable;

public class Airport implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String airportName;
	private String abbrevation;
	private String location;

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((airportName == null) ? 0 : airportName.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Airport other = (Airport) obj;
		if (airportName == null) {
			if (other.airportName != null)
				return false;
		} else if (!airportName.equals(other.airportName))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Airport [airportName=" + airportName + ", abbrevation="
				+ abbrevation + ", location=" + location + "]";
	}
	public String getAirportName() {
		return airportName;
	}
	public void setAirportName(String airportName) {
		this.airportName = airportName;
	}
	public String getAbbrevation() {
		return abbrevation;
	}
	public void setAbbrevation(String abbrevation) {
		this.abbrevation = abbrevation;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public Airport() {
		super();
	}
	public Airport(String airportName, String abbrevation, String location) {
		super();
		this.airportName = airportName;
		this.abbrevation = abbrevation;
		this.location = location;
	}
	
}
