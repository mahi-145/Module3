package com.capgemini.ars.entities;

import java.io.Serializable;
import java.sql.Date;

public class Flight implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String flightno;
	private String airline;
	private String dep_city;
	private String arr_city;
	private Date dep_date;
	private Date arr_date;
	private String dep_time;
	private String arr_time;
	private int FirstSeats;
	private float FirstSeatFare;
	private int BussSeats;
	private float BussSeatsFare;
	private int firstAvail;
	private int bSeatsAvail;
	
	
	public int getFirstAvail() {
		return firstAvail;
	}

	public void setFirstAvail(int firstAvail) {
		this.firstAvail = firstAvail;
	}

	public int getbSeatsAvail() {
		return bSeatsAvail;
	}

	public void setbSeatsAvail(int bSeatsAvail) {
		this.bSeatsAvail = bSeatsAvail;
	}
	

	public Flight(String flightno, String airline, String dep_city,
			String arr_city, Date dep_date, Date arr_date, String dep_time,
			String arr_time, int firstSeats, float firstSeatFare,
			int bussSeats, float bussSeatsFare, int firstAvail, int bSeatsAvail) {
		super();
		this.flightno = flightno;
		this.airline = airline;
		this.dep_city = dep_city;
		this.arr_city = arr_city;
		this.dep_date = dep_date;
		this.arr_date = arr_date;
		this.dep_time = dep_time;
		this.arr_time = arr_time;
		FirstSeats = firstSeats;
		FirstSeatFare = firstSeatFare;
		BussSeats = bussSeats;
		BussSeatsFare = bussSeatsFare;
		this.firstAvail = firstAvail;
		this.bSeatsAvail = bSeatsAvail;
	}

	public Flight(String flightno, String airline, String dep_city,
			String arr_city, Date dep_date, Date arr_date, String dep_time,
			String arr_time, int firstSeats, float firstSeatFare, int bussSeats,
			float bussSeatsFare) {
		super();
		this.flightno = flightno;
		this.airline = airline;
		this.dep_city = dep_city;
		this.arr_city = arr_city;
		this.dep_date = dep_date;
		this.arr_date = arr_date;
		this.dep_time = dep_time;
		this.arr_time = arr_time;
		FirstSeats = firstSeats;
		FirstSeatFare = firstSeatFare;
		BussSeats = bussSeats;
		BussSeatsFare = bussSeatsFare;
	}

	public Flight() {
		// TODO Auto-generated constructor stub
	}

	public String getFlightno() {
		return flightno;
	}

	public void setFlightno(String flightno) {
		this.flightno = flightno;
	}

	public String getAirline() {
		return airline;
	}

	public void setAirline(String airline) {
		this.airline = airline;
	}

	public String getDep_city() {
		return dep_city;
	}

	public void setDep_city(String dep_city) {
		this.dep_city = dep_city;
	}

	public String getArr_city() {
		return arr_city;
	}

	public void setArr_city(String arr_city) {
		this.arr_city = arr_city;
	}

	public Date getDep_date() {
		return dep_date;
	}

	public void setDep_date(Date dep_date) {
		this.dep_date = dep_date;
	}

	public Date getArr_date() {
		return arr_date;
	}

	public void setArr_date(Date arr_date) {
		this.arr_date = arr_date;
	}

	public String getDep_time() {
		return dep_time;
	}

	public void setDep_time(String dep_time) {
		this.dep_time = dep_time;
	}

	public String getArr_time() {
		return arr_time;
	}

	public void setArr_time(String arr_time) {
		this.arr_time = arr_time;
	}

	public int getFirstSeats() {
		return FirstSeats;
	}

	public void setFirstSeats(int firstSeats) {
		FirstSeats = firstSeats;
	}

	public float getFirstSeatFare() {
		return FirstSeatFare;
	}

	public void setFirstSeatFare(float firstSeatFare) {
		FirstSeatFare = firstSeatFare;
	}

	public int getBussSeats() {
		return BussSeats;
	}

	public void setBussSeats(int bussSeats) {
		BussSeats = bussSeats;
	}

	public float getBussSeatsFare() {
		return BussSeatsFare;
	}

	public void setBussSeatsFare(float bussSeatsFare) {
		BussSeatsFare = bussSeatsFare;
	}

	@Override
	public String toString() {
		return "flight [flightno=" + flightno + ", airline=" + airline
				+ ", dep_city=" + dep_city + ", arr_city=" + arr_city
				+ ", dep_date=" + dep_date + ", arr_date=" + arr_date
				+ ", dep_time=" + dep_time + ", arr_time=" + arr_time
				+ ", FirstSeats=" + FirstSeats + ", FirstSeatFare="
				+ FirstSeatFare + ", BussSeats=" + BussSeats
				+ ", BussSeatsFare=" + BussSeatsFare + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((flightno == null) ? 0 : flightno.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Flight other = (Flight) obj;
		if (flightno == null) {
			if (other.flightno != null)
				return false;
		} else if (!flightno.equals(other.flightno))
			return false;
		return true;
	}
	
	public boolean bookFirstSeats(int fSeats)
	{
		if(firstAvail>=fSeats)
		{
			firstAvail=firstAvail-fSeats;
			return true;
		}
		else return false;
		
	}
	public boolean bookBussSeats(int bSeats)
	{
		if(bSeatsAvail>=bSeats)
		{
			bSeatsAvail=bSeatsAvail-bSeats;
			return true;
		}
		else return false;
		
	}
	public boolean cancelFirstSeats(int fSeats)
	{
		if(fSeats<firstAvail)
		{
			firstAvail=firstAvail+fSeats;
			return true;
		}
		else return false;
		
	}
	public boolean cancelBussSeats(int bSeats)
	{
		if(bSeats<bSeatsAvail)
		{
			bSeatsAvail=bSeatsAvail+bSeats;
			return true;
		}
		else return false;
		
	}
}
