package com.capgemini.ars.utlities;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;
import java.util.logging.Logger;

public class ProjectProperties {
	private static Properties projprops;
	private static Logger myLogger =  Logger.getLogger("CoreCustomer040");
	
	static{
		projprops = new Properties();
		try {
			FileReader reader = new FileReader("config/project.properties");
			projprops.load(reader);
			myLogger.info("Properties are populated");
		} catch (FileNotFoundException e) {
			myLogger.severe(e.getMessage());
		} catch (IOException e) {
			myLogger.severe(e.getMessage());
		}
	}
	
	public static String getProperty(String key){
		return projprops.getProperty(key);
	}

	//It is for the purpose of testing
	public static void main(String[] args) { 
		System.out.println(ProjectProperties.getProperty("url"));
	}
}
