package com.capgemini.ars.utlities;

import java.sql.SQLException;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.capgemini.ars.exceptions.FlightException;
import oracle.jdbc.pool.OracleDataSource;

public class DatasourceFactory {
	private OracleDataSource ds;
	private static Logger myLogger =  Logger.getLogger("Airline Reservation Software");

	public DatasourceFactory() throws FlightException {
		try {
			ds = new OracleDataSource();
		} catch (SQLException e) {
			myLogger.fatal("creation of factory failed.");
			throw new FlightException("creation of factory failed.");
		}
		ds.setURL(ProjectProperties.getProperty("url"));
		ds.setUser(ProjectProperties.getProperty("userName"));
		ds.setPassword(ProjectProperties.getProperty("password"));
		ds.setDriverType(ProjectProperties.getProperty("driverType"));
		myLogger.info("Datasource created");
	}
	
	public DataSource getDataSource(){
		return ds;
	}
	
}
