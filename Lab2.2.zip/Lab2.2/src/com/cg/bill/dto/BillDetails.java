package com.cg.bill.dto;

import java.time.LocalDate;

public class BillDetails {

	private long bno;
	private long cno;
	private double currReading;
	private double unitConsumed;
	private double netAmount;
	private LocalDate date;
	public long getBno() {
		return bno;
	}
	public void setBno(long bno) {
		this.bno = bno;
	}
	public long getCno() {
		return cno;
	}
	public void setCno(long cno) {
		this.cno = cno;
	}
	public double getCurrReading() {
		return currReading;
	}
	public void setCurrReading(double currReading) {
		this.currReading = currReading;
	}
	public double getUnitConsumed() {
		return unitConsumed;
	}
	public void setUnitConsumed(double unitConsumed) {
		this.unitConsumed = unitConsumed;
	}
	public double getNetAmount() {
		return netAmount;
	}
	public void setNetAmount(double netAmount) {
		this.netAmount = netAmount;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	@Override
	public String toString() {
		return "BillDetails [bno=" + bno + ", cno=" + cno + ", currReading="
				+ currReading + ", unitConsumed=" + unitConsumed
				+ ", netAmount=" + netAmount + ", date=" + date + "]";
	}
	public BillDetails(long bno, long cno, double currReading,
			double unitConsumed, double netAmount, LocalDate date) {
		super();
		this.bno = bno;
		this.cno = cno;
		this.currReading = currReading;
		this.unitConsumed = unitConsumed;
		this.netAmount = netAmount;
		this.date = date;
	}
	public BillDetails(long bno, double currReading,
			double unitConsumed, double netAmount, LocalDate date) {
		super();
		this.bno = bno;
		this.currReading = currReading;
		this.unitConsumed = unitConsumed;
		this.netAmount = netAmount;
		this.date = date;
	}
	public BillDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
