package com.cg.bill.dto;

public class Consumer {

	private long cNo;
	private String cName;
	private String address;
	public Consumer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public long getcNo() {
		return cNo;
	}
	@Override
	public String toString() {
		return "Consumer [cNo=" + cNo + ", cName=" + cName + ", address=" + address + "]";
	}
	public Consumer(long cNo, String cName, String address) {
		super();
		this.cNo = cNo;
		this.cName = cName;
		this.address = address;
	}
	public void setcNo(long cNo) {
		this.cNo = cNo;
	}
	public String getcName() {
		return cName;
	}
	public void setcName(String cName) {
		this.cName = cName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
}
