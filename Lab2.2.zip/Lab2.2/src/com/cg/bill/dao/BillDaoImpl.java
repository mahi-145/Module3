package com.cg.bill.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import com.cg.bill.dto.BillDetails;
import com.cg.bill.dto.Consumer;
import com.cg.bill.exception.BillException;
import com.cg.mpa.dbutil.DBUtil;


public class BillDaoImpl implements BillDao {

	Connection con = null;
	Statement st = null;
	ResultSet rs = null;
	PreparedStatement pst = null;
	
	
	@Override
	public List<Consumer> getAllConsumers() throws BillException {
		
		List<Consumer> clist = new ArrayList<>();
		
		con = com.cg.mpa.dbutil.DBUtil.getCon();
		String qry = "Select * from consumers";
		Consumer cus = null;
		try {
			st = con.createStatement();
			rs = st.executeQuery(qry);
			while(rs.next()) {
				cus = new Consumer(rs.getLong(1), rs.getString(2), rs.getString(3));
				clist.add(cus);
			}
		}
		catch (Exception e) {
			throw new BillException("Error while fetching consumers");
		}
		
		return clist;
	}

	@Override
	public Consumer getConsumer(long cnum) throws BillException {
		String qry = "select * from consumers where consumer_num=?";
		Consumer consumer = null;
		
		con = DBUtil.getCon();
		try {
			pst = con.prepareStatement(qry);
			pst.setLong(1, cnum);
			rs = pst.executeQuery();
			
			if(rs.next()) {
				consumer = new Consumer();
				consumer.setcNo(rs.getLong(1));
				consumer.setcName(rs.getString(2));
				consumer.setAddress(rs.getString(3));
			}
			else{
				throw new BillException("Error");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new BillException("Invalid Consumer number");
		}
		
		return consumer;
	}

	@Override
	public BillDetails getBillDetail(long cnum) throws BillException {
		String qry = "select * from billdetails where consumer_num=?";
		BillDetails bill = null;
		
		con = DBUtil.getCon();
		try {
			pst = con.prepareStatement(qry);
			pst.setLong(1, cnum);
			rs = pst.executeQuery();
			
			while(rs.next()) {
				bill = new BillDetails(rs.getLong(1),rs.getLong(2),rs.getDouble(3),rs.getDouble(4),
						rs.getDouble(5),rs.getDate(6).toLocalDate());
			}
		} catch (SQLException e) {
			throw new BillException("No bill info present for " + cnum);
		}
		
		return bill;
	}

	@Override
	public int addBillDetail(BillDetails bill) throws BillException {
		String qry = "insert into billdetails values(?,?,?,?,?,?)";
		
		con = DBUtil.getCon();
		int inserted = 0;
		try {
			pst = con.prepareStatement(qry);
			
			pst.setLong(1, generateBillNo());
			pst.setDouble(2, bill.getCno());
			pst.setDouble(3, bill.getCurrReading());
			pst.setDouble(4, bill.getUnitConsumed());
			pst.setDouble(5, bill.getNetAmount());
			pst.setDate(6, Date.valueOf(bill.getDate()));
			
			inserted = pst.executeUpdate();
		}
		catch (Exception e) {
			throw new BillException("Error while inserting data for " + bill.getCno());
		}
		
		return inserted;
	}

	private int generateBillNo() throws BillException {
		String qry = "select seq_bill_num.nextval from dual";
		con = DBUtil.getCon();
		int pid = 0;
		try {
			st = con.createStatement();
			rs = st.executeQuery(qry);
			
			rs.next();
			pid = (int) rs.getLong(1);
		} 
		catch (Exception e) {
			 throw new BillException("Problem in generating purchase id" + " " + e.getMessage());
		}
		return pid;
	}

}
