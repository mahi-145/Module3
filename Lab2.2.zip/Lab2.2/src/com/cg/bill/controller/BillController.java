package com.cg.bill.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.bill.dto.BillDetails;
import com.cg.bill.dto.Consumer;
import com.cg.bill.exception.BillException;
import com.cg.bill.service.BillService;
import com.cg.bill.service.BillServiceImpl;


@WebServlet(urlPatterns={"/list","/search","/index","/consumer","/billdetails","/generatebill",
		"/calculatebill"})
public class BillController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public BillController() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String url = request.getServletPath(); // identifying which request is coming 
		String targetUrl = "";
		HttpSession sess = null;
		BillService bser = new BillServiceImpl();

		switch(url) {
		//showing all the consumers list
		case "/list":
			
			try {
				
				List<Consumer> blist = bser.getAllConsumers();
				request.setAttribute("blist", blist);
				targetUrl = "Home.jsp";
			} 
			catch (BillException e) {
				request.setAttribute("error", e.getMessage());
				targetUrl = "Error.jsp";
			}
			
			break;
		
		//welcome page
		case "/index":
				targetUrl = "index.html";
			break;
		//going to show enter consumer page	
		case "/search":
			targetUrl = "SearchConsumer.jsp";
			break;
		
		//searching a consumer based on consumer_num
		case "/consumer":
			
			String num = request.getParameter("cnum");
			long cnum = Long.valueOf(num);
			
			try {
				Consumer con = bser.getConsumer(cnum);
				System.out.println(con);
				request.setAttribute("consumer", con);
				targetUrl = "SingleConsumer.jsp";
			}
			catch (BillException e) {
				request.setAttribute("error", e.getMessage());
				targetUrl = "Error.jsp";
			}
			break;
		
		//shwoing bill details
		case "/billdetails":
			
			long cnumber = Long.valueOf(request.getParameter("cno"));
			System.out.println("consumer no: "+cnumber);
	
			try {
				BillDetails bill = bser.getBillDetail(cnumber); 
				System.out.println(bill);
				request.setAttribute("bill", bill);
				targetUrl = "Bill.jsp";
			}
			catch (BillException e) {

				request.setAttribute("error", e.getMessage());
				targetUrl = "Error.jsp";
				
			}
			
			break;
			
		//setting consumer id in session
		case "/generatebill":
			
			Long con =  Long.parseLong(request.getParameter("cno"));
			sess = request.getSession(true);
			sess.setAttribute("cnum", con);//setting consumer no in the session 
		
			targetUrl = "GenerateBill.jsp";
		break;
			
		//calculating bill , inserting data in billdetails and getting the details by using consumer id
		//and showing the result
		case "/calculatebill":
			
			long cn = Long.valueOf(request.getParameter("cno"));
			Double cmr = Double.valueOf(request.getParameter("cmr"));
			Double lmr = Double.valueOf(request.getParameter("lmr"));
			
			Double unitConsumed = lmr-cmr;
			Double netAmount = unitConsumed * 1.15 + 100;
			sess = request.getSession(false);
			
			Long cno = (Long)sess.getAttribute("cnum");
			System.out.println("consumer no = " + cno);
			
			BillDetails bill = new BillDetails();
			
			bill.setCno(cno);
			bill.setCurrReading(cmr);
			bill.setUnitConsumed(unitConsumed);
			bill.setNetAmount(netAmount);
			bill.setDate(LocalDate.now());
			
			try {
				int id = bser.addBillDetail(bill);
				System.out.println("is: "+id);
				
				if(id == 1) {
					BillDetails bill2 = bser.getBillDetail(cno);
					System.out.println("bill 2 details after adding"+bill2);
					request.setAttribute("bill2", bill2);
					targetUrl = "Final.jsp";
				}
				else{
					request.setAttribute("error", "Error while inserting data");
					targetUrl = "Error.jsp";
				}
			}
			catch (BillException e) {
				
				request.setAttribute("error", e.getMessage());
				targetUrl = "Error.jsp";
			}
			break;
		}
		
		RequestDispatcher rd = request.getRequestDispatcher(targetUrl);
		rd.forward(request, response);
	}

}
