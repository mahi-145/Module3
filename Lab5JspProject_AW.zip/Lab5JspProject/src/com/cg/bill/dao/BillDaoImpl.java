package com.cg.bill.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.bill.dto.BillDetails;
import com.cg.bill.dto.BillHistory;
import com.cg.bill.dto.Consumers;
import com.cg.bill.exception.BillException;
import com.cg.bill.util.DbUtil;

public class BillDaoImpl implements BillDao
{
	Connection conn=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	
	@Override
	public List<Consumers> getAllConsumers() throws BillException 
	{
		List<Consumers> cList=new ArrayList<>();
		
		try 
		{
			conn=DbUtil.getConn();
			st=conn.createStatement();
			rs=st.executeQuery(QueryMapper.SELECT_LIST_CONSUMERS);
			while(rs.next())
			{
				Consumers consumer=new Consumers();
				consumer.setConsumerNum(rs.getInt("consumer_num"));
				consumer.setConsumerName(rs.getString("consumer_name"));
				consumer.setAddress(rs.getString("address"));
				
				cList.add(consumer);
			}
			
			
		}
		catch (SQLException e) 
		{
		
			throw new BillException("Problem in fetching Consumer List");
		}
		
		
		return cList;
	}

	@Override
	public Consumers getConsumerDetails(long consumerNum) throws BillException 
	{
		Consumers consumer=new Consumers();
		try
		{
			conn=DbUtil.getConn();
			pst=conn.prepareStatement(QueryMapper.SEARCH_CONSUMER);
			pst.setLong(1, consumerNum);
			rs=pst.executeQuery();
			rs.next();
			consumer=new Consumers(rs.getLong("consumer_num"), rs.getString("consumer_name"), rs.getString("address") );
			
			
		}
		 catch (SQLException e) 
		{
		//	e.printStackTrace();
			throw new BillException("Problem in searching consumer");
		}
		return consumer;
	}

	@Override
	public BillDetails getBillingDetails(long consumerNum) throws BillException 
	{
		BillDetails bh=new BillDetails();
		try
		{
			conn=DbUtil.getConn();
			pst=conn.prepareStatement(QueryMapper.FETCH_BILLDETAILS);
			pst.setLong(1, consumerNum);
			rs=pst.executeQuery();
			rs.next();
			bh=new BillDetails(rs.getInt(1), rs.getLong(2), rs.getFloat(3), rs.getFloat(4), rs.getFloat(5), rs.getDate(6).toLocalDate());
			
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			throw new BillException("Problem in fetching bill details");
		}
		return bh;
	}

	@Override
	public long generateBillNumber() throws BillException 
	{
		long bId=0;
		conn=DbUtil.getConn();
		try
		{
			st=conn.createStatement();
			rs=st.executeQuery(QueryMapper.BILL_SEQUENCE);
			rs.next();
			bId=rs.getLong(1);
			
		}
		catch (SQLException e) 
		{
			throw new BillException("Problem in generating Bill Number");
		}
		
		return bId;
	}

	@Override
	public long insertBillDetails(BillDetails bDetails) throws BillException
	{
		conn=DbUtil.getConn();
		bDetails.setBillNum(generateBillNumber());
		try 
		{
			System.out.println("consumer no" + bDetails.getConsumerNum());
			PreparedStatement pst=conn.prepareStatement(QueryMapper.INSERT_QUERY);
			pst.setLong(1,bDetails.getBillNum());
			pst.setLong(2, bDetails.getConsumerNum());
			pst.setFloat(3,bDetails.getCurrReading());
			pst.setFloat(4,bDetails.getUnitConsumed());
			pst.setFloat(5,bDetails.getNetAmount());
			pst.setDate(6,Date.valueOf(bDetails.getDate()));
			pst.executeUpdate();
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
			throw new BillException("Problem in inserting data");
		}
		return bDetails.getBillNum();

	}
	
	
	
}
