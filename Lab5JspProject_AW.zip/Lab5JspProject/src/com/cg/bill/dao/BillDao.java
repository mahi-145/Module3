package com.cg.bill.dao;

import java.util.List;

import com.cg.bill.dto.BillDetails;
import com.cg.bill.dto.BillHistory;
import com.cg.bill.dto.Consumers;
import com.cg.bill.exception.BillException;


public interface BillDao
{
	List<Consumers>getAllConsumers() throws BillException;
	Consumers getConsumerDetails(long consumerNum) throws BillException;
	BillDetails getBillingDetails(long consumerNum) throws BillException;
	long generateBillNumber() throws BillException;
	long insertBillDetails(BillDetails bDetails) throws BillException;
}
