package com.cg.bill.dao;

public interface QueryMapper 
{
	String SELECT_LIST_CONSUMERS="select * from Consumers";
	String SEARCH_CONSUMER="select * from Consumers where consumer_num=?";
	String FETCH_BILLDETAILS="select * from billdetails where consumer_num=?";
	String BILL_SEQUENCE="Select seq_bill_num.NEXTVAL from dual";
	String INSERT_QUERY="insert into billdetails values(?,?,?,?,?,?)";

}
