package com.cg.bill.util;

import java.sql.Connection;

import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.cg.bill.exception.BillException;
public class DbUtil 
{
	
	public static Connection getConn() throws BillException
	{
		Connection conn = null;
		InitialContext context;
	//	conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
		try 
		{
			context=new InitialContext();
			DataSource ds=(DataSource)context.lookup("java:/JDBC/OracleDS");
			conn=ds.getConnection();
		}
		catch (Exception e) 
		{
			throw new BillException(e.getMessage());
		}
		return conn;
	}
	
}
