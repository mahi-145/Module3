package com.cg.bill.service;

import java.util.List;

import com.cg.bill.dao.BillDao;
import com.cg.bill.dao.BillDaoImpl;
import com.cg.bill.dto.BillDetails;
import com.cg.bill.dto.BillHistory;
import com.cg.bill.dto.Consumers;
import com.cg.bill.exception.BillException;

public class BillServiceImpl implements BillService
{
	BillDao billDao=new BillDaoImpl();
	
	@Override
	public List<Consumers> getAllConsumers() throws BillException
	{
		//System.out.println(billDao.getAllConsumers());
		return billDao.getAllConsumers();
	}

	@Override
	public Consumers getConsumerDetails(long consumerNum) throws BillException 
	{
		return billDao.getConsumerDetails(consumerNum);
	}

	@Override
	public BillDetails getBillingDetails(long consumerNum) throws BillException
	{
		
		return billDao.getBillingDetails(consumerNum);
	}

	@Override
	public long insertBillDetails(BillDetails bDetails) throws BillException
	{
		
		return billDao.insertBillDetails(bDetails);
	}
	
}
