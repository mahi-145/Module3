package com.cg.bill.dto;

public class BillHistory
{
	private int billNumber;
	private long consumerNum;
	public long getConsumerNum() {
		return consumerNum;
	}
	public void setConsumerNum(long consumerNum) {
		this.consumerNum = consumerNum;
	}
	private String month;
	private int meterReading;
	private int unitConsumed;
	private float billAmount;
	public int getBillNumber() {
		return billNumber;
	}
	public void setBillNumber(int billNumber) {
		this.billNumber = billNumber;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public int getMeterReading() {
		return meterReading;
	}
	public void setMeterReading(int meterReading) {
		this.meterReading = meterReading;
	}
	public int getUnitConsumed() {
		return unitConsumed;
	}
	public void setUnitConsumed(int unitConsumed) {
		this.unitConsumed = unitConsumed;
	}
	public float getBillAmount() {
		return billAmount;
	}
	public void setBillAmount(float billAmount) {
		this.billAmount = billAmount;
	}

	public BillHistory() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "BillHistory [billNumber=" + billNumber + ", consumerNum="
				+ consumerNum + ", month=" + month + ", meterReading="
				+ meterReading + ", unitConsumed=" + unitConsumed
				+ ", billAmount=" + billAmount + "]";
	}
	public BillHistory(int billNumber, long consumerNum, String month,
			int meterReading, int unitConsumed, float billAmount) {
		super();
		this.billNumber = billNumber;
		this.consumerNum = consumerNum;
		this.month = month;
		this.meterReading = meterReading;
		this.unitConsumed = unitConsumed;
		this.billAmount = billAmount;
	}
	
	
}
