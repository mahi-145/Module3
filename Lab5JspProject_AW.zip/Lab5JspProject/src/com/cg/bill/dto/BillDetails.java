package com.cg.bill.dto;

import java.time.LocalDate;

public class BillDetails
{
	private long billNum;
	private long consumerNum;
	private float currReading;
	private float unitConsumed;
	private float netAmount;
	LocalDate date;
	
	public long getBillNum() 
	{
		return billNum;
	}
	public void setBillNum(long billNum) 
	{
		this.billNum = billNum;
	}
	public long getConsumerNum() 
	{
		return consumerNum;
	}
	public void setConsumerNum(long consumerNum) 
	{
		this.consumerNum = consumerNum;
	}
	public float getCurrReading() 
	{
		return currReading;
	}
	public void setCurrReading(float currReading) 
	{
		this.currReading = currReading;
	}
	public float getUnitConsumed() 
	{
		return unitConsumed;
	}
	public void setUnitConsumed(float unitConsumed) 
	{
		this.unitConsumed = unitConsumed;
	}
	public float getNetAmount() 
	{
		return netAmount;
	}
	public void setNetAmount(float netAmount) 
	{
		this.netAmount = netAmount;
	}
	public LocalDate getDate() 
	{
		return date;
	}
	public void setDate(LocalDate date) 
	{
		this.date = date;
	}
	public BillDetails(long billNum, long consumerNum, float currReading,
			float unitConsumed, float netAmount, LocalDate date) {
		super();
		this.billNum = billNum;
		this.consumerNum = consumerNum;
		this.currReading = currReading;
		this.unitConsumed = unitConsumed;
		this.netAmount = netAmount;
		this.date = date;
	}
	public BillDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "BillDetails [billNum=" + billNum + ", consumerNum="
				+ consumerNum + ", currReading=" + currReading
				+ ", unitConsumed=" + unitConsumed + ", netAmount=" + netAmount
				+ ", date=" + date + "]";
	}
	
	
}
