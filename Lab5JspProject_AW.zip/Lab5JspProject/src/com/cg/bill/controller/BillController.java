package com.cg.bill.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

import javax.security.auth.message.callback.PrivateKeyCallback.Request;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.bill.dto.BillDetails;
import com.cg.bill.dto.BillHistory;
import com.cg.bill.dto.Consumers;
import com.cg.bill.exception.BillException;
import com.cg.bill.service.BillService;
import com.cg.bill.service.BillServiceImpl;


@WebServlet(urlPatterns={"/BillController","/List","/Search","/BillDetails","/GenerateBill"})
public class BillController extends HttpServlet {

	private static final long serialVersionUID = 1L;

	public BillController() 
	{
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String url=request.getServletPath();
		String targetUrl="";
		BillService billSer=new BillServiceImpl();
		System.out.println(url);
		switch(url)
		{
		case "/List":
			try 
			{
				List<Consumers> cList=billSer.getAllConsumers();
				request.setAttribute("clist", cList);
				targetUrl="List.jsp";
			} 
			catch (BillException e) 
			{
				request.setAttribute("error", e.getMessage());
				targetUrl="Error.jsp";
			}
			break;
			
		case "/Search":
				try
				{
				//	System.out.println("Hello");
					long cNum=Long.parseLong(request.getParameter("consumerno"));
					//Consumers consumer=new Consumers();
					 Consumers consumer=billSer.getConsumerDetails(cNum);
					request.setAttribute("cDetails", consumer);
					targetUrl="Success.jsp";
				
					
				}
				catch(BillException e)
				{
					request.setAttribute("error", e.getMessage());
					targetUrl="Error.jsp";
				}
			break;
			
		case "/BillDetails":
				try
				{
					long cNum=Long.parseLong(request.getParameter("cno"));
					BillDetails bd =billSer.getBillingDetails(cNum);
					request.setAttribute("cDetails", bd);
				//	request.getAttribute("cDetails")
					targetUrl="billDetails.jsp";
				}
				catch(BillException e)
				{
					request.setAttribute("error", e.getMessage());
					targetUrl="Error.jsp";
				}
			break;
			
		case "/GenerateBill":
					long cNum=Long.parseLong(request.getParameter("consumerno"));
					System.out.println(cNum);
					float lastMonth=Float.parseFloat(request.getParameter("lastmonth"));
					float currMonth=Float.parseFloat(request.getParameter("currMonth"));
					float units=lastMonth+currMonth;
					
					float bill=(float) (((currMonth-lastMonth)*1.25)+100);
//					long custNum=Long.parseLong(request.getParameter("cno"));
					
					BillDetails bdetails=new BillDetails();
					bdetails.setConsumerNum(cNum);
					bdetails.setCurrReading(currMonth);
					bdetails.setUnitConsumed(units);
					bdetails.setNetAmount(bill);
					bdetails.setDate(LocalDate.now());
					
					try
					{
						long dataAdded=0;
						dataAdded=billSer.insertBillDetails(bdetails);
						if(dataAdded>0)
						{
							BillDetails bd =billSer.getBillingDetails(cNum);
							request.setAttribute("cDetails", bd);
							//	request.getAttribute("cDetails")
								targetUrl="Final.jsp";
							
						}
					}
					catch(BillException e)
					{
						request.setAttribute("error", e.getMessage());
						targetUrl="Error.jsp";
					}
			break;
				
		}
		RequestDispatcher rd = request.getRequestDispatcher(targetUrl);
		rd.forward(request, response);
	}
	

}
