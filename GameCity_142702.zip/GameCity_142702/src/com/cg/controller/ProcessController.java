package com.cg.controller;

import java.io.IOException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.cg.dto.GameBean;
import com.cg.dto.UserBean;
import com.cg.exception.GameException;
import com.cg.service.*;

@WebServlet(urlPatterns={"/buycard","/Success"})
public class ProcessController extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       

    public ProcessController()
    {
        super();
        
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException 
	{
		String url = request.getServletPath(); // identifying which request is coming 
		String targetUrl = "";
		HttpSession sess = null;
		ProcessService pSer=new ProcessServiceImpl();
		switch(url)
		{
		case"/buycard":	
			int amt=Integer.parseInt(request.getParameter("amount"));
			if(amt>500 && amt<2000)
			{
				String name=request.getParameter("unm");
				String address=request.getParameter("add");
				int amount=Integer.valueOf(request.getParameter("amount"));
				int currBal=amount-100;
				sess = request.getSession(false);
				UserBean user=new UserBean();
				
				user.setuName(name);
				user.setAddress(address);
				user.setCardAmt(currBal);
				try
				{
					int uid = 0;
					uid=pSer.addUserDetails(user);	
					List<GameBean>glist= pSer.getAllGames();
					request.setAttribute("glist",glist);
					targetUrl="Play.jsp";
				}
				catch (GameException e)
				{	
					request.setAttribute("error", e.getMessage());
					targetUrl = "Topup.jsp";
					e.printStackTrace();
				}
			}
			break;
		case "/Success":
			GameBean gb=new GameBean();
			int gameamt=gb.getgamt();
			String nm=request.getParameter("gnm");
			request.setAttribute("name",nm);
			int card_amt=Integer.valueOf(request.getParameter("amount"))-100;
			int balance=card_amt-gameamt;
			request.setAttribute("gbal",balance);		
			targetUrl="Success.jsp";
			break;
		}
		RequestDispatcher rd = request.getRequestDispatcher(targetUrl);
		rd.forward(request, response);
	}

}
