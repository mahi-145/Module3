package com.cg.util;

import java.sql.Connection;

import javax.naming.InitialContext;
import javax.sql.DataSource;
import com.cg.exception.GameException;

public class DBUtil 
{
public static Connection getCon() throws GameException 
{
		
		Connection con = null;
		InitialContext context;
		try 
		{
			context = new InitialContext();
			DataSource ds = (DataSource) context.lookup("java:/jdbc/OracleDS");
			con = ds.getConnection();
		}
		catch (Exception e)
		{
			throw new GameException(e.getMessage());
		}	
		return con;
	}
}
