package com.cg.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import com.cg.dto.GameBean;
import com.cg.dto.UserBean;
import com.cg.exception.GameException;
import com.cg.util.DBUtil;

public class ProcessDaoImpl implements ProcessDao
{
	Connection con=null;
	Statement st=null;
	@Override
	public List<GameBean> getAllGames() throws GameException
	{
		List<GameBean> gList = new ArrayList<>();
		try 
		{
			con=DBUtil.getCon();
			st = con.createStatement();
			ResultSet rs=st.executeQuery(QueryMapper.SELECT_ALL_GAMES);
			while(rs.next())
			{
				GameBean games=new GameBean();
				games.setgname(rs.getString("name"));
				games.setgamt(rs.getInt("amount"));
				gList.add(games);
			}
		}
		catch(SQLException se)
		{
			throw new GameException("Problem in Fetching Games");
		}
		return gList;
	}
	@Override
	public int addUserDetails(UserBean user) throws GameException
	{
		con=DBUtil.getCon();
		PreparedStatement pst;
		int dataAdded=0;
		try 
		{
			pst = con.prepareStatement(QueryMapper.ADD_USER_DETAIL);
			
			pst.setInt(1,generateUserId());
			pst.setString(2,user.getuName());
			pst.setString(3,user.getAddress());
			pst.setInt(4,user.getCardAmt());	
			dataAdded = pst.executeUpdate();
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			//throw new GameException("Error while inserting data for " + user.getuId());
		}
		return dataAdded;
	}
	private int generateUserId()throws GameException
	{
		con = DBUtil.getCon();
		ResultSet rs;
		int uid = 0;
		try {
			st = con.createStatement();
			rs = st.executeQuery(QueryMapper.USER_SEQUENCE);	
			rs.next();
			uid=rs.getInt("user_id");
		} 
		catch (Exception e)
		{
			 throw new GameException("Problem in generating user id" + " " + e.getMessage());
		}
		return uid;
	}
}

