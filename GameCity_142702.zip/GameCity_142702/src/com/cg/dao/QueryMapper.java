package com.cg.dao;

public interface QueryMapper 
{
String SELECT_ALL_GAMES="SELECT * from onlinegames";
String ADD_USER_DETAIL="INSERT INTO users VALUES(?,?,?,?)";
String USER_SEQUENCE="SELECT seq_users.NEXTVAL FROM DUAL";
}
