package com.cg.dao;

import java.util.List;

import com.cg.dto.GameBean;
import com.cg.dto.UserBean;
import com.cg.exception.GameException;

public interface ProcessDao 
{
	public int addUserDetails(UserBean user)throws GameException;
	public List<GameBean> getAllGames() throws GameException;
}
