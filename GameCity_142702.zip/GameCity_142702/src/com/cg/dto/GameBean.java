package com.cg.dto;

public class GameBean 
{
	private String gname;
	private int gamt;
	
	public GameBean() 
	{
		super();
	}

	public GameBean(String gname, int gamt) 
	{
		super();
		this.gname = gname;
		this.gamt = gamt;
	}

	public String getgname()
	{
		return gname;
	}

	public void setgname(String gname) 
	{
		this.gname = gname;
	}

	public int getgamt() 
	{
		return gamt;
	}

	public void setgamt(int gamt) 
	{
		this.gamt = gamt;
	}
	
}
