package com.cg.dto;

public class UserBean 
{
	private int uId;
	private String uName;
	private String address;
	private int cardAmt;
	public int getuId() 
	{
		return uId;
	}
	public void setuId(int uId) 
	{
		this.uId = uId;
	}
	public String getuName() 
	{
		return uName;
	}
	public void setuName(String uName)
	{
		this.uName = uName;
	}
	public String getAddress()
	{
		return address;
	}
	public void setAddress(String address)
	{
		this.address = address;
	}
	public int getCardAmt() 
	{
		return cardAmt;
	}
	public void setCardAmt(int cardAmt)
	{
		this.cardAmt = cardAmt;
	}
	public UserBean(int uId, String uName, String address, int cardAmt) {
		super();
		this.uId = uId;
		this.uName = uName;
		this.address = address;
		this.cardAmt = cardAmt;
	}
	public UserBean()
	{
		super();
	}
	
	
	
}
