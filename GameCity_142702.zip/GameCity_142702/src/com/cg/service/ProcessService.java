package com.cg.service;

import java.util.List;

import com.cg.dto.GameBean;
import com.cg.dto.UserBean;
import com.cg.exception.GameException;

public interface ProcessService
{
	public List<GameBean> getAllGames() throws GameException;
	public int addUserDetails(UserBean user)throws GameException;
}
