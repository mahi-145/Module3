package com.cg.service;

import java.util.List;

import com.cg.dao.*;
import com.cg.dto.GameBean;
import com.cg.dto.UserBean;
import com.cg.exception.GameException;

public class ProcessServiceImpl implements ProcessService
{
	ProcessDao pdao=new ProcessDaoImpl();
	@Override
	public List<GameBean> getAllGames() throws GameException 
	{
		return pdao.getAllGames();
	}
	@Override
	public int addUserDetails(UserBean user) throws GameException 
	{
		return pdao.addUserDetails(user);
	}

}
