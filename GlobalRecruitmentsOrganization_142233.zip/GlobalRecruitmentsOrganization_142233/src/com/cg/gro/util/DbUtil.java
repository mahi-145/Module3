package com.cg.gro.util;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.cg.gro.exception.ContactBookException;

public class DbUtil 
{
	static String dbunm=null;
	static String dbpwd=null;
	static String url=null;


	public static Connection getCon() throws Exception, ContactBookException, SQLException
	{

		Properties dbInfoProps=DbUtil.getProp(); 
		Connection conn=null;

		url=dbInfoProps.getProperty("dbURL");
		dbunm=dbInfoProps.getProperty("dbUser");
		dbpwd=dbInfoProps.getProperty("dbPwd");
		if(conn==null)                        
		{

			conn=DriverManager.getConnection(url,dbunm,dbpwd);

		}
		return conn;
	}

	public static Properties getProp() throws FileNotFoundException,ContactBookException,Exception  //reading the data from property object and returning the property object
	{
		Properties props=null;	
		FileReader fr=null;

		props=new Properties();
		fr=new FileReader("resources/dbInfo.properties");
		props.load(fr);

		return props;

	}

}
