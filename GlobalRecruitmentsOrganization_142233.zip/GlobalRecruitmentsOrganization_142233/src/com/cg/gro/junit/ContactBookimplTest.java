package com.cg.gro.junit;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.gro.bean.EnquiryBean;
import com.cg.gro.dao.ContactBookDao;
import com.cg.gro.dao.ContactBookDaoImpl;
import com.cg.gro.exception.ContactBookException;


public class ContactBookimplTest 
{
	static ContactBookDao enqDao = null;									//static object of Dao interface
	static EnquiryBean enqbean=null;											//static object of enquiry bean class
	
	
	@BeforeClass
	public static void BeforeClass() throws ContactBookException
	{
		enqDao = new ContactBookDaoImpl();							//object of DAO class
		enqbean=new EnquiryBean();											//object of enquiry bean class
	}
	
	@Test
	public void testAddEnquiry() throws ContactBookException
	{
		Assert.assertNotSame(1, enqDao.addEnquiry(enqbean));
	}

	@Test
	public void testAddEnquiry1() throws ContactBookException
	{
		Assert.assertSame(1, enqDao.addEnquiry(enqbean));
	}

	@Test(expected=Exception.class)
	public void testAddEnquiry2() throws ContactBookException
	{
		Assert.assertNotNull( enqDao.addEnquiry(enqbean));
	}
	
	@Test
	public void testViewEnquiry1() throws ContactBookException						//to fetch the inserted id, failed because id does not exist
	{
		Assert.assertSame(1, enqDao.getDetails(1009));
	}
	
	@Test
	public void testViewEnquiry2() throws ContactBookException						//to fetch the inserted id, passed because id does not exist
	{
		Assert.assertNotSame(1, enqDao.getDetails(1001));
	}
	
	
}
