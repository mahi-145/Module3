package com.cg.gro.dao;

import java.util.ArrayList;

import com.cg.gro.bean.EnquiryBean;
import com.cg.gro.exception.ContactBookException;

public interface ContactBookDao 
{
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException;
	public EnquiryBean getEnquiryDetails(int EnquiryID) throws ContactBookException;
	public int generateEnquiryId() throws ContactBookException;
	public ArrayList<EnquiryBean> getDetails(int enqryId) throws ContactBookException; 
	

}
