package com.cg.gro.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import sun.security.pkcs11.Secmod.DbMode;

import com.cg.gro.bean.EnquiryBean;
import com.cg.gro.exception.ContactBookException;
import com.cg.gro.util.DbUtil;




public class ContactBookDaoImpl implements ContactBookDao
{

	Connection conn=null;
	Statement st=null;
	PreparedStatement pst=null;	//for dynamic insertion
	ResultSet rs=null;

	Logger enqLogger=null;

	public ContactBookDaoImpl()
	{
		PropertyConfigurator.configure("resources/log4j.properties");
		enqLogger=enqLogger.getLogger("MobDaoImpl.class");

	}
	

	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException 
	{
		String insertqry="Insert into enquiry values(?,?,?,?,?,?)";
		int id=0;

		try
		{
			conn=DbUtil.getCon();
			pst=conn.prepareStatement(insertqry);
			id = generateEnquiryId();
			pst.setInt(1, id);
			pst.setString(2, enqry.getfName());
			pst.setString(3, enqry.getlName());
			pst.setString(4, enqry.getContactNo());
			pst.setString(5, enqry.getpDomain());
			pst.setString(6, enqry.getpLocation());

			pst.executeUpdate();
			enqLogger.log(Level.INFO, "Enquiry Added:" +enqry);

		}
		catch (Exception e) 
		{
			enqLogger.error("This is exception"+e.getMessage());
			throw new ContactBookException(e.getMessage());
		}
		finally
		{
			try 
			{
				System.out.println(conn);                               					//debug
				conn.close();
				pst.close();
			}
			catch (SQLException e) 
			{
				throw new ContactBookException(e.getMessage());
			}
		}
		return id;
	}

	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryID)
			throws ContactBookException 
	{
		String query="Select * from enquiry where enqryid="+EnquiryID;
		EnquiryBean eq=new EnquiryBean();

		try
		{
			conn=DbUtil.getCon();
			pst=conn.prepareStatement(query);
			rs=pst.executeQuery();
			rs.next();
			eq=new EnquiryBean(rs.getInt(1),rs.getString(2), rs.getString(3), rs.getString(4),rs.getString(5),rs.getString(6));
		}
		catch (Exception e) 
		{
			enqLogger.error("This is exception"+e.getMessage());
			throw new ContactBookException(e.getMessage());
		}
		return eq;
	}




	@Override
	public int generateEnquiryId() throws ContactBookException 
	{
		String query="select enquiries.NEXTVAL FROM DUAL";
		int generatedValue;

		try 
		{
			conn=DbUtil.getCon();
			st=conn.createStatement();
			rs=st.executeQuery(query);

			rs.next();
			generatedValue=rs.getInt(1);
			
		}
		catch (Exception e)
		{
			throw new ContactBookException(e.getMessage());
		} 
		finally
		{
			try
			{
				rs.close();
				st.close();
				conn.close();

			}
			catch (SQLException e) 				//throwing sql exception through employee exception
			{
				throw new ContactBookException(e.getMessage());
			}

		}



		return generatedValue;
	}


	@Override
	public ArrayList<EnquiryBean> getDetails(int enqryId) throws ContactBookException 
	{
		ArrayList<EnquiryBean> enqList=new ArrayList<EnquiryBean>();
		String selQry="select * from enquiry where enqryId=?";

		EnquiryBean m=null;
		try
		{
			conn=DbUtil.getCon();
			pst=conn.prepareStatement(selQry);
			pst.setInt(1, enqryId);
			rs=pst.executeQuery();
			enqLogger.log(Level.INFO, "Enquiry Fetched:" +m);
		
			while(rs.next())
			{
				m=new EnquiryBean(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4),rs.getString(5),rs.getString(6));
				enqList.add(m);
			}

	
		}
		catch(Exception e)
		{
			throw new ContactBookException(e.getMessage());
		}
		finally
		{
			try
			{
				conn.close();
				rs.close();
				pst.close();
			}
			catch(Exception e)
			{
				throw new ContactBookException(e.getMessage());
			}
		}
		return enqList;
	}
}




