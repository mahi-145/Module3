package com.cg.gro.ui;

import java.util.ArrayList;
import java.util.Scanner;

import sun.java2d.pipe.ValidatePipe;
import javafx.scene.transform.Scale;

import com.cg.gro.bean.EnquiryBean;
import com.cg.gro.exception.ContactBookException;
import com.cg.gro.service.ContactBookService;
import com.cg.gro.service.ContactBookServiceImpl;


public class Client 
{
	static ContactBookService conBook=null;
	static Scanner sc=null;

	public static void main(String[] args) 
	{
		conBook=new ContactBookServiceImpl();
		sc=new Scanner(System.in);

		while(true)
		{
			System.out.println("*********Global Recruitments*********");
			System.out.println("Choose an operation");
			System.out.println("1. Enter Enquiry Details");
			System.out.println("2. View Enquiry Details on ID");
			System.out.println("0. Exit");
			System.out.println("***********");
			System.out.println("Please Enter a choice");

			int choice = sc.nextInt();
			switch(choice)
			{
			case 1: addDetails();
			break;
			case 2: viewDetails();
			break;
			default:System.out.println("Thank You for selecting us!!");
						System.exit(0);	
			break;
			}

		}




	}

	public static void viewDetails()
	{
		System.out.println("Enter the Enquiry Number");
		int enqryId=sc.nextInt();

		EnquiryBean enqbean=new EnquiryBean();
		try
		{
//			ArrayList<EnquiryBean> list=conBook.getDetails(enqryId);
//			System.out.println("Id	" + " First Name	" + "    Last Name 	" + "   contactNo		" + "   Preffered Domain		" + "  Preffered Location " );
//			if(list.size()>0)
//			{
//				for(EnquiryBean eList:list)
//				{
//					System.out.println(eList);
//				}
//			}
//			else
//			{
//				System.out.println("Sorry does not exist");
//			}
			 enqbean = conBook.getEnquiryDetails(enqryId);
			 System.out.println(enqbean);
		}
		catch (ContactBookException e) 
		{
	
			System.out.println(("Sorry cannot show you information"));
		}

	}

	//		enqbean.getfName();
	//		enqbean.getlName();
	//		enqbean.getContactNo();
	//		enqbean.getpDomain();
	//		enqbean.getpLocation();
	//		
	//		
	//	}

	public static void addDetails() 
	{

		try
		{
			System.out.println("Enter first Name");
			String fName=sc.next();
			if(conBook.validateName(fName))
			{
				System.out.println("Enter last Name");
				String lName=sc.next();
				if(conBook.validateLName(lName))
				{
					System.out.println("Enter Contact Number");
					String conNo=sc.next();
					if(conBook.validatePhone(conNo))
					{
						System.out.println("Enter Preferred Domain");
						String pDomain=sc.next();
						if(conBook.validateDomain(pDomain))
						{
							System.out.println("Enter Preffered Location");
							String pLocation=sc.next();
							if(conBook.validateLocation(pLocation))
							{
								EnquiryBean enqBean = new EnquiryBean();
								enqBean.setfName(fName);
								enqBean.setlName(lName);
								enqBean.setContactNo(conNo);
								enqBean.setpDomain(pDomain);
								enqBean.setpLocation(pLocation);
								//	int eId=enqBean.getEnqryId();
								int dataAdded=conBook.addEnquiry(enqBean);
								if(dataAdded==1)
								{
									System.out.println("Thank You "+fName +" " + lName +" we will contact you shortly");
									//	System.out.println(eId);
								}
								else
								{
									System.out.println("Sorry Could not add data");
								}
							}
						}
						else
						{
							System.out.println("Value must be entered");
						}
					}
				}
			}
		}


		catch (ContactBookException e) 
		{
			System.out.println(e.getMessage());
		}
	}
}

