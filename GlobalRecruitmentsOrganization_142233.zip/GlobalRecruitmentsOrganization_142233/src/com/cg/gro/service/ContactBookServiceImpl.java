package com.cg.gro.service;

import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.gro.bean.EnquiryBean;
import com.cg.gro.dao.ContactBookDao;
import com.cg.gro.dao.ContactBookDaoImpl;
import com.cg.gro.exception.ContactBookException;

public class ContactBookServiceImpl implements ContactBookService
{
	ContactBookDao conBookDao=null;
	
	public ContactBookServiceImpl() 
	{
		conBookDao = new ContactBookDaoImpl();
	}
	
	
	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException 
	{
		return conBookDao.addEnquiry(enqry);
	}


	@Override
	public int generateEnquiryId() throws ContactBookException 
	{
		return conBookDao.generateEnquiryId();
	}


	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryID)
			throws ContactBookException 
	{
		return conBookDao.getEnquiryDetails(EnquiryID);
	}


	@Override
	public ArrayList<EnquiryBean> getDetails(int id) throws ContactBookException 
	{
		return conBookDao.getDetails(id);
	}



		public boolean validatePhone(String phoneNo) throws ContactBookException 
		{
			String phonePattern="[7-9][0-9]{9}";
			if(Pattern.matches(phonePattern, phoneNo))
			{
				return true;
			}
			else
			{
				throw new ContactBookException("Please enter Valid Mobile Number");
			}
		}

		public boolean validateName(String fName) throws ContactBookException 
		{
			String namePattern="[A-Z][a-z]{1,20}";
			if(Pattern.matches(namePattern, fName))
			{	
				return true;
			}
			else
			{
				throw new ContactBookException("Only first Character must be capital value");
			}
		}

		public boolean validateLName(String lName) throws ContactBookException 
		{
			String namePattern="[A-Z][a-z]{1,20}";
			if(Pattern.matches(namePattern, lName))
			{	
				return true;
			}
			else
			{
				throw new ContactBookException("Only first Character must be capital value ");
			}
		}

		public boolean validateLocation(String location) throws ContactBookException 
		{
			String namePattern="[A-Z][a-z]{1,20}";
			if(Pattern.matches(namePattern, location))
			{	
				return true;
			}
			else
			{
				throw new ContactBookException("Only first Character must be capital value ");
			}
		}

		public boolean validateDomain(String domain) throws ContactBookException 
		{
			String namePattern="[A-Z][a-z]{1,20}";
			if(Pattern.matches(namePattern, domain))
			{	
				return true;
			}
			else
			{
				throw new ContactBookException("Only first Character must be capital value");
			}
		}



	
	
	
}
