package com.cg.gro.service;

import java.util.ArrayList;

import com.cg.gro.bean.EnquiryBean;
import com.cg.gro.exception.ContactBookException;


public interface ContactBookService
{
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException;
	public int generateEnquiryId() throws ContactBookException;
	public EnquiryBean getEnquiryDetails(int EnquiryID) throws ContactBookException;
	public ArrayList<EnquiryBean> getDetails(int id) throws ContactBookException; 
	public boolean validatePhone(String phoneNo) throws ContactBookException;	
	public boolean validateName(String fName) throws ContactBookException ;
	public boolean validateLName(String lName) throws ContactBookException; 
	public boolean validateLocation(String location) throws ContactBookException; 
	public boolean validateDomain(String domain) throws ContactBookException; 


	
}
