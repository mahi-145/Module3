package com.cg.admin.dao;

import java.sql.Statement;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.management.Query;

import com.cg.admin.dto.BookingInformation;
import com.cg.admin.exception.AdminException;
import com.cg.admin.exception.BookingException;
import com.cg.admin.util.DBUtil;

public class BookingInfoDaoImpl implements BookingInfoDao 
{
	Connection conn;
	

	@Override
	public int countBookingIds(int fno) throws AdminException 
	{
		int count=0;
		PreparedStatement pst;
		ResultSet rs=null;
		try {
			conn=DBUtil.getCon();
			pst = conn.prepareStatement(QueryMapper.BOOKINGS_FOR_SPECIFIC_FLIGHT);
			pst.setInt(1, fno);
			rs=pst.executeQuery();
			rs.next();
			count=rs.getInt("No_Of_Bookings");
		} 
		catch (Exception e) 
		{
			throw new AdminException("Problem in counting booking id"+e.getMessage());
		} 
		return count;
	}

	@Override
	public List<BookingInformation> getAllBookings(int flightNo)
			throws AdminException 
	{

		List<BookingInformation> bookList=new ArrayList<BookingInformation>();
		try 
		{
			conn=DBUtil.getCon();
			PreparedStatement pst = conn.prepareStatement(QueryMapper.SELECT_BOOKING_INFO);
			pst.setInt(1, flightNo);
			ResultSet rs = pst.executeQuery();
			while(rs.next())
			{
				BookingInformation bi=new BookingInformation();
				
				bi.setBookingId(rs.getInt("BookingId"));
				bi.setCustEmail(rs.getString("CustEmail"));
				bi.setNoOfPassengers(rs.getInt("NoOfPassengers"));
				bi.setClassType(rs.getString("ClassType"));
				bi.setTotalFare(rs.getDouble("TotalFare"));
				bi.setSeatNumber(rs.getString("SeatNumber"));
				bi.setCreditCardInfo(rs.getString("creditCardInfo"));
				bi.setSrcCity(rs.getString("SrcCity"));
				bi.setDestCity(rs.getString("DestCity"));
				bi.setFlightNo(rs.getInt("FlightNo"));
				bookList.add(bi);
				
			}
		} 
		catch (Exception e) 
		{
			throw new AdminException("Problem in Fetching Booking list "+e.getMessage());
		}
		
		return bookList;
		
	}

	@Override
	public int addNewBookingInformation(BookingInformation bookInfo)
			throws BookingException 
	{
		int id=0;
		try
		{
			conn=DBUtil.getCon();
			PreparedStatement pst= conn.prepareStatement(QueryMapper.INSERT_BOOKING_INFO);
			id=generateBookingId();
			pst.setInt(1, id);
			pst.setString(2, bookInfo.getCustEmail());
			pst.setInt(3, bookInfo.getNoOfPassengers());
			pst.setString(4, bookInfo.getClassType());
			pst.setDouble(5, bookInfo.getTotalFare());
			pst.setString(6, bookInfo.getSeatNumber());
			pst.setString(7, bookInfo.getCreditCardInfo());
			pst.setString(8, bookInfo.getSrcCity());
			pst.setString(9, bookInfo.getDestCity());
			pst.setInt(10, bookInfo.getFlightNo());
			pst.executeUpdate();
						
			return id;

		}
		catch(SQLException | IOException e)
		{
			throw new BookingException("Problem in inserting booking details of customer");
		}
	}
	
	
	public int generateBookingId() throws BookingException
	{
		int generatedId=0;
		Statement st=null;
		ResultSet rs=null;
		
		try
		{
			conn=DBUtil.getCon();
			st=conn.createStatement();
			rs=st.executeQuery(QueryMapper.SEQUENCE_BOOKING_ID);

			rs.next();
			generatedId=rs.getInt(1);
		}
		catch(Exception e)
		{
			throw new BookingException(e.getMessage());
		}
		finally
		{
			try
			{
				rs.close();
				st.close();
				conn.close();
			}
			catch(Exception e)
			{
				throw new BookingException(e.getMessage());
			}
		}
		
		return generatedId;
	}

	@Override
	public BookingInformation getBookingInformation(int bookingId)
			throws BookingException
	{
		BookingInformation bookInfo=null;
		ResultSet rs=null;
		try
		{
			Connection conn=DBUtil.getCon();
			PreparedStatement pst=conn.prepareStatement(QueryMapper.GET_BOOKED_DETAILS);
			pst.setInt(1, bookingId);
			rs=pst.executeQuery();
			
			if(rs.next())
			{
				String custEmail=rs.getString(1);
				int noOfPassengers=rs.getInt(2);
				String classType=rs.getString(3);
				Double totalFare=rs.getDouble(4);
				String seatNumber=rs.getString(5);
				String creditCardInfo=rs.getString(6);
				String srcCity=rs.getString(7);
				String destCity=rs.getString(8);
				int flightno = rs.getInt(9);
				bookInfo=new BookingInformation(flightno, bookingId, custEmail, noOfPassengers, classType, totalFare, seatNumber, creditCardInfo, srcCity, destCity);
				

			}
		}
		catch (SQLException | IOException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			throw new BookingException("Exception from getBookingInformation()",e);
		} finally {
			
			try {
				if(rs!=null)
					rs.close();
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
		return bookInfo;
	}

	@Override
	public boolean deleteBookingInformation(String id) throws BookingException 
	{
		try
		{
			Connection conn=DBUtil.getCon();
			PreparedStatement pst=conn.prepareStatement(QueryMapper.DELETE_BOOKING_ID);
			pst.setString(1, id);
			int flag=pst.executeUpdate();
			
			if(flag==1)
				return true;
			else
				return false;
		}
		catch (SQLException | IOException e) {
			// TODO Auto-generated catch block
			throw new BookingException("Exception from deleteBookingInformation()",e);
		}		
	}
	
	
}


