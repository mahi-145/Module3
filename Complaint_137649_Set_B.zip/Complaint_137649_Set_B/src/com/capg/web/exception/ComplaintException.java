package com.capg.web.exception;

public class ComplaintException extends Exception
{

	private static final long serialVersionUID = 1L;

	public ComplaintException()
	{
		
	}

	public ComplaintException(String message)
	{
		super(message);
	}

	public ComplaintException(Throwable cause)
	{
		super(cause);
	}

	public ComplaintException(String message, Throwable cause)
	{
		super(message, cause);
	}

	public ComplaintException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) 
	{
		super(message, cause, enableSuppression, writableStackTrace);
	}

}
