package com.capg.web.controller;

import java.util.Arrays;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.capg.web.entities.Complaint;
import com.capg.web.exception.ComplaintException;
import com.capg.web.service.IComplaintService;

@Controller
public class ComplaintController {

	@Autowired
	private IComplaintService complaintService;

	public IComplaintService getComplaintService() {
		return complaintService;
	}

	public void setComplaintService(IComplaintService complaintService) {
		this.complaintService = complaintService;
	}

	public List<String> getComplaintList() {
		return Arrays.asList("Internet Banking", "General Banking", "Others");
	}

	@RequestMapping("/fetchHomePage.html")
	public String getHomePage(Model model) {
		model.addAttribute("categoryList", getComplaintList());
		model.addAttribute("Complaint", new Complaint());

		return "HomePage";
	}

	@RequestMapping(value = "/processRaiseComplaintForm.html", method = RequestMethod.POST)
	public String getprocessRaiseComplaintForm(
			@ModelAttribute("Complaint") @Valid Complaint complaint,
			BindingResult formBindingResult, Model model) {

		if (formBindingResult.hasErrors()) {
			model.addAttribute("categoryList", getComplaintList());

			return "HomePage";
		}

		try {

			int id = complaintService.createComplaint(complaint);

			model.addAttribute("info", "Complaint Id for this request is " + id+".");

			return "SuccessPage";

		}
		catch (ComplaintException e)
		{
			model.addAttribute("errMsg","Something went wrong while trying to add details reason"+ e.getMessage());
			return "ErrorPage";
		}
	}

	@RequestMapping("/fetchCheckStatus.html")
	public String getCheckStatus(Model model) {
		return "CheckStatus";
	}

	@RequestMapping(value = "/FetchComplaintByID.html", method = RequestMethod.POST)
	public String processFetchProductDetailsForm(
			@RequestParam("complaintId") int id, Model model) {

		if (id <= 0) {
			model.addAttribute("errMsg", "Id should be a valid positive number");
			return "ErrorPage";
		}

		try {

			Complaint complaint = complaintService.getComplaint(id);

			// add to model as to display to the getProductPage
			model.addAttribute("Complaint", complaint);
			return "CheckStatus";

		} catch (Exception e) {
			model.addAttribute(
					"errMsg",
					"could not fetch Product Details: Reason: "
							+ e.getMessage());
			return "ErrorPage";

		}
	}

}
