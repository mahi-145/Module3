package com.capg.web.service;

import com.capg.web.entities.Complaint;
import com.capg.web.exception.ComplaintException;

public interface IComplaintService {

	
	public int createComplaint(Complaint complaint) throws ComplaintException;
	
	public Complaint getComplaint(int id) throws ComplaintException;
}
