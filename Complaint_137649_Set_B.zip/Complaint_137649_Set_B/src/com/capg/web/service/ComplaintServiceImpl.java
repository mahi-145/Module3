package com.capg.web.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.web.dao.IComplaintDAO;
import com.capg.web.entities.Complaint;
import com.capg.web.exception.ComplaintException;


@Service
@Transactional
public class ComplaintServiceImpl implements IComplaintService {

	@Autowired
	private IComplaintDAO complaintDAO;

	public IComplaintDAO getComplaintDAO() {
		return complaintDAO;
	}

	public void setComplaintDAO(IComplaintDAO complaintDAO) {
		this.complaintDAO = complaintDAO;
	}

	@Override
	public int createComplaint(Complaint complaint) throws ComplaintException {
		// TODO Auto-generated method stub
		return complaintDAO.createComplaint(complaint);
	}

	@Override
	public Complaint getComplaint(int id) throws ComplaintException {
		// TODO Auto-generated method stub
		return complaintDAO.getComplaint(id);
	}

}
