package com.capg.web.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.capg.web.entities.Complaint;
import com.capg.web.exception.ComplaintException;

@Repository
public class ComplaintDAOImpl implements IComplaintDAO
{

	@PersistenceContext
	private EntityManager entityManager;

	public EntityManager getEntityManager()
	{
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager)
	{
		this.entityManager = entityManager;
	}
	
	/*
	 * Employee Name: Sushil Sharma
	 * Employee Code: 137649
	 * Date: 23rd NOV 2017
	 * Description: The Method below is used to insert record into the database Table Complaint.
	 */

	@Override
	public int createComplaint(Complaint complaint) throws ComplaintException
	{	
		int id;
		
		try {
			
			String category = complaint.getCategory();
			
			if(category.equalsIgnoreCase("Internet Banking"))
			{
				complaint.setPriority("High");
				complaint.setStatus("Open");
			}
			
			if(category.equalsIgnoreCase("General Banking"))
			{
				complaint.setPriority("Medium");
				complaint.setStatus("Open");
			}
			
			if(category.equalsIgnoreCase("Others"))
			{
				complaint.setPriority("Low");
				complaint.setStatus("Open");
			}

			entityManager.persist(complaint);
			entityManager.flush();
			id=complaint.getId();
		}
		catch (Exception e) 
		{
			throw new ComplaintException(e.getMessage());
		}

		return id;
	}

	/*
	 * Employee Name: Sushil Sharma
	 * Employee Code: 137649
	 * Date: 23rd NOV 2017
	 * Description:  The Method below is used to retrieve complaint status of a particular complaint on the basis of ID .
	 */
	
	@Override
	public Complaint getComplaint(int id) throws ComplaintException 
	{	
		Complaint complaint = null;
		
		try 
		{
			complaint=entityManager.find(Complaint.class, id);
			entityManager.flush();
			
			if(complaint==null)
				throw new Exception("Complaint with this id does not exist");
			
		}
		catch (Exception e)
		{
			throw new ComplaintException(e.getMessage());
		}
		
		return complaint;
	}

}
