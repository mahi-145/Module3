package com.capg.web.dao;

import com.capg.web.entities.Complaint;
import com.capg.web.exception.ComplaintException;

public interface IComplaintDAO {

	
	public int createComplaint(Complaint complaint) throws ComplaintException;
	
	public Complaint getComplaint(int id) throws ComplaintException;
}
