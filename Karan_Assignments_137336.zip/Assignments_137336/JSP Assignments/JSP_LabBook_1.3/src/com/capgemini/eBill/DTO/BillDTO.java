package com.capgemini.eBill.DTO;

import java.util.Date;

/*
 *  bill_num NUMBER(6) PRIMARY KEY, 
 *  consumer_num NUMBER(6) REFERENCES Consumers(consumer_num), 
 *  cur_reading NUMBER(5,2), 
 *  unitConsumed NUMBER(5,2), 
 *  netAmount NUMBER(5,2), 
 *  bill_date DATE DEFAULT SYSDATE
 */
public class BillDTO
{
	private int billNumber;
	private int consumerNumber;
	private double currentReading;
	private double unitConsumed;
	private double netAmount;
	private Date date;
	
	public BillDTO() {
		super();
	}

	public BillDTO(int billNumber, int consumerNumber, double currentReading,
			double unitConsumed, double netAmount, Date date) {
		super();
		this.billNumber = billNumber;
		this.consumerNumber = consumerNumber;
		this.currentReading = currentReading;
		this.unitConsumed = unitConsumed;
		this.netAmount = netAmount;
		this.date = date;
	}

	public int getBillNumber() {
		return billNumber;
	}

	public void setBillNumber(int billNumber) {
		this.billNumber = billNumber;
	}

	public int getConsumerNumber() {
		return consumerNumber;
	}

	public void setConsumerNumber(int consumerNumber) {
		this.consumerNumber = consumerNumber;
	}

	public double getCurrentReading() {
		return currentReading;
	}

	public void setCurrentReading(double currentReading) {
		this.currentReading = currentReading;
	}

	public double getUnitConsumed() {
		return unitConsumed;
	}

	public void setUnitConsumed(double unitConsumed) {
		this.unitConsumed = unitConsumed;
	}

	public double getNetAmount() {
		return netAmount;
	}

	public void setNetAmount(double netAmount) {
		this.netAmount = netAmount;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return "BillDTO [billNumber=" + billNumber + ", consumerNumber="
				+ consumerNumber + ", currentReading=" + currentReading
				+ ", unitConsumed=" + unitConsumed + ", netAmount=" + netAmount
				+ ", date=" + date + "]";
	}
}
