package com.capgemini.eBill.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.eBill.DTO.BillDTO;
import com.capgemini.eBill.DTO.Consumer;
import com.capgemini.eBill.exception.BillException;
import com.capgemini.eBill.service.EBillServiceImpl;
import com.capgemini.eBill.service.IEBillService;

@WebServlet("/EbillController")
public class EbillController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	IEBillService service;
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		
		super.init(config);
		
		service = new EBillServiceImpl();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String operation = request.getParameter("userAction");
		PrintWriter pw = response.getWriter();
		RequestDispatcher view = null;
		HttpSession session = request.getSession(false);
		
		if (operation != null && "list".equals(operation)) 
		{
			
			if (session == null) {
				session = request.getSession(true);
			}
			ArrayList<Consumer> consumers = null;
			
			try 
			{
				consumers = service.viewConsumer();
			} 
			catch (BillException e) {
				
				session.setAttribute("error", e);
				//view = request.getRequestDispatcher("Error.jsp");
				//pw.println("Cannot show. Reason is "+e.getMessage());
				//view.include(request, response);
				response.sendRedirect("Error.jsp");
			}
			
			if(consumers != null)
			{
				session.setAttribute("consumers", consumers);
				response.sendRedirect("Show_ConsumerList.jsp");
			}
			else
			{
				response.sendRedirect("Error.jsp");
			}
		}
		
		if(operation != null && "showBillDetails".equals(operation))
		{
			if(session == null)
			{
				session = request.getSession(true);
			}
			ArrayList<BillDTO> bills = null;
			String consumerNumberStr = request.getParameter("consumerNumber");
			int consumerNumber = Integer.valueOf(consumerNumberStr);
			session.setAttribute("consumerNumber", consumerNumber);
			try
			{
				bills = service.viewBill(consumerNumber);
			}
			catch (BillException e) {
				
				session.setAttribute("error", e);
				//view = request.getRequestDispatcher("Error.jsp");
				//pw.println("Cannot show. Reason is "+e.getMessage());
				//view.include(request, response);
				response.sendRedirect("Error.jsp");
			}
			
			if(bills != null)
			{
				session.setAttribute("bills", bills);
				response.sendRedirect("Show_Bills.jsp");
			}
			else
			{
				response.sendRedirect("Error.jsp");
			}
		}
		
		if(operation != null && "search".equals(operation))
		{
			if (session == null) {
				session = request.getSession(true);
			}
			Consumer consumer = null;
			String consumerNumberStr = request.getParameter("consumerNumber");
			int consumerNumber = Integer.valueOf(consumerNumberStr);
			try
			{
				consumer = service.getConsumerDetails(consumerNumber);
			}
			catch (BillException e) {
				
				session.setAttribute("error", e);
				//view = request.getRequestDispatcher("Error.jsp");
				//pw.println("Cannot show. Reason is "+e.getMessage());
				//view.include(request, response);
				response.sendRedirect("Error.jsp");
			}
			
			if(consumer != null)
			{
				session.setAttribute("consumer", consumer);
				response.sendRedirect("Show_Consumer.jsp");
			}
			else
			{
				response.sendRedirect("Error.jsp");
			}
		}
		
		if (operation != null && "calculate".equals(operation)) 
		{
			if (session == null) {
				session = request.getSession(true);
			}
			
			String consumerNumberStr = request.getParameter("consumerNumber");
			int consumerNumber = Integer.valueOf(consumerNumberStr);
			String lastReadingStr = request.getParameter("lastReading");
			double lastReading = Double.valueOf(lastReadingStr);
			String currentReadingStr = request.getParameter("currentReading");
			double currentReading = Double.valueOf(currentReadingStr);
			
			Consumer consumer = null;
			try 
			{
				consumer = service.getConsumerDetails(consumerNumber);
				
			} 
			catch (BillException e) 
			{
				session.setAttribute("error", e);
				//view = request.getRequestDispatcher("Error.jsp");
				//pw.println("Cannot show. Reason is "+e.getMessage());
				//view.include(request, response);
				response.sendRedirect("Error.jsp");
			}
			
			BillDTO bill = new BillDTO();
			
			//bill.setBillNumber(billNumber);
			double fixedCharge = 100;
			double unitConsumed = 0;
			unitConsumed = currentReading - lastReading;
			double netAmount = 0;
			netAmount = (unitConsumed * 1.15) + fixedCharge;
			
			bill.setConsumerNumber(consumerNumber);
			bill.setCurrentReading(currentReading);
			bill.setUnitConsumed(unitConsumed);
			bill.setNetAmount(netAmount);
			bill.setDate(java.sql.Date.valueOf(LocalDate.now()));
			
			try 
			{
				int records = service.addBill(bill);
				
			}
			catch(BillException e)
			{
				session.setAttribute("error", e);
				//view = request.getRequestDispatcher("Error.jsp");
				//pw.println("Cannot show. Reason is "+e.getMessage());
				//view.include(request, response);
				response.sendRedirect("Error.jsp");
			}
			if(consumer != null)
			{
			session.setAttribute("consumer", consumer);
			session.setAttribute("bill", bill);
			view = request.getRequestDispatcher("Bill_Info.jsp");
			view.forward(request, response);
			}
			else
			{
				response.sendRedirect("Error.jsp");
			}
			
			
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
		
	}

}
