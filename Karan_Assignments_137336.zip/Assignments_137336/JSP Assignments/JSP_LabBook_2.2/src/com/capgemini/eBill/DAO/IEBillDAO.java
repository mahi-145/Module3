package com.capgemini.eBill.DAO;

import java.util.ArrayList;

import com.capgemini.eBill.DTO.BillDTO;
import com.capgemini.eBill.DTO.Consumer;
import com.capgemini.eBill.exception.BillException;

public interface IEBillDAO 
{
	public int addBill(BillDTO bill) throws BillException;
	
	public Consumer getConsumerDetails(int consumerNumber) throws BillException;

	public ArrayList<Consumer> viewConsumer() throws BillException;

	public ArrayList<BillDTO> viewBill(int consumerNumber) throws BillException;

}
