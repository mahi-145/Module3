CREATE TABLE Consumers( consumer_num NUMBER(6) PRIMARY KEY, consumer_name VARCHAR2(20) NOT NULL, address VARCHAR2(30) ); 

INSERT INTO Consumers VALUES(100001,'Sumeet','Shivaji Nagar, Pune'); 
INSERT INTO Consumers VALUES(100002,'Meenal','M G Colony Panvel, Mumbai'); 
INSERT INTO Consumers VALUES(100003,'Neeraj','Whitefield, Bangalore'); 
INSERT INTO Consumers VALUES(100004,'Arul','Karapakkam, Chennai'); 

CREATE TABLE BillDetails( bill_num NUMBER(6) PRIMARY KEY, consumer_num NUMBER(6) REFERENCES Consumers(consumer_num), cur_reading NUMBER(5,2), unitConsumed NUMBER(5,2), netAmount NUMBER(5,2), bill_date DATE DEFAULT SYSDATE); 

CREATE SEQUENCE seq_bill_num START WITH 100;

select * from consumers;