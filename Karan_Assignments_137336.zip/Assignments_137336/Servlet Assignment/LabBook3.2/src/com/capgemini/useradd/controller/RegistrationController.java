package com.capgemini.useradd.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.useradd.DTO.UserDTO;
import com.capgemini.useradd.exception.UserException;
import com.capgemini.useradd.service.IRegisterService;
import com.capgemini.useradd.service.RegisterServiceImpl;

@WebServlet("/RegistrationController")
public class RegistrationController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	IRegisterService service;
		
	@Override
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		super.init(config);
		service = new RegisterServiceImpl();
	}

	/* (non-Javadoc)
	 * @see javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String operation = request.getParameter("userAction");
		PrintWriter pw = response.getWriter();
		RequestDispatcher view = null;
		
		if (operation != null && "add".equals(operation)) {
			
			String firstName = request.getParameter("firstName");
			String lastName = request.getParameter("lastName");
			String password = request.getParameter("password");
			String gender = request.getParameter("gender");
			String[] skillSet = request.getParameterValues("skillSet");
			
			String skills = "";
			
			for (int index = 0; index < skillSet.length; index++) 
			{
				skills += skillSet[index] + ", ";
			}
			
			skills = skills.substring(0, skills.length()-2);
			
			String city = request.getParameter("city");
			
			UserDTO user = new UserDTO();
			
			user.setFirstName(firstName);
			user.setLastName(lastName);
			user.setPassword(password);
			user.setGender(gender);
			user.setSkillSet(skills);
			user.setCity(city);
			
			try {
				
				int records = service.addUser(user);
				
				if (records != 0) {
					response.sendRedirect("success.html");
				} 
				else 
				{
					response.sendRedirect("failure.html");
				}
			} 
			catch (UserException e) {
				pw.println("<h1 style='color:red'>Error while registering User" +e.getMessage());
				
			}
		}
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doGet(request, response);
	}

}
