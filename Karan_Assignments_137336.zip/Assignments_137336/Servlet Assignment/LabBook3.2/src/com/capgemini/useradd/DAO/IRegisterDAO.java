package com.capgemini.useradd.DAO;

import com.capgemini.useradd.DTO.UserDTO;
import com.capgemini.useradd.exception.UserException;

public interface IRegisterDAO 
{
	public int addUser(UserDTO user) throws UserException;
}
