package com.capgemini.useradd.DTO;

public class UserDTO 
{
	private String firstName;
	private String lastName;
	private String password;
	private String gender;
	private String skillSet;
	private String city;
	
	public UserDTO(String firstName, String lastName, String password,
			String gender, String skillSet, String city) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.password = password;
		this.gender = gender;
		this.skillSet = skillSet;
		this.city = city;
	}

	public UserDTO() {
		super();
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getSkillSet() {
		return skillSet;
	}

	public void setSkillSet(String skillSet) {
		this.skillSet = skillSet;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Override
	public String toString() {
		return "UserDTO [firstName=" + firstName + ", lastName=" + lastName
				+ ", password=" + password + ", gender=" + gender
				+ ", skillSet=" + skillSet + ", city=" + city + "]";
	}
	
	
}
