package com.cg.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class WelcomeServlet
 */
@WebServlet("/WelcomeServlet")
public class WelcomeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		PrintWriter pw = response.getWriter();

		response.setContentType("text/html");

		HttpSession session = request.getSession(false);

		if (session != null) {
			
//			String strUsr = (String) getServletContext()
//					.getAttribute("appUser");

			String strUsr = (String) session.getAttribute("username");
								
			pw.println("<h3> Your session id is " + session.getId() + "<hr>");
			pw.println("<h3> Session Creation Time is " + session.getCreationTime() + "<hr>");
			pw.println("<h3>Welcome....... " + strUsr + "</h3><hr>");
			pw.println("<a href='LogoutServlet'>Logout</a>");
			
			pw.println("<hr><H3>Test URL Rewriting</H3>");
			
			pw.println("Click <A HREF=\"" + response.encodeURL(request.getRequestURI()) + "\">here</A>");
			
			pw.println("to test that session tracking works via URL");
			
			pw.println("rewriting even when cookies aren't supported");
						
		} else {
			pw.println("<h1>Session Expired, Kindly Re-Login</h1>");
			request.getRequestDispatcher("userAuth.html").include(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
