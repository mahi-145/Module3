package com.cg.servlet;


import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ConfigServlet
 */
@WebServlet(name = "/ConfigServlet", urlPatterns = "/ConfigServlet", initParams = {
		@WebInitParam(name = "uname", value = "123"),
		@WebInitParam(name = "pass", value = "123") })
public class ConfigServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String name = request.getParameter("username");
		String pwd = request.getParameter("password");

		PrintWriter pw = response.getWriter();

		response.setContentType("text/html");

		// to have inter-servlet communication we'll use RequestDispatcher
		RequestDispatcher view = null;

		if (strUser.equals(name) && strPass.equals(pwd)) {
			
			HttpSession session = request.getSession(true);
			
			// setting the session time-out programmatically
//			session.setMaxInactiveInterval(60);	// takes parameter as seconds
			
			// true => return the existing session obj
			// or if session is null
			// then create a new session
			
			// false => return the existing session obj
			// and if session doesn't exists then return null
			
			pw.println("<h1>Authorized, you are welcome</h1>");

//			view = request.getRequestDispatcher("/WelcomeServlet");
//
//			view.forward(request, response);

			// Client side request dispatching
			// set the context attribute
//			getServletContext().setAttribute("appUser", strUser);
			session.setAttribute("username", "strUser");
			// maintaining username in session scope
			
			response.sendRedirect("WelcomeServlet");
			
		} else {
			pw.println("<h1 style='color:red'>UnAuthorized user </h1><hr>");

			view = request.getRequestDispatcher("/userAuth.html");

			view.include(request, response);
		}
	}

	String strUser, strPass;

	@Override
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		super.init(config);

		strUser = config.getInitParameter("uname");
		strPass = config.getInitParameter("pass");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
