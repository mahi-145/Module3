package com.capgemini.useradd.service;

import java.util.ArrayList;

import com.capgemini.useradd.DAO.IRegisterDAO;
import com.capgemini.useradd.DAO.RegisterDAOImpl;
import com.capgemini.useradd.DTO.UserDTO;
import com.capgemini.useradd.exception.UserException;

public class RegisterServiceImpl implements IRegisterService
{
	IRegisterDAO registerDAO;
	
	public RegisterServiceImpl()
	{
		registerDAO = new RegisterDAOImpl();
	}
	
	@Override
	public int addUser(UserDTO user) throws UserException 
	{
		
		return registerDAO.addUser(user);
	}

	@Override
	public ArrayList<UserDTO> showUser() throws UserException {
		 return registerDAO.showUser();
	}

}
