import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;


public class TestnDeserialization 
{
	public static void main(String[] args) 
	{
		FileInputStream fis;
		ObjectInputStream ois=null;
		try 
		{
			fis= new FileInputStream("EmpData.obj");
			ois= new ObjectInputStream(fis);
		} 
		catch (Exception e1) {
			
			e1.printStackTrace();
		}
		
	
		
		int n = 0;
		for(int i=0;i<n;i++)
		{
		try
		{
			
			Emp ee=(Emp)ois.readObject();
			System.out.println("emp object is read in a file"+ee);
		}
		catch(IOException | ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		
		
		
		}
	}


}