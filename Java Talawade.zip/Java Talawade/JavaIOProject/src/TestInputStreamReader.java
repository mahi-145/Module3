import java.io.*;
public class TestInputStreamReader
{

	public static void main(String[] args) 
	{
	try
	{
		InputStreamReader isr= new InputStreamReader(System.in);
		BufferedReader br= new BufferedReader(isr);
		System.out.println("Enter Emp Id:");
		int eid=Integer.parseInt(br.readLine());
		
		System.out.println("Enter Emp Name:");
		String enm=br.readLine();
		
		System.out.println("Enter Emp Salary:");
		float esl=Float.parseFloat(br.readLine());
		
		System.out.println(eid+" "+enm+" "+esl);
		FileWriter fw= new FileWriter("EmpInfo.txt");
		BufferedWriter bw=new BufferedWriter(fw);
		Integer eIDS=new Integer(eid);//boxing
		bw.write(eIDS.toString());
		bw.write(enm);
		Float eslS=new Float(esl);
		bw.write(eslS.toString());
		bw.flush();
		System.out.println("Emp info written"+"in a file");
		
	}
	catch(IOException ie)
	{
		ie.printStackTrace();
	}
}
}
	
