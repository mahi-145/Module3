import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Scanner;


public class TestnSerialization 
{
		public static void main(String[] args) 
		{
			Scanner sc=new Scanner(System.in);
			int n = 0;
			Emp e[]=new Emp[n];
			for(int i=0;i<n;i++)
			{
			
			System.out.println("Enter the empId:");
			int empId= sc.nextInt();
			
			System.out.println("Enter the empName:");
			String empName= sc.next();
			
			System.out.println("Enter the emp salary:");
			float empsal= sc.nextFloat();
			
			e[i]=new Emp(empId,empName,empsal);
			}
			System.out.println("emp object is written in a file");
			FileOutputStream fos;
			try
			{
				fos= new FileOutputStream("EmpData.obj");
				ObjectOutputStream oos= new ObjectOutputStream(fos);
				for(int i=0;i<n;i++)
				{
				oos.writeObject(e[i]);
				
				}
			}
			catch(IOException er)
			{
				er.printStackTrace();
			}
			
			
			

		}

}
