import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;


public class TestEmpDeserialization
{
	public static void main(String[] args) 
	{
		FileInputStream fis;
		ObjectInputStream ois=null;
		try 
		{
			fis= new FileInputStream("EmpData.obj");
			ois= new ObjectInputStream(fis);
		} 
		catch (Exception e1) {
			
			e1.printStackTrace();
		}
		
	
		
		for(int i=0;i<3;i++)
		{
		try
		{
			
			Emp e=(Emp)ois.readObject();
			System.out.println("emp object is read in a file"+e);
		}
		
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		catch(IOException e) 
		{
			e.printStackTrace();
		}
		
		}
		
	}
}
		
