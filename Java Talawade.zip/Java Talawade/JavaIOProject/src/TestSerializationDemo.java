import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Scanner;


public class TestSerializationDemo 
{

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
		
		System.out.println("Enter the empId:");
		int empId= sc.nextInt();
		
		System.out.println("Enter the empName:");
		String empName= sc.next();
		
		System.out.println("Enter the emp salary:");
		float empsal= sc.nextFloat();
		
		Emp e1=new Emp(empId,empName,empsal);
		FileOutputStream fos;
		try
		{
			fos= new FileOutputStream("EmpData.obj");
			ObjectOutputStream oos= new ObjectOutputStream(fos);
			oos.writeObject(e1);
			System.out.println("emp object is written in a file");
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		
		
		

	}

}
