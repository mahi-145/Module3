import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Scanner;


public class TestEmpSerialization 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		Emp e[]=new Emp[3];
		for(int i=0;i<3;i++)
		{
		
		System.out.println("Enter the empId:");
		int empId= sc.nextInt();
		
		System.out.println("Enter the empName:");
		String empName= sc.next();
		
		System.out.println("Enter the emp salary:");
		float empsal= sc.nextFloat();
		
		e[i]=new Emp(empId,empName,empsal);
		}
		System.out.println("emp object is written in a file");
		FileOutputStream fos;
		try
		{
			fos= new FileOutputStream("EmpData.obj");
			ObjectOutputStream oos= new ObjectOutputStream(fos);
			for(int i=0;i<3;i++)
			{
			oos.writeObject(e[i]);
			
			}
		}
		catch(IOException er)
		{
			er.printStackTrace();
		}
		
		
		

	}
}
