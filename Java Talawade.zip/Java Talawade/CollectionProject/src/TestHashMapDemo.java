import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;


public class TestHashMapDemo
{

	public static void main(String[] args)
	{
		HashMap<Long,String> mobileDirectory= new HashMap<Long,String>();
		
		mobileDirectory.put(8965412354L, "Anindita");
		mobileDirectory.put(8996541235L, "Mahima");
		mobileDirectory.put(8845621357L, "Pari");
		mobileDirectory.put(8987456213L, "Krittika");
		mobileDirectory.put(8965412354L, "Anindita");
		
		/*Set<Long> setIt=mobileDirectory.keySet();
		
		Iterator<Long> mobIt=setIt.iterator();
		while(mobIt.hasNext())
		{
			Long dirEntry= mobIt.next();
			System.out.println("Mobile: "+dirEntry);
		}*/
	Collection <String>setIt=mobileDirectory.values();
	Iterator<String> nmIt=setIt.iterator();
	while(nmIt.hasNext())
	{
		String dirEntry=nmIt.next();
		System.out.println(dirEntry);
	}
}

}
