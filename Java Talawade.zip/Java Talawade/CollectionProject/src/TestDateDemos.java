import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.format.DateTimeFormatter;


public class TestDateDemos 
{

	public static void main(String[] args)
	{
		LocalDate today=LocalDate.now();
		System.out.println("Today Date: "+today);
		
		System.out.println("**************");
		LocalDate myDOJ=LocalDate.of(2010,04,03);
		System.out.println("My date of joining is :"+myDOJ);
		
		System.out.println("**************");
		String ronalDOJ= "13-Dec-2017";
		
		DateTimeFormatter myFormat=
		DateTimeFormatter.ofPattern("dd-MMM-yyyy");
		LocalDate ronalDOJD=LocalDate.parse(ronalDOJ,myFormat);
		System.out.println("Ronal DOJ ="+ronalDOJD);
		
		System.out.println("*******************");
		
		DateTimeFormatter secondFormat= 
				DateTimeFormatter.ofPattern("yyyy-MMM-dd");
		String urDOJ=ronalDOJD.format(secondFormat);
		System.out.println("...."+urDOJ);
		
		System.out.println("Difference");
		
		Period period=Period.between(myDOJ, today);
		int years=period.getYears();
		int month=period.getMonths();
		int day=period.getDays();
		
		System.out.println("My experience in cg is :"+ years +" Years: "
				+ month +" Months : "+ day + " Days ");
		

	}

}
