package com.capgemini.apply.dao;

import com.capgemini.apply.bean.ApplicationBean;
import com.capgemini.apply.exception.ApplicationException;

public interface ApplyDao 
{
	public int addApplicantDetails(ApplicationBean applicant) 
			throws ApplicationException;
	public ApplicationBean getApplicationDetails(long applicationID) 
			throws ApplicationException;

}
