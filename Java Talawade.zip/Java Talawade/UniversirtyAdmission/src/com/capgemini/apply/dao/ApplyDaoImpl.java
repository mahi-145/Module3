package com.capgemini.apply.dao;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.apply.bean.ApplicationBean;
import com.capgemini.apply.exception.ApplicationException;
import com.capgemini.apply.util.DBUtil;

public class ApplyDaoImpl implements ApplyDao
{
	Connection con = null;
	Statement st = null;
	PreparedStatement pst = null;
	ResultSet rs = null;
	Logger applyLogger;

	public ApplyDaoImpl() {

		PropertyConfigurator.configure("resources/log4j.properties");
		applyLogger = Logger.getLogger("ApplyDaoImpl.class");
	}


	@Override
	public int addApplicantDetails(ApplicationBean applicant)
			throws ApplicationException 
	{
		String insertQry = "INSERT INTO candidate_detail VALUES(?,?,?,?,?,?,?)";
		int appId = 0;

		try {
			con = DBUtil.getCon();
			System.out.println(con);
			pst = con.prepareStatement(insertQry);
			appId = generateMobId();

			pst.setInt(1, appId);// setting auto generating sequence							
			pst.setString(2, applicant.getfName());
			pst.setString(3, applicant.getlName());
			pst.setLong(4, applicant.getContactNo());
			pst.setString(5, applicant.getEmail());
			pst.setFloat(6, applicant.getAggregate());
			pst.setString(7, applicant.getStream());

			pst.executeUpdate();
		}
		catch (Exception e) {
			applyLogger.error("This is exception: " + e.getMessage());

			throw new ApplicationException(e.getMessage());
		} 
		finally 
		{

			try {
				pst.close();
				con.close();

			} catch (SQLException e) 
			{

				applyLogger.error("This is exception: " + e.getMessage());
				throw new ApplicationException(e.getMessage());
			}
		}
		return appId;
	}
	
	private int generateMobId() throws ApplicationException {

		String seqQry = "SELECT apply_id_seq.NEXTVAL FROM DUAL";

		int generatedValue;

		try {

			con = DBUtil.getCon();
			st = con.createStatement();
			rs = st.executeQuery(seqQry);

			rs.next();
			generatedValue = rs.getInt(1);

			applyLogger.log(Level.INFO,"sequence generated");

		} catch (Exception e) {

			applyLogger.error("This is exception: " + e.getMessage());
			throw new ApplicationException(e.getMessage());

		} finally {

			try {

				rs.close();
				st.close();
				con.close();

			} 
			catch (SQLException e)
			{
				applyLogger.error("This is exception: " + e.getMessage());
				throw new ApplicationException(e.getMessage());
			}
		}
		return generatedValue;

	}
	@Override
	public ApplicationBean getApplicationDetails(long applicationID)
			throws ApplicationException
	{

		String selQry = "SELECT * FROM candidate_detail where applyid = " + applicationID;

		ApplicationBean app = null;

		try {
			con = DBUtil.getCon();
			st = con.createStatement();
			rs = st.executeQuery(selQry);

			while( rs.next() ) {

				app = new ApplicationBean(rs.getInt(1),rs.getString(2), rs.getString(3), rs.getString(5),
						rs.getLong(4),rs.getString(7), rs.getFloat(6));
			}

			applyLogger.log(Level.INFO, "data inserted" + applicationID);

		}
		catch (Exception e) {

			e.printStackTrace();
			applyLogger.error("This is exception: " + e.getMessage());
			throw new ApplicationException(e.getMessage());

		}
		finally {


			try {
				rs.close();
				st.close();
				con.close();

			} catch (SQLException e) {

				applyLogger.error("This is exception: " + e.getMessage());
				throw new ApplicationException(e.getMessage());

			}
		}
		return app;
	}


}
