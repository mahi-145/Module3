package com.capgemini.apply.ui;

import java.util.Scanner;

import com.capgemini.apply.bean.ApplicationBean;
import com.capgemini.apply.exception.ApplicationException;
import com.capgemini.apply.service.ApplyService;
import com.capgemini.apply.service.ApplyServiceImpl;

public class Client {

	static Scanner sc;
	static ApplyService appSer;

	public static void main(String [] args) {

		sc = new Scanner(System.in);
		appSer = new ApplyServiceImpl();

		System.out.println("*************Admission System*****************");

		int choice = 0;

		while(true) {
			System.out.println("Select an operation \n 1. Enter Details"
					+ "\n 2. View Details based on Application Id "
					+ "\n 0. Exit");

			System.out.println("**********************************************");
			System.out.println("Please enter a choice: \n");
			System.out.println("**********************************************");
			choice = sc.nextInt();
			System.out.println("**********************************************");

			switch(choice) {

			case 1: addDetails();
			break;
			case 2: fetchDetails();
			break;
			//case 0: exitApplication();
			//break;
			default :
				System.out.println("Invalid input");
			}
		}
	}
	//adding details...
		private static void addDetails() {

			System.out.print("Enter First Name: ");
			String fName = sc.next();
			System.out.print("Enter Last Name: ");
			String lName = sc.next();
			System.out.print("Enter Contact Number: ");
			long contact = sc.nextLong();
			System.out.print("Enter Email: ");
			String email = sc.next();
			System.out.print("Enter Stream: ");
			sc.nextLine();
			String stream = sc.nextLine();
			System.out.print("Enter Aggregate in qualifying exam: ");
			float agg = sc.nextFloat();
			//System.out.println(stream);
			
			//sc.close();
			
			

			ApplicationBean appBean = new ApplicationBean();
			appBean.setfName(fName);
			appBean.setlName(lName);
			appBean.setContactNo(contact);
			appBean.setEmail(email);
			appBean.setStream(stream);
			appBean.setAggregate(agg);

			try {

				if(appSer.isValidApplicatnt(appBean)) {
					
					int UniqueId = appSer.addApplicantDetails(appBean);
					
					if(UniqueId > 0 ) {

						System.out.println("\n**********************************************");
						System.out.println("Thank you "+appBean.getfName() + " " + appBean.getlName() +
								" your Unique Id is " + UniqueId + " we will contact you shortly");
						System.out.println("\n**********************************************");
					}
				}
			} 
			catch (ApplicationException e) {
				
				System.out.println("\n**********************************************");
				//e.printStackTrace();
				System.out.println(e.getMessage());
				System.out.println("\n**********************************************");
			}

		}
		private static void fetchDetails() {

			System.out.println("Enter Applicant Id. : ");
			long appId = sc.nextLong();
			System.out.println("\n**********************************************");

			ApplicationBean appBean = new ApplicationBean();
			try {

				appBean = appSer.getApplicationDetails(appId);

				if(appBean != null) {

					System.out.println("Id\tFirst Name\tLast Name\tContact No.\tStream\t\tAggregate\tEmail   ");				

					System.out.print(appBean.getApplyId() + "\t");
					System.out.print(appBean.getfName() + "\t\t");
					System.out.print(appBean.getlName() + "\t\t");
					System.out.print(appBean.getContactNo() + "\t");
					System.out.print(appBean.getStream() + "\t");
					System.out.print(appBean.getAggregate() + "\t");
					System.out.println(appBean.getEmail());

					

				}
				else {
					System.out.println("**********************************************");
					System.out.println("Sorry no details found!!");
					System.out.println("\n**********************************************");
				}

			}
			catch (ApplicationException e) {
				System.out.println("\n**********************************************");
				System.err.println(e.getMessage());
				System.out.println("\n**********************************************");
			}
		}
		private static void exitApplication() {
			System.out.println("\n**********************************************");
			System.out.println("Thank you for applying !!");
			System.exit(1);
			System.out.println("\n**********************************************");
		}
}
