package com.cg.contactbook.dao;
import java.sql.*;
import java.util.*;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.contactbook.bean.*;
import com.cg.contactbook.exception.*;
import com.cg.contactbook.util.*;


public class ContactBookDaoImpl implements ContactBookDao
{
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	Logger cbLogger=null;
	
	public ContactBookDaoImpl()
	{
		PropertyConfigurator.configure("resources/log4j.properties");
		cbLogger=Logger.getLogger("ContactBookDaoImpl.class");
	}
//************Add Enquiry Details**********
	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException 
	{

		int dataAdded=0;
		String insertQry="INSERT INTO enquiry VALUES("
				+ "?,?,?,?,?,?)";
		try
		{
			con =DBUtil.getCon();
			pst=con.prepareStatement(insertQry);

			pst.setInt(1,generateEnqryId());
			pst.setString(2,enqry.getfName());
			pst.setString(3,enqry.getlName());
			pst.setLong(4,enqry.getContactNo());
			pst.setString(5, enqry.getpDomain());
			pst.setString(6,enqry.getpLocation());

			dataAdded=pst.executeUpdate();
			cbLogger.log(Level.INFO,"Enquiry details Inserted: "+enqry);
		}
		catch(Exception e)
		{
			cbLogger.error("This is Exception:"+e.getMessage());
			throw new ContactBookException(e.getMessage());
		}
		finally
		{
			try
			{
				pst.close();
				con.close();
				st.close();
			}
			catch(SQLException e)
			{
				cbLogger.error("This is Exception:"+e.getMessage());
				throw new ContactBookException(e.getMessage());
			}
		}
		return dataAdded;
	}
//***********View Details************
	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryID)throws ContactBookException 
	{
		cbLogger.info("getEnquiryDetails Method started");
		EnquiryBean eb=null;
		try 
		{
			con=DBUtil.getCon();
			String viewQry="SELECT * FROM enquiry WHERE enqryid=?";
			pst=con.prepareStatement(viewQry);
			pst.setInt(1,EnquiryID);
			rs=pst.executeQuery();
			if(rs.next()==false)
			{
				throw new Exception("Invalid Enquiry Id");
			}
			eb=new EnquiryBean();
			eb.setEnqryId(EnquiryID);
			eb.setfName(rs.getString(2));
			eb.setlName(rs.getString(3));
			eb.setContactNo(rs.getLong(4));
			eb.setpDomain(rs.getString(5));
			eb.setpLocation(rs.getString(6));
		} 
		catch(Exception e) 
		{
			cbLogger.error("This is Exception:"+e.getMessage());
			throw new ContactBookException(e.getMessage());
		}
		return eb;
		
	}
//***************Generate Enquiry Id*********
	@Override
	public int generateEnqryId() throws ContactBookException
	{
		cbLogger.info("generate Enquiry Id Method started");
		cbLogger.debug("Trying to generate Enquiry id using sequence");
		int generatedVal;
		String qry="SELECT enquiries.NEXTVAL FROM DUAL";
		try
		{
			con =DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(qry);
			rs.next();
			generatedVal=rs.getInt(1);
		}
		catch(Exception e)
		{
			cbLogger.error("This is Exception:"+e.getMessage());
			e.printStackTrace();
			throw new ContactBookException(e.getMessage());
		}
		finally
		{
			try
			{
				rs.close();
				st.close();
				con.close();
			}
			catch(SQLException e)
			{
				cbLogger.error("This is Exception:"+e.getMessage());
				e.printStackTrace();
				throw new ContactBookException(e.getMessage());
			}
		}
		return generatedVal;
		
	}
//************Fetch all ENquiry ID*********
	@Override
	public ArrayList<Integer> getAllEnqryId() throws ContactBookException
	{
		ArrayList<Integer>idList=new ArrayList<Integer>();
		String selectQry="SELECT enqryid FROM enquiry";
		try 
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			
			while(rs.next())
			{
				idList.add(rs.getInt(1));
			}
		}
		catch (Exception e) 
		{
			throw new ContactBookException(e.getMessage());
		}
		finally
		{
			try
			{
				rs.close();
				st.close();
				con.close();
			}
			catch(SQLException e)
			{
				cbLogger.error("This is Exception:"+e.getMessage());
				throw new ContactBookException(e.getMessage());
			}
		}
		return idList;
	}

}
