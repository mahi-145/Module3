package com.capgemini.contact.service;

import com.capgemini.contact.bean.ApplicationBean;
import com.capgemini.contact.exception.ApplicationException;

public interface ApplyService {

	public int addApplicantDetails(ApplicationBean applicant) throws ApplicationException;
	public ApplicationBean getApplicationDetails(long applicationID) throws ApplicationException;
	public boolean isValidApplicatnt(ApplicationBean applicant) throws ApplicationException;
	
}
