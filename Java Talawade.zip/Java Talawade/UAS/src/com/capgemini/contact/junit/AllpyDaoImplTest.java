package com.capgemini.contact.junit;

import junit.framework.Assert;

import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.apply.dao.ApplyDao;
import com.capgemini.apply.dao.ApplyDaoImpl;
import com.capgemini.contact.bean.ApplicationBean;
import com.capgemini.contact.exception.ApplicationException;

public class AllpyDaoImplTest {

	static ApplyDao appDao = null;
	static ApplicationBean appBean = null;
	
	@BeforeClass
	public static void beforeClass() {
		appDao = new ApplyDaoImpl();
		appBean = new ApplicationBean();
	
	}
	
	@Test
	public void testAddApp1() throws ApplicationException {
		
		Assert.assertEquals(1003, appDao.addApplicantDetails(appBean));
	}
	
	@Test(expected = Exception.class)
	public void testAddApp2() throws ApplicationException {
		
		Assert.assertEquals(6, appDao.addApplicantDetails(appBean));
	}
	
	@Test
	public void testAddApp3() throws ApplicationException {
		Assert.assertNotNull(appDao.addApplicantDetails(appBean));
	}
	
	@Test
	public void testGetApp1() throws ApplicationException {
		Assert.assertEquals(1,appDao.getApplicationDetails(1001));
	}
	@Test
	public void testGetApp2() throws ApplicationException {
		Assert.assertEquals(appBean.toString(),appDao.getApplicationDetails(1006));
	}
	@Test(expected = Exception.class)
	public void testGetApp3() throws ApplicationException {
		Assert.assertEquals(appBean,appDao.getApplicationDetails(5000));
	}
	
	@Test(expected = Exception.class)
	public void testGetApp4() throws ApplicationException {
		Assert.assertNotNull(appDao.getApplicationDetails(5000));
	}
}
