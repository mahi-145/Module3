import java.util.Random;


public class AccountTestDemo {

	public static void main(String[] args) 
	{
		Random rand=new Random();
		int n=rand.nextInt(50)+1;
		
		Account ac1=new Account(n,20000,new Person("Smith",40));
		Account ac2=new Account(n,40000,new Person("Kathy",40));
		
		ac1.deposit(2000);
		ac1.withdraw(4000);
		
		System.out.println(ac1);
		System.out.println(ac2);

	}

}
