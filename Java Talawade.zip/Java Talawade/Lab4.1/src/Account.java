
public class Account 

{
	private long accNum;
	private double balance;
	Person person;
	
	public Account()
	{
		
	}
	

	public Account(long accNum, double balance, Person accHolder) {
		super();
		this.accNum = accNum;
		this.balance = balance;
		this.person = person;
	}


	public long getAccNum() {
		return accNum;
	}

	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public Person getperson() {
		return person;
	}

	public void setAccHolder(Person accHolder) {
		this.person = person;
	}
	public void deposit(float deposit)
	{
		balance=balance+deposit;
	}
	public void withdraw(float withdraw)
	{
		balance=balance-withdraw;
	}


	@Override
	public String toString() {
		return "Account [accNum=" + accNum + ", balance=" + balance
				+ ", person=" + person + "]";
	}
	
}
