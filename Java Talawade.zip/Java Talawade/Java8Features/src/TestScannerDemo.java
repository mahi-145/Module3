import java.util.Scanner;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.Supplier;
@FunctionalInterface
interface MaxFiner
{
	public int max(int num1,int num2);
}

/*class MaxFinerImpl implements MaxFiner    its not required
{

	@Override
	public int max(int num1, int num2) 
	{
		return num1>num2?num1:num2;
	}
	
}*/
public class TestScannerDemo
{

	public static void main(String[] args)
	{
	/*	try(Scanner sc=new Scanner(System.in))
		{
			try()
			{
				
			}
		}*/
		MaxFiner mf=(num1,num2)->num1>num2?num1:num2;     //Lmbda Expression
		System.out.println("greated number is "
		+mf.max(60,90));
		/*MaxFiner mf=new MaxFinerImpl();
		int max=mf.max(90, 80);
		System.out.println("Maximum od 2 numbers:"+max);*/
		Consumer<String> consumer= (String str)-> 
		System.out.println(str);
		consumer.accept("Welcome");
		
		Supplier<String> sup=()->"Happy New Year";
		System.out.println(sup.get());
		
		BiFunction<Integer,Integer,Integer> biFunctiona=(x,y)->x>y?x:y;
		System.out.println("Greatest number is:"+biFunctiona.apply(90,80));
		
		Predicate<Integer> predicate=(num)->num%2==0;
		
		System.out.println("is 4 even number?"+predicate.test(4));
		System.out.println("is 3 even number?"+predicate.test(3));
		System.out.println("is 4 odd number?"+predicate.test(4));
		System.out.println("is 3 odd number?"+predicate.test(3));
		
	
	}

}
