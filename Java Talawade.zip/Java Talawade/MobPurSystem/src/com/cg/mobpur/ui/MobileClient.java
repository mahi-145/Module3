package com.cg.mobpur.ui;

import java.util.ArrayList;
import java.util.Scanner;

import oracle.net.aso.e;

import com.cg.mobpur.bean.Mobile;
import com.cg.mobpur.exception.MobileException;
import com.cg.mobpur.bean.Mobile;
import com.cg.mobpur.bean.Purchase;
import com.cg.mobpur.exception.MobileException;
import com.cg.mobpur.service.MobileService;
import com.cg.mobpur.service.MobileServiceImpl;

public class MobileClient
{
	static Scanner sc=null;
	static MobileService mobSer=null;
	public static void main(String[] args) throws MobileException
	{
		mobSer=new MobileServiceImpl();
		sc=new Scanner(System.in);
		int choice;
		while(true)
		{
			System.out.println("What do you want to do?");
			System.out.println("1:Add Customer\t"
								+"2:Fetch All details\t "
								+ "3:Delete mobile\t"
								+ "4:Search Mobile\t "
								+ "5:Exit");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1: insertCust();
			break;
			case 2: fetchAllMob();
				break;
			case 3: deleteMob();
				break;
			case 4: SearchMob(); 
			break;
			default: System.exit(0);
			}

		}

	}
	
	private static void SearchMob() 
	{
		System.out.println("Enter min price:");
		float price1=sc.nextFloat();
		System.out.println("Enter max price:");
		float price2=sc.nextFloat();
		try
		{
			ArrayList<Mobile> mobList= mobSer.searchMob(price1,price2);
			for(Mobile mb:mobList)
			{
				System.out.println(mb);
			}
		} 
		catch (Exception m)
		{
			System.out.println(m.getMessage());
			
		}
	}


	/*********main ends************/
	public static void insertCust()
	{
		System.out.println("Enter Customer Name: ");
		String cnm=sc.next();
		try
		{
			if(mobSer.validateName(cnm))
			{
				System.out.println("Enter Mail Id: ");
				String email=sc.next();

				if(mobSer.validateMail(email))
				{
					System.out.println("Enter mobile number");
					long phone=sc.nextLong();
					if(mobSer.validatePhone(phone))
					{
						System.out.println("Enter mobile Id:");
						int mobId=sc.nextInt();
						Purchase pd=new Purchase();
						pd.setcName(cnm);
						pd.setMailId(email);
						pd.setPhoneNo(phone);
						pd.setmobileId(mobId);

						int dataAdded=mobSer.addPur(pd);
						if(dataAdded==1)
						{
							System.out.println("CustData added");
						}
						else
						{
							System.out.println("May be some Exception while adding the employee");
						}
					}
				}
			}
		}
		catch(MobileException e)	
		{
			System.out.println(e.getMessage());
		}
	}
	/*********insert ends************/
	public static void fetchAllMob()
	{
		try
		{
			ArrayList<Mobile> mobList= mobSer.getAllMob();
			for(Mobile mb:mobList)
			{
				System.out.println(mb);
			}
		} 
		catch (MobileException m)
		{
			System.out.println("May be some Exception while fetching the employee");
			m.printStackTrace();
		}
	}
	/*********fetch ends************/
	public static void deleteMob()  
	/*********delete ends**********/
	{
		System.out.println("Enter Mobile Id: ");
		int mobId=sc.nextInt();
		try
		{
			Mobile mb=new Mobile();
			mb.setMobileId(mobId);
			int dataDeleted=mobSer.deleteMob(mb);
			if(dataDeleted==1)
				System.out.println("Mobile data deleted");
			else
				System.out.println("May be some Exception while adding the employee");
		}
		catch (Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
}


