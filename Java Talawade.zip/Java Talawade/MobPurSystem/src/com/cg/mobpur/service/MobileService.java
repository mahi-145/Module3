package com.cg.mobpur.service;

import java.util.ArrayList;

import com.cg.mobpur.bean.Mobile;
import com.cg.mobpur.bean.Purchase;
import com.cg.mobpur.exception.MobileException;

public interface MobileService 
{
	public int addMob(Mobile mob)throws MobileException;
	
	public ArrayList<Mobile> getAllMob()throws MobileException;
	
	public int generatepurchaseId()throws MobileException;
			
	
	public boolean validateMail(String mailId)throws MobileException;
	
	public boolean validateName(String cName)throws MobileException;

	public boolean validatePhone(long phoneNo) throws MobileException;

	public int addPur(Purchase pur) throws MobileException;

	boolean validateDigit(int mobId) throws MobileException;

	public int deleteMob(Mobile Mob) throws MobileException;


	ArrayList<Mobile> searchMob(float priceone, float pricetwo)
			throws MobileException;
	
	
	
}
