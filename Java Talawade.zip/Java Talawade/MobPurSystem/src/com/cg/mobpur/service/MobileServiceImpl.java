package com.cg.mobpur.service;

import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.mobpur.exception.MobileException;
import com.cg.mobpur.dao.MobDao;
import com.cg.mobpur.dao.MobDaoImpl;
import com.cg.mobpur.bean.Mobile;
import com.cg.mobpur.bean.Purchase;
import com.cg.mobpur.dao.MobDao;
import com.cg.mobpur.dao.MobDaoImpl;
import com.cg.mobpur.exception.MobileException;

public class MobileServiceImpl implements MobileService
{
	MobDao mobDao=null;
	public MobileServiceImpl()
	{
		mobDao=new MobDaoImpl();
	}
	@Override
	public int addMob(Mobile mob) throws MobileException
	{
		return mobDao.addMob(mob);
	}

	@Override
	public ArrayList<Mobile> getAllMob() throws MobileException
	{
		return mobDao.getAllMob();
	}

	@Override
	public int generatepurchaseId() throws MobileException 
	{
		return mobDao.generatepurchaseId();
	}

	@Override
	public boolean validateDigit(int mobId) throws MobileException 
	{
	String numPattern="[0-9]{4}";
	if(Pattern.matches(numPattern, new Integer(mobId).toString())) 
		{
			return true;
		}
	else 
	{
		throw new MobileException("Only Min 4 digits allowed in empId");
	}
	
}

	@Override
	public boolean validateMail(String mailId) throws MobileException 
	{
		String mailPattern="^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
				+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
		if(Pattern.matches(mailPattern, mailId))
		{
			return true;
		}
	else 
	{
		throw new MobileException("Only valid emailId is allowed");
	}
		
	}

	@Override
	public boolean validatePhone(long phoneNo) throws MobileException 
	{
		String numPattern="[7-9][0-9]{9}";
		if(Pattern.matches(numPattern, new Long(phoneNo).toString()))
		{
			return true;
		}
	else 
	{
		throw new MobileException("phone no should have 10 digits");
	}
		
	}

	@Override
	public boolean validateName(String cName) throws MobileException 
	{
		String namePattern="[A-Z][a-z]{1,20}";
		if(Pattern.matches(namePattern, cName))
		{
			return true;
		}
		else
		{
			throw new MobileException("Only Chars allowed and starts with capital "
					+ "e.g Anindita");
		}
	}
	@Override
	public int addPur(Purchase pur) throws MobileException 
	{
		return mobDao.addPur(pur) ;
	}
	@Override
	public int deleteMob(Mobile Mob) throws MobileException
	{
		return mobDao.deleteMob(Mob);
	}

	@Override
	public ArrayList<Mobile> searchMob(float priceone, float pricetwo)
			throws MobileException 
	{
		return mobDao.searchMob(priceone, pricetwo);
	}
	
	
	
	

}
