package com.cg.mobpur.junit;

import junit.framework.Assert;

import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.mobpur.bean.Mobile;
import com.cg.mobpur.bean.Purchase;
import com.cg.mobpur.dao.MobDao;
import com.cg.mobpur.dao.MobDaoImpl;
import com.cg.mobpur.exception.MobileException;



public class MobDaoImplTest 
{
	static Purchase pur=null;
    static MobDao mobDao = null;
    static Mobile mob = null;
    
    @BeforeClass
    public static void beforeClass()
    {
        
        mobDao = new MobDaoImpl();
        mob = new Mobile();
    }
    
    @Test
    public void testAddMob1() throws MobileException {
		Assert.assertEquals(1, mobDao.addPur(pur));
    }
    
    @Test(expected = Exception.class)
    public void testAddMob2() throws Exception {
        
        Assert.assertEquals(1, mobDao.addPur(pur));
    }
    
    
    @Test
    public void testAddMob3() throws MobileException {
        Assert.assertNotNull(mobDao.addPur(pur));
    }
    
    @Test
    public void testDeleteMob1() throws MobileException {
        Assert.assertEquals(1,mobDao.deleteMob(mob));
    }
    
    @Test
    public void testDeleteMob2() throws MobileException {
        Assert.assertEquals(0,mobDao.deleteMob(mob
        		));
    }

    @Test
    public void testgeneratedId() throws MobileException {
        Assert.assertEquals(1041,mobDao.generatepurchaseId());
    }
    
//  @Test
//  public void testGetdata() throws MobileException {
//      Assert.assertEquals(1,mobDao.getAllMobDetails(7000,20000));
//  }
//  
//  @Test
//  public void testGetMob3() throws MobileException {
//      Assert.assertEquals(1,mobDao.getAllMobDetails());
//  }
    
}
