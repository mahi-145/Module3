package com.cg.mobpur.bean;

public class Mobile 
{
	private int mobileId;
	private String Name;
	private float price;
	private int quantity;
	public int getMobileId() 
	{
		return mobileId;
	}
	public void setMobileId(int mobileId)
	{
		this.mobileId = mobileId;
	}
	public String getName()
	{
		return Name;
	}
	public void setName(String name) 
	{
		Name = name;
	}
	public float getPrice()
	{
		return price;
	}
	public void setPrice(float price) 
	{
		this.price = price;
	}
	public int getQuantity() 
	{
		return quantity;
	}
	public void setQuantity(int quantity)
	{
		this.quantity = quantity;
	}
	@Override
	public String toString() 
	{
		return "Mobile [mobileId=" + mobileId + ", Name=" + Name + ", price="
				+ price + ", quantity=" + quantity + "]";
	}
	public Mobile(int mobileId, String name, float price, int quantity)
	{
		super();
		this.mobileId = mobileId;
		Name = name;
		this.price = price;
		this.quantity = quantity;
	}
	public Mobile() 
	{
		super();
		
	}
	

}
