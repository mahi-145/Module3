package com.cg.mobpur.bean;

import java.sql.Date;


public class Purchase 
{
	private int purchaseId;
	private String cName;
	private String mailId;
	private long phoneNo;
	private Date purchaseDate;
	private int mobileId;
	public int getPurchaseId() 
	{
		return purchaseId;
	}
	public void setPurchaseId(int purchaseId)
	{
		this.purchaseId = purchaseId;
	}
	public String getcName()
	{
		return cName;
	}
	public void setcName(String cName) 
	{
		this.cName = cName;
	}
	public String getMailId()
	{
		return mailId;
	}
	public void setMailId(String mailId) 
	{
		this.mailId = mailId;
	}
	public long getPhoneNo() 
	{
		return phoneNo;
	}
	public void setPhoneNo(long phoneNo) 
	{
		this.phoneNo = phoneNo;
	}
	public Date getPurchaseDate() 
	{
		return purchaseDate;
	}
	public void setPurchaseDate(Date purchaseDate) 
	{
		this.purchaseDate = purchaseDate;
	}
	public int getmobileId() 
	{
		return mobileId;
	}
	public void setmobileId(int mobileId) 
	{
		this.mobileId = mobileId;
	}
	public Purchase(int purchaseId, String cName, String mailId, long phoneNo,
			Date purchaseDate,int mobileId) 
	{
		super();
		this.purchaseId = purchaseId;
		this.cName = cName;
		this.mailId = mailId;
		this.phoneNo = phoneNo;
		this.purchaseDate = purchaseDate;
		this.mobileId=mobileId;
	}
	public Purchase() 
	{
		super();
		
	}
	@Override
	public String toString() 
	{
		return "Customer [purchaseId=" + purchaseId + ", cName=" + cName
				+ ", mailId=" + mailId + ", phoneNo=" + phoneNo
				+ ", purchaseDate=" + purchaseDate + "]";
	}
	
	

}
