package com.cg.mobpur.dao;

import java.util.ArrayList;

import com.cg.mobpur.bean.Mobile;
import com.cg.mobpur.bean.Purchase;
import com.cg.mobpur.exception.MobileException;
import com.cg.mobpur.bean.Mobile;
import com.cg.mobpur.exception.MobileException;

public interface MobDao 
{
	public int addMob(Mobile Mob) throws MobileException; 
	
	public ArrayList<Mobile> getAllMob()throws MobileException;
	
	public int updateMob(int Mob)throws MobileException;
	
	public int insertMob(Mobile Mob)throws MobileException;
	
	public int addMob(Purchase Mob)throws MobileException;
	
	public int generatepurchaseId()throws MobileException;
	
	public int addPur(Purchase pur) throws MobileException;
	
	public int deleteMob(Mobile Mob) throws MobileException;

	ArrayList<Mobile> searchMob(float priceone, float pricetwo)
			throws MobileException;
	
	
	

}
