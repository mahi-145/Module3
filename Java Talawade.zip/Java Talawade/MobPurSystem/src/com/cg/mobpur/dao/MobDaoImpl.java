package com.cg.mobpur.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.mobpur.exception.MobileException;
import com.cg.mobpur.bean.Mobile;
import com.cg.mobpur.bean.Purchase;
import com.cg.mobpur.exception.MobileException;
import com.cg.mobpur.exception.MobileException;
import com.cg.mobpur.util.DBUtil;
import com.cg.mobpur.bean.Mobile;
import com.cg.mobpur.exception.MobileException;


public class MobDaoImpl implements MobDao
{
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	Logger mobLogger=null;
	
	public MobDaoImpl()
	{
		PropertyConfigurator.configure("resources/log4j.properties");
		mobLogger=Logger.getLogger("MobDaoImpl.class");
	}

	@Override
	public int addPur(Purchase pur) throws MobileException
	{
		int dataAdded=0;
		String insertQry="INSERT INTO purchasedetails"
				+ "(purchaseid,cname,mailid,phoneNo,purchasedate,mobileid) "
				+ "VALUES(?,?,?,?,sysdate,?)";
		try 
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(insertQry);
			pst.setInt(1,generatepurchaseId());
			pst.setString(2,pur.getcName());
			pst.setString(3, pur.getMailId());
			pst.setFloat(4,pur.getPhoneNo());
			pst.setInt(5, pur.getmobileId());
			
			
			dataAdded=pst.executeUpdate();
			//System.out.println("dataAdded");
			mobLogger.log(Level.INFO, "PurInserted: "+pur);
		} 
		catch (Exception e) 
		{
			throw new MobileException(e.getMessage());
		}
		finally
		{
		try
			{
			pst.close();
			con.close();
			} 
			catch (SQLException e) 
			{
				mobLogger.error("This is exception"+e.getMessage());
				throw new MobileException(e.getMessage());
			}
		}
		return dataAdded;
	}
	@Override
	public int updateMob(int mobId) throws MobileException 
	{
		String updateQry="UPDATE mobiles set quantity=quantity-1 where mobileId=?";
		int dataUpdated=0;
		try 
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(updateQry);
			pst.setInt(1,mobId);
			dataUpdated=pst.executeUpdate();
			
		} 
		catch (Exception e) 
		{
			throw new MobileException(e.getMessage());
		} 
		finally
		{
			try 
			{
				pst.close();
				con.close();
			} 
			catch (Exception e) 
			{
				throw new MobileException(e.getMessage());
			}
		}
		return dataUpdated;
	}

	@Override
	public ArrayList<Mobile> getAllMob() throws MobileException 
	{
		ArrayList<Mobile> mobList= new ArrayList<Mobile>();
		String selectQry="select * from mobiles";
		Mobile mb=null;
		try 
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			while(rs.next())
			{
				mb= new Mobile(rs.getInt("mobileId"),rs.getString("Name"),
						rs.getFloat("price"),rs.getInt("quantity"));
				mobList.add(mb);
			}
		} 
		catch (Exception e)
		{
			throw new MobileException(e.getMessage());
		}
		finally
		{
			try
			{
				rs.close();
				st.close();
				con.close();
			} 

			catch (SQLException e)
			{
				throw new MobileException(e.getMessage());
			}
		
		}
		return mobList;
	}


	
	/*@Override
	public int insertMob(Mobile Mob) throws MobileException
	{
		// TODO Auto-generated method stub
		return 0;
	}*/

	@Override
	public int deleteMob(Mobile Mob) throws MobileException 
	{
		String deleteQry="Delete from mobiles where mobileId=?";
		int dataDeleted;
	
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(deleteQry);
			pst.setInt(1,Mob.getMobileId());
			dataDeleted=pst.executeUpdate();
		}
		
			catch (Exception e) 
			{
				throw new MobileException(e.getMessage());
			}
			finally
			{
				try
				{
					pst.close();
					con.close();
				} 

				catch (SQLException e)
				{
					throw new MobileException(e.getMessage());
				}
			
			}
			return dataDeleted;

	}

	@Override
	public ArrayList<Mobile> searchMob(float price1, float price2) throws MobileException
	{
		ArrayList<Mobile> mobList= new ArrayList<Mobile>();
		String insertQry="Select * from mobiles where price between ? and ?";
		Mobile mSearch=null;
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(insertQry);
			pst.setFloat(1,price1);
			pst.setFloat(2,price2);
			rs=pst.executeQuery();
			while(rs.next())
			{
				mSearch=new Mobile(rs.getInt("mobileId"),rs.getString("Name"),
						rs.getFloat("price"),rs.getInt("quantity"));
			}
		}
		catch (Exception e) 
		{
			throw new MobileException(e.getMessage());
		}
		
		return mobList;
	}

	@Override
	public int addMob(Purchase Mob) throws MobileException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int generatepurchaseId() throws MobileException 
	{
		String qry="Select pur_seq.NEXTVAL FROM DUAL";
		int generatedVal;
		try 
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(qry);
			rs.next();
			generatedVal=rs.getInt(1);
			
		} 
		catch (Exception e)
		{
			throw new MobileException(e.getMessage());
		} 
		finally
		{
			try
			{
				rs.close();
				st.close();
				con.close();
			} 
			catch (SQLException e)
			{
				throw new MobileException(e.getMessage());
			}
		}
		return generatedVal;
	}

	@Override
	public int addMob(Mobile Mob) throws MobileException {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public int insertMob(Mobile Mob) throws MobileException {
		// TODO Auto-generated method stub
		return 0;
	}
	



	



}