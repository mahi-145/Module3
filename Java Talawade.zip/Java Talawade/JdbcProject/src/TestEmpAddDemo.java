import java.sql.*;


public class TestEmpAddDemo 
{

	public static void main(String[] args) 
	{
		//load oracle type 4 driver in memory
		Connection con=null;
		Statement st=null;
		try 
		{
			Class.forName
			("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection
					("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
			String insertQry="INSERT INTO emp_142409("+"emp_id,emp_name,emp_sal)"+" "
					+ "Values(666,'Kavita',80000)";
					st=con.createStatement();
					int data=st.executeUpdate(insertQry);
					System.out.println("data inserted in table:"+data);
		} 
		catch (Exception e)
		{
			
			e.printStackTrace();
		}

	}


}
