import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;


public class TestResuSetMetadaDemo 
{

	public static void main(String[] args) 
	{
		//load oracle type 4 driver in memory
		Connection con=null;
		Statement st=null;
		ResultSet rs=null;
		ResultSetMetaData rsmd=null;
		try 
		{
			Class.forName
			("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection
					("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
			st=con.createStatement();
			rs=st.executeQuery("SELECT * FROM Emp_142409");
			rsmd=rs.getMetaData();
			int ColumnCount=rsmd.getColumnCount();
			System.out.println("No of columns :"+rsmd.getColumnCount());
			for(int i=0;i<ColumnCount;i++)
			{
				System.out.println(i+"Column Name: "+rsmd.getColumnName(i));
				
				System.out.println(i+"Column Type: "+rsmd.getColumnType(i));
				
				System.out.println(i+"Column Type Name: "+rsmd.getColumnTypeName(i));
				
				System.out.println(i+"Column Label: "+rsmd.getColumnLabel(1));
			}
			
		}
		catch (Exception e)
		{
			
			e.printStackTrace();
		}

}
}

