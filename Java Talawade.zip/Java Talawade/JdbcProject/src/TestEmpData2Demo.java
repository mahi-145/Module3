import java.sql.*;
import java.util.Scanner;


public class TestEmpData2Demo 
{

	public static void main(String[] args) 
	{
		//load oracle type 4 driver in memory
		Scanner sc=null;
		Connection con=null;
		PreparedStatement pst;
		try 
		{
			sc=new Scanner(System.in);
			Class.forName
			("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection
					("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
			System.out.println("Enter the no of employees: ");
			int i=sc.nextInt();
			for(i=0;i<3;i++)
			{
			System.out.println("Enter id:");
			int empId=sc.nextInt();
			System.out.println("Enter name:");
			String empName=sc.next();
			System.out.println("Enter salary:");
			float empSal=sc.nextFloat();
			String insertQry="INSERT INTO Emp_142409(emp_id,emp_name,emp_sal)VALUES"
					+"(?,?,?)";
			
			pst=con.prepareStatement(insertQry);
			pst.setInt(1, empId);//1,2,3 is for question during insertion
			pst.setString(2, empName);
			pst.setFloat(3, empSal);
			int dataAdded=pst.executeUpdate();
			System.out.println("Data added...");
		} 
		}
		catch (Exception e)
		{
			
			e.printStackTrace();
		}

	}


}
