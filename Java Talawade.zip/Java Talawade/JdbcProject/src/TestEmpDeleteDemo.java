import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;


public class TestEmpDeleteDemo 
{

		public static void main(String[] args) 
		{
			//load oracle type 4 driver in memory
			Scanner sc=null;
			Connection con=null;
			PreparedStatement pst=null;
			try 
			{
				sc=new Scanner(System.in);
				Class.forName
				("oracle.jdbc.driver.OracleDriver");
				con=DriverManager.getConnection
						("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
	
				
				String deleteQry="DELETE FROM Emp_142409 where Emp_id=666";
				
				pst=con.prepareStatement(deleteQry);
				pst.executeUpdate();
				System.out.println("Data deleted...");
			} 
	
			catch (Exception e)
			{
				
				e.printStackTrace();
			}

		}


	}

