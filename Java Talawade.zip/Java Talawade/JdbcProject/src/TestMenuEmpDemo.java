import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;


public class TestMenuEmpDemo
{
    public static void main(String[] args) 
    {
        Connection con=null;
        Statement st = null;
        PreparedStatement pst = null;
        String menu=null;
        Scanner sc=new Scanner(System.in);
        System.out.println("Which menu u want to access ?"+menu+" Is?"+"1 \t 2 \t 3 \t 4 \t");
        System.out.println("Enter ur choice:");
        int choice=sc.nextInt();
    
            switch(choice)
            {
            case 1:
            {
                try 
                    {
                    Class.forName("oracle.jdbc.driver.OracleDriver");
                    con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
                        String insertQry="INSERT INTO EMP_142961(emp_id,emp_name,emp_sal)VALUES(666,'Kavita S',80000)";
                        st=con.createStatement();
                        int data=st.executeUpdate(insertQry);
                        System.out.println("Data Inserted in table:"+data);
                    }
                
                catch (Exception e) 
                    {
                
                        e.printStackTrace();
                    }
                break;
            }
            case 2:
            {   
                try 
                {
                    Class.forName("oracle.jdbc.driver.OracleDriver");
                    con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
                    System.out.println("Enter no of employees:");
                    int n=sc.nextInt();
                    String insertQry="INSERT INTO EMP_142961(emp_id,emp_name,emp_sal)VALUES(?,?,?)";

                    pst=con.prepareStatement(insertQry);
                    {

                        System.out.println(" Enter Id:");
                        int empId=sc.nextInt();
                        System.out.println(" Enter Name:");
                        String empName=sc.next();
                        System.out.println(" Enter Salary:");
                        float empSal=sc.nextFloat();

                        pst.setInt(1, empId);
                        pst.setString(2, empName);
                        pst.setFloat(3, empSal);
                        int dataAdded=pst.executeUpdate();
                        
                    }
                    System.out.println("Data is added...");
                }
                    
                    catch (Exception e) 
                    {   
                        e.printStackTrace();
                    }
                break;
            }
            case 3:
            {
                try 
                {
                    Class.forName("oracle.jdbc.driver.OracleDriver");
                    con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
                    
                    String updateQry="UPDATE Emp_142961 SET emp_sal = emp_sal+10000 WHERE emp_sal<20000";
                    st = con.createStatement();
                    int data=st.executeUpdate(updateQry);
                    System.out.println("Data is Updated in table:"+data);
                }
                    
                catch (Exception e) 
                {
                    e.printStackTrace();
                }
                break;
            }
            case 4:
            {
                try 
                {
                    sc=new Scanner(System.in);
                    Class.forName("oracle.jdbc.driver.OracleDriver");
                    con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
                    {
                    String deleteQry="DELETE FROM EMP_142961 WHERE emp_Id=666";
                    pst=con.prepareStatement(deleteQry);
                
                    int data=pst.executeUpdate(deleteQry);
                    System.out.println("Data is deleted...");
                    }
                }   
                catch (Exception e) 
                {   
                    e.printStackTrace();
                }
                break;
            }
            default:
                    System.exit(0);
            }
        } 
    }

