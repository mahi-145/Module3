import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;


public class TestEmpUpdateEmp
{
		public static void main(String[] args) 
		{
			//load oracle type 4 driver in memory
			Connection con=null;
			Statement st=null;
			try 
			{
				Class.forName
				("oracle.jdbc.driver.OracleDriver");
				con=DriverManager.getConnection
						("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
				String updateQry="Update Emp_142409 set emp_sal =10000 where emp_sal<20000";
						st=con.createStatement();
						int data=st.executeUpdate(updateQry);
						System.out.println("data updated in table:"+data);
			} 
			catch (Exception e)
			{
				
				e.printStackTrace();
			}

		}

	}

