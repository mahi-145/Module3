import java.sql.*;
public class TestEmpSelectDemo 
{

	public static void main(String[] args) 
	{
		//load oracle type 4 driver in memory
		Connection con=null;
		Statement st=null;
		ResultSet rs=null;
		try 
		{
			Class.forName
			("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection
					("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
			st=con.createStatement();
			String selQry="Select * from Emp_142409";
			rs = st.executeQuery(selQry);
			System.out.println("Id\t Name\t Salary\t Doj");
			while(rs.next())
			{
			System.out.println(rs.getInt(1)+
					"\t "+rs.getString("Emp_Name")+
					"\t "+rs.getInt("Emp_Sal")+
					"\t "+rs.getDate("Emp_Doj"));
			}
		} 
		catch (Exception e)
		{
			
			e.printStackTrace();
		}

	}

}
