package com.cg.mcam.service;


import java.util.ArrayList;
import java.util.regex.Pattern;
import com.cg.mcam.bean.Artist_Master;
import com.cg.mcam.bean.Composer_Master;
import com.cg.mcam.bean.Song_Master;
import com.cg.mcam.dao.MediaDao;
import com.cg.mcam.dao.MediaDaoImpl;
import com.cg.mcam.exception.MediaException;

public class MediaServiceImpl implements MediaService

{


	MediaDao medDao=null;
    public MediaServiceImpl()
    {
    	medDao=new MediaDaoImpl();
    }
	@Override
	public int addSongs(Song_Master sm) throws MediaException 
	{
	
		return medDao.addSongs(sm);
	}
	
	@Override
	public ArrayList<Song_Master> getAllSongs() throws MediaException 
	{
		
		return medDao.getAllSongs();
	}
	
	@Override
	public int deleteSong(int id) throws MediaException {
		
		return medDao.deleteSong(id);
	}
	
	@Override
	public int addComposer(Composer_Master cm) throws MediaException 
	{
		
		return medDao.addComposer(cm);
	}
	
	@Override
	public Song_Master getSong(int song_id) throws MediaException, Exception 
	{
		Song_Master sm2=new Song_Master();
		sm2=medDao.getSong(song_id);
		return sm2;
	}
	
	@Override
	public int addArtist(Artist_Master am) throws MediaException 
	{
		
		return medDao.addArtist(am);
	}
	
	@Override
	public Composer_Master getComposer(int composer_Id) throws MediaException 
	{
		
		return medDao.getComposer(composer_Id);
	}
	
	@Override
	public Artist_Master getArtist(int artist_Id) throws MediaException 
	{
		
		return medDao.getArtist(artist_Id);
	}
	@Override
	public int getUserId() throws MediaException {
		// TODO Auto-generated method stub
		return medDao.getUserId();
	}
	@Override
	public String getUserPwd() throws MediaException {
		// TODO Auto-generated method stub
		return medDao.getUserPwd();
	}
	@Override
	public int getAdminId() throws MediaException {
		// TODO Auto-generated method stub
		return medDao.getAdminId();
	}
	@Override
	public String getAdminPwd() throws MediaException {
		// TODO Auto-generated method stub
		return medDao.getAdminPwd();
	}
	@Override
	public boolean validateUserId(int user_id) throws MediaException 
	{
		int namePattern=medDao.getUserId();
		if(namePattern==user_id)
		{
			return true;
		}
		else
		{
			throw new MediaException("Invalid user id");
		}
	}
	@Override
	public boolean validateAdminId(int adminId) throws MediaException 
	{
		int namePattern=medDao.getAdminId();
		if(namePattern==adminId)
		{
			return true;
		}
		else
		{
			throw new MediaException("Invalid Admin id");
		}	}
	@Override
	public boolean validateUserPwd(String userPwd) throws MediaException
	{
		String namePattern=medDao.getUserPwd();
		if(Pattern.matches(namePattern,userPwd))
		{
			return true;
		}
		else
		{
			throw new MediaException("Invalid user password");
		}
	}
	@Override
	public boolean validateAdminPwd(String adminPwd) throws MediaException 
	{
		String namePattern=medDao.getAdminPwd();
		if(Pattern.matches(namePattern,adminPwd))
		{
			return true;
		}
		else
		{
			throw new MediaException("Invalid Admin password");
		}
	}
	
	
	
	

}
