package com.cg.mcam.bean;

import java.sql.Date;

public class User_Master
{
	private int user_Id;
	private String user_Password;

	
	public int getUser_Id() {
		return user_Id;
	}
	public void setUser_Id(int user_Id) {
		this.user_Id = user_Id;
	}
	public String getUser_Password()
	{
		return user_Password;
	}
	public void setUser_Password(String user_Password) 
	{
		this.user_Password = user_Password;
	}

	public User_Master() {
		super();
		// TODO Auto-generated constructor stub
	}
	public User_Master(int user_Id, String user_Password) {
		super();
		this.user_Id = user_Id;
		this.user_Password = user_Password;
	}

	
	
}
