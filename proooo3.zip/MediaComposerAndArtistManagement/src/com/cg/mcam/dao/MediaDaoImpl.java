package com.cg.mcam.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.print.attribute.standard.Media;
import com.cg.mcam.bean.Artist_Master;
import com.cg.mcam.bean.Composer_Master;
import com.cg.mcam.bean.Song_Master;
import com.cg.mcam.exception.MediaException;
import com.cg.mcam.util.DBUtil;

public class MediaDaoImpl implements MediaDao

{

	Connection con=null;
	Statement st=null;
	ResultSet rs=null;
	PreparedStatement pst=null;

/*************************************************Add Composer******************************************************/

	@Override
	public int addComposer(Composer_Master cm) throws MediaException
	{
		{
			String insertQry="Insert Into Composer_Master(composer_Id,composer_Name,composer_Born_Date,composer_Died_Date,composer_Caeipi_Number,Created_by,Created_on,Updated_by,Updated_on) Values(?,?,?,sysdate,?,?,sysdate,?,sysdate)";
			int composerAdded=0;
			try 
			{
				con=DBUtil.getCon();
				pst=con.prepareStatement(insertQry);
				pst.setInt(1,generateComposerId());
				pst.setString(2, cm.getComposer_Name());
				pst.setString(3, cm.getComposer_Born_Date());
				pst.setString(4, cm.getComposer_Caeipi_Number());
				pst.setInt(5,cm.getCreated_by());
				pst.setInt(6,cm.getUpdated_by());


				composerAdded=pst.executeUpdate();


			} 
			catch (Exception e) 
			{
				throw new MediaException(e.getMessage());
			} 
			finally
			{
				try 
				{
					pst.close();
					con.close();
				} 
				catch (SQLException e) 
				{
					throw new MediaException(e.getMessage());
				}
			}

			return composerAdded;
		}
	}

	/***********************************Add Artist****************************************************/
	
	@Override
	public int addArtist(Artist_Master am) throws MediaException {
		
		{
			String insertQry="Insert Into Artist_Master(artist_Id,artist_Name,artist_Type,artist_Born_Date,artist_Died_Date,created_by,created_on,updated_by,updated_on) Values(?,?,?,sysdate,?,?,sysdate,?,sysdate)";
			int ArtistAdded=0;
			try 
			{
				con=DBUtil.getCon();
				pst=con.prepareStatement(insertQry);
				pst.setInt(1,generateArtistId());
				pst.setString(2, am.getArtist_Name());
				pst.setString(3, am.getArtist_Type());
				pst.setString(4, am.getArtist_Born_Date());
				pst.setDate(5,am.getArtist_Died_Date());
				pst.setInt(6,am.getCreated_By());
				pst.setInt(7, am.getUpdated_By());


				ArtistAdded=pst.executeUpdate();


			} 
			catch (Exception e) 
			{
				throw new MediaException(e.getMessage());
			} 
			finally
			{
				try 
				{
					pst.close();
					con.close();
				} 
				catch (SQLException e) 
				{
					throw new MediaException("Some error occured while adding"+e.getMessage());
				}
			}

			return ArtistAdded;
		}
	
	}
	/*********************************Add Song*****************************************************/	
	@Override
	public int addSongs(Song_Master sm) throws MediaException 
	{
		{
			String insertQry="Insert Into Song_Master(song_id,song_name,song_duration,Created_by,Created_on,Updated_by,Updated_on) Values(?,?,?,?,sysdate,?,sysdate)";
			int songAdded=0;
			try 
			{
				con=DBUtil.getCon();
				pst=con.prepareStatement(insertQry);
				pst.setInt(1, generateSongId());
				pst.setString(2, sm.getSong_name());
				pst.setString(3, sm.getSong_duration());
				pst.setInt(4, sm.getCreated_by());
				pst.setInt(5, sm.getUpdated_by());

				songAdded=pst.executeUpdate();


			} 
			catch (Exception e) 
			{
				throw new MediaException(e.getMessage());
			} 
			finally
			{
				try 
				{
					pst.close();
					con.close();
				} 
				catch (SQLException e) 
				{
					throw new MediaException(e.getMessage());
				}
			}

			return songAdded;
		}
	}


	/************************************************Generate Song id***********************************************/
	@Override
	public int generateSongId() throws MediaException

	{
		String qry="Select songs_id.NextVal From Dual";

		int generatedSongsId;
		try 
		{

			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(qry);
			rs.next();
			generatedSongsId=rs.getInt(1);

		} 

		catch (Exception e) 
		{

			throw new MediaException(e.getMessage());

		}

		finally
		{
			try
			{
				rs.close();
				st.close();
				con.close();
			} 

			catch (SQLException e) 
			{
				throw new MediaException(e.getMessage());
			}

		}

		return generatedSongsId;



	}
	/*****************************************Generate Artist Id****************************************/
	
	@Override
	public int generateArtistId() throws MediaException
	{
		String qry="Select artist_Id.NextVal From Dual";

		int generateArtistId;
		try 
		{

			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(qry);
			rs.next();
			generateArtistId=rs.getInt(1);

		} 

		catch (Exception e) 
		{

			throw new MediaException("Some error occured while generating"+e.getMessage());

		}

		finally
		{
			try
			{
				rs.close();
				st.close();
				con.close();
			} 

			catch (SQLException e) 
			{
				throw new MediaException(e.getMessage());
			}

		}

		return generateArtistId;

		
		
	}

	/*********************************************Fetch all songs****************************************************/	
	@Override
	public ArrayList<Song_Master> getAllSongs() throws MediaException
	{
		String selQuery="Select * from Song_Master";
		Song_Master sm=null;

		ArrayList<Song_Master> songsList=new ArrayList<Song_Master>();

		try{

			con=DBUtil.getCon();

			st=con.createStatement();

			rs=st.executeQuery(selQuery);

			while(rs.next())
			{
				sm=new Song_Master(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getInt(4),rs.getDate(5),rs.getInt(6),rs.getDate(7));
				songsList.add(sm);
			}

		}
		catch(Exception e)
		{
			throw new MediaException(e.getMessage());
		}
		finally
		{
			try
			{
				rs.close();
				st.close();
				con.close();
			} 

			catch (SQLException e) 
			{
				throw new MediaException(e.getMessage());
			}

		}


		return songsList;
	}

	/*****************************************************Delete Song************************************************/

	@Override
	public int deleteSong(int id) throws MediaException 
	{
		String delQuery="Delete from Song_Master where song_id= ?";
		int songDeleted;
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(delQuery);
			pst.setInt(1,id);
			songDeleted=pst.executeUpdate();
		}
		catch(Exception e)
		{
			throw new MediaException(e.getMessage());
		}

		finally
		{
			try{

				con.close();
				pst.close();
			}

			catch(SQLException e)
			{
				throw new MediaException(e.getMessage());
			}

		}
		return songDeleted;	
	}


	/************************************************Generate Composer ID****************************************************/


	@Override
	public int generateComposerId() throws MediaException 
	{
		String qry="Select composer_id.NextVal From Dual";

		int generatedComposerId;
		try 
		{

			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(qry);
			rs.next();
			generatedComposerId=rs.getInt(1);

		} 

		catch (Exception e) 
		{

			throw new MediaException(e.getMessage());

		}

		finally
		{
			try
			{
				rs.close();
				st.close();
				con.close();
			} 

			catch (SQLException e) 
			{
				throw new MediaException(e.getMessage());
			}

		}

		return generatedComposerId;





	}

/*************************************************Generate artist id******************************************/
	
	

	/************************************************Get Song based on Id****************************************************/


	@Override
	public Song_Master getSong(int song_id) throws MediaException, Exception 
	{
		con=DBUtil.getCon();
		String selquery="Select * from Song_Master where song_id= ? ";
		pst=con.prepareStatement(selquery);
		pst.setInt(1, song_id);
		rs=pst.executeQuery();
		Song_Master sm2=new Song_Master();
		
		while(rs.next())
		{
			sm2.setSong_id(rs.getInt(1));
			sm2.setSong_name(rs.getString(2));
			sm2.setSong_duration(rs.getString(3));
			sm2.setCreated_by(rs.getInt(4));
			sm2.setUpdated_by(rs.getInt(5));
		}
		
		return sm2;
	}

	

/****************************************search/get  composer*******************************************/


	@Override
	public Composer_Master getComposer(int composer_Id) throws MediaException 
	{
		String searchQuery="Select * from composer_master where composer_Id=?";
		Composer_Master composer=null;
		try
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(searchQuery);
			while(rs.next())
			{
				composer= new Composer_Master(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getDate(4),rs.getString(5),rs.getInt(6),rs.getDate(7),rs.getInt(8),rs.getDate(9));
						
			}
		}
		catch(Exception e)
		{
			throw new MediaException("Some error occured"+e.getMessage());
		}
				return composer;
	}
/************************************************search artist **************************************************************/

@Override
public Artist_Master getArtist(int artist_Id) throws MediaException 
{

	String searchQuery="Select * from artist_master where artist_Id=?";
	Artist_Master artist=null;
	try
	{
		con=DBUtil.getCon();
		st=con.createStatement();
		rs=st.executeQuery(searchQuery);
		while(rs.next())
		{
			artist= new Artist_Master(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getDate(5),rs.getInt(6),rs.getDate(7),rs.getInt(8),rs.getDate(9));
					
		}
	}
	catch(Exception e)
	{
		throw new MediaException("Some error occured"+e.getMessage());
	}
			return artist;

}



/**********************************Login check******************************************/

@Override
public int getUserId() throws MediaException 
{

	String selectQry="SELECT User_Id FROM User_Master";
	int id=0;
	try 
	{
		con=DBUtil.getCon();
		st=con.createStatement();
		rs=st.executeQuery(selectQry);
		rs.next();
		id=rs.getInt(1);
	}
	catch (Exception e) 
	{
		throw new MediaException(e.getMessage());
	}
	
	finally
	{
		try 
		{
			st.close();
			con.close();
			rs.close();
		}
		catch (SQLException e) 
		{
			throw new MediaException(e.getMessage());
		}
		
	}
	return id;
}

@Override
public String getUserPwd() throws MediaException
{
	String selectQry="SELECT User_Password FROM User_Master";
	
	String pwd;
	try 
	{
		con=DBUtil.getCon();
		st=con.createStatement();
		rs=st.executeQuery(selectQry);
		rs.next();
		pwd=rs.getString(1);
	}
	catch (Exception e) 
	{
		throw new MediaException(e.getMessage());
	}
	
	finally
	{
		try 
		{
			st.close();
			con.close();
			rs.close();
		}
		catch (SQLException e) 
		{
			throw new MediaException(e.getMessage());
		}
		
	}
	return pwd;
}

@Override
public int getAdminId() throws MediaException 
{
	String selectQry="SELECT Admin_Id FROM Admin_Master";
	int id=0;
	try 
	{
		con=DBUtil.getCon();
		st=con.createStatement();
		rs=st.executeQuery(selectQry);
		rs.next();
		id=rs.getInt(1);
	}
	catch (Exception e) 
	{
		throw new MediaException(e.getMessage());
	}
	
	finally
	{
		try 
		{
			st.close();
			con.close();
			rs.close();
		}
		catch (SQLException e) 
		{
			throw new MediaException(e.getMessage());
		}
		
	}
	return id;
}

@Override
public String getAdminPwd() throws MediaException 
{
	String selectQry="SELECT Admin_Password FROM Admin_Master";
	
	String pwd;
	try 
	{
		con=DBUtil.getCon();
		st=con.createStatement();
		rs=st.executeQuery(selectQry);
		rs.next();
		pwd=rs.getString(1);
	}
	catch (Exception e) 
	{
		throw new MediaException(e.getMessage());
	}
	
	finally
	{
		try 
		{
			st.close();
			con.close();
			rs.close();
		}
		catch (SQLException e) 
		{
			throw new MediaException(e.getMessage());
		}
		
	}
	return pwd;
}



}
	
	
	