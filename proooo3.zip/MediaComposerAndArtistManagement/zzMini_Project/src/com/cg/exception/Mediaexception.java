package com.cg.exception;



public class Mediaexception extends Exception
{
	public Mediaexception (String msg)
	{
		super(msg);
	}
}
