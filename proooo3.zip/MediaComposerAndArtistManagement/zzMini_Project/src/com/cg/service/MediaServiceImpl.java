package com.cg.service;

import java.util.ArrayList;
import java.util.regex.Pattern;

import javax.swing.text.html.HTMLDocument.Iterator;

import com.cg.dao.IMediaDao;
import com.cg.dao.MediaDaoImpl;
import com.cg.exception.Mediaexception;

public class MediaServiceImpl implements IMediaService
{
	IMediaDao mdao;
	
	public MediaServiceImpl() 
	{
		mdao=new MediaDaoImpl();
	}

	

	@Override
	public int getUserId() throws Mediaexception
	{
		// TODO Auto-generated method stub
		return mdao.getUserId();
	}

	@Override
	public String getUserPwd() throws Mediaexception {
		// TODO Auto-generated method stub
		return mdao.getUserPwd();
	}

	@Override
	public int getAdminId() throws Mediaexception {
		// TODO Auto-generated method stub
		return mdao.getAdminId();
	}

	@Override
	public String getAdminPwd() throws Mediaexception {
		// TODO Auto-generated method stub
		return mdao.getAdminPwd();
	}



	@Override
	public boolean validateUserId(int user_id) throws Mediaexception 
	{
		int namePattern=mdao.getUserId();
		if(namePattern==user_id)
		{
			return true;
		}
		else
		{
			throw new Mediaexception("Invalid user id");
		}
	}



	@Override
	public boolean validateAdminId(int adminId) throws Mediaexception 
	{
		int namePattern=mdao.getAdminId();
		if(namePattern==adminId)
		{
			return true;
		}
		else
		{
			throw new Mediaexception("Invalid Admin id");
		}
	}



	@Override
	public boolean validateUserPwd(String userPwd) throws Mediaexception
	{
		String namePattern=mdao.getUserPwd();
		if(Pattern.matches(namePattern,userPwd))
		{
			return true;
		}
		else
		{
			throw new Mediaexception("Invalid user password");
		}

	}



	@Override
	public boolean validateAdminPwd(String adminPwd) throws Mediaexception
	{
		String namePattern=mdao.getAdminPwd();
		if(Pattern.matches(namePattern,adminPwd))
		{
			return true;
		}
		else
		{
			throw new Mediaexception("Invalid Admin password");
		}
	}
	
	
	
	
	

	/*@Override
	public ArrayList<Integer> getAllUserids() throws Mediaexception {
		// TODO Auto-generated method stub
		return mdao.getAllUserids();
	}

	@Override
	public ArrayList<Integer> getAllAdminids() throws Mediaexception {
		// TODO Auto-generated method stub
		return mdao.getAllAdminids();
	}

	@Override
	public boolean validateUserId(int user_id) throws Mediaexception 
	{
		int count=0;
		Iterator it=mdao.getAllUserids().iterator();
		
		while(it.hasNext())
		{
			int id=(int)it.next();
			if(user_id == id)
			{
				count=1;
				break;
			}
		}
		if(count==1)
		{
			return true;
		}
		else
		{
			throw new Mediaexception("User id not matched as already present in User Tables");
		}
		
	}

	@Override
	public boolean validateAdminId(int adminId) throws Mediaexception {
		// TODO Auto-generated method stub
		return false;
	}*/

}
