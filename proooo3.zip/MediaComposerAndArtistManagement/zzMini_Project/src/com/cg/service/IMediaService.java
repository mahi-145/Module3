package com.cg.service;

import java.util.ArrayList;

import com.cg.exception.Mediaexception;

public interface IMediaService
{
	/*public ArrayList<Integer> getAllUserids() throws Mediaexception;
	
	public ArrayList<Integer> getAllAdminids() throws Mediaexception;*/
	
	
	public boolean  validateUserId(int user_id) throws Mediaexception;
	
	public boolean  validateAdminId(int  adminId) throws Mediaexception;
	
	public boolean  validateUserPwd(String userPwd) throws Mediaexception;
	
	public boolean  validateAdminPwd(String  adminPwd) throws Mediaexception;
	
	
	public int getUserId() throws Mediaexception;
	
	public String getUserPwd() throws Mediaexception;
	
	public int getAdminId() throws Mediaexception;
	
	public String getAdminPwd() throws Mediaexception;
	
}
