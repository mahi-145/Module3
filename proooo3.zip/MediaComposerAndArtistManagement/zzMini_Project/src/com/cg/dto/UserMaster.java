package com.cg.dto;

public class UserMaster 
{
	private int user_id;
	private String userpassword;
	
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public String getUserpassword() {
		return userpassword;
	}
	public void setUserpassword(String userpassword) {
		this.userpassword = userpassword;
	}
	public UserMaster() {
		super();
		// TODO Auto-generated constructor stub
	}
	public UserMaster(int user_id, String userpassword) {
		super();
		this.user_id = user_id;
		this.userpassword = userpassword;
	}

	
	
	
}
