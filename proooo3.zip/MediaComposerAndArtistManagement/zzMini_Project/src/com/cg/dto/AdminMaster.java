package com.cg.dto;

public class AdminMaster 
{
	private int adminId;
	private String adminpassword;
	public int getAdminId() {
		return adminId;
	}
	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}
	public String getAdminpassword() {
		return adminpassword;
	}
	public void setAdminpassword(String adminpassword) {
		this.adminpassword = adminpassword;
	}
	public AdminMaster() {
		super();
		// TODO Auto-generated constructor stub
	}
	public AdminMaster(int adminId, String adminpassword) {
		super();
		this.adminId = adminId;
		this.adminpassword = adminpassword;
	}
	
	
	
}
