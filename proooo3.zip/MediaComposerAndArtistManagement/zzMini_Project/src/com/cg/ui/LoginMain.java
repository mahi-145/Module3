package com.cg.ui;

import java.util.Scanner;

import com.cg.exception.Mediaexception;
import com.cg.service.IMediaService;
import com.cg.service.MediaServiceImpl;

public class LoginMain 
{

	static Scanner sc=null;
	static IMediaService mser=null;
	
	public static void main(String[] args) 
	{
		
		sc=new Scanner(System.in);
		mser=new MediaServiceImpl();
		
		int choice;
		
		
		
		while(true)
		{
			System.out.println("Select the type of user you are :");
			System.out.println("\n1.Admin");
			System.out.println("\n2.User");
			
			choice=sc.nextInt();
			switch (choice) 
			{
				case 1:Admin();
						break;

				case 2:User();
						break;
			default:End();
				break;
			}
				
		}
		
	}

	
	private static void User() 
	{
		System.out.println("Enter User Id : ");
		int userId=sc.nextInt();
		System.out.println("Enter User Password");
		String userPWD=sc.next();
		
		try 
		{
			if(mser.validateUserId(userId))
			{
				if(mser.validateUserPwd(userPWD))
				{
					System.out.println("*****************Successfully logged in as user*******************");
					System.out.println("please select the operation to perform");
				}
				else
				{
					System.out.println("Invalid password");
				}
			}
			else
			{
				System.out.println("Invalid user id");
			}
		}
		catch (Mediaexception e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	private static void Admin() 
	{
		System.out.println("Enter Admin Id : ");
		int adminId=sc.nextInt();
		System.out.println("Enter Admin Password");
		String adminPWD=sc.next();
		
		try 
		{
			if(mser.validateAdminId(adminId))
			{
				if(mser.validateAdminPwd(adminPWD))
				{
					System.out.println("*****************Successfully logged in as Admin*******************");
					System.out.println("please select the operation to perform");
				}
				else
				{
					System.out.println("Invalid password");
				}
			}
			else
			{
				System.out.println("Invalid admin id");
			}
		}
		catch (Mediaexception e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	private static void End() 
	{
		System.out.println("check your Login credentials");
		System.out.println("Thank You for using our application ");
	}

	
}
