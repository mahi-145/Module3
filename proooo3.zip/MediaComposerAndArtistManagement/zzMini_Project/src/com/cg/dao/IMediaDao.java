package com.cg.dao;

import java.util.ArrayList;

import com.cg.exception.Mediaexception;

public interface IMediaDao 
{
	//public ArrayList<Integer> getAllUserids() throws Mediaexception;
	
	//public ArrayList<Integer> getAllAdminids() throws Mediaexception;
	
	public int getUserId() throws Mediaexception;
	
	public String getUserPwd() throws Mediaexception;
	
	public int getAdminId() throws Mediaexception;
	
	public String getAdminPwd() throws Mediaexception;
}
