package com.cg.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.exception.Mediaexception;
import com.cg.util.DBUtil;

public class MediaDaoImpl implements IMediaDao 
{

	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	
	@Override
	public int getUserId() throws Mediaexception 
	{
		String selectQry="SELECT User_Id FROM User_Master";
		int id=0;
		try 
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			rs.next();
			id=rs.getInt(1);
		}
		catch (Exception e) 
		{
			throw new Mediaexception(e.getMessage());
		}
		
		finally
		{
			try 
			{
				st.close();
				con.close();
				rs.close();
			}
			catch (SQLException e) 
			{
				throw new Mediaexception(e.getMessage());
			}
			
		}
		return id;
	}
	@Override
	public String getUserPwd() throws Mediaexception 
	{
		String selectQry="SELECT User_Password FROM User_Master";
		
		String pwd;
		try 
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			rs.next();
			pwd=rs.getString(1);
		}
		catch (Exception e) 
		{
			throw new Mediaexception(e.getMessage());
		}
		
		finally
		{
			try 
			{
				st.close();
				con.close();
				rs.close();
			}
			catch (SQLException e) 
			{
				throw new Mediaexception(e.getMessage());
			}
			
		}
		return pwd;
		
	}
	@Override
	public int getAdminId() throws Mediaexception 
	{
		String selectQry="SELECT Admin_Id FROM Admin_Master";
		int id=0;
		try 
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			rs.next();
			id=rs.getInt(1);
		}
		catch (Exception e) 
		{
			throw new Mediaexception(e.getMessage());
		}
		
		finally
		{
			try 
			{
				st.close();
				con.close();
				rs.close();
			}
			catch (SQLException e) 
			{
				throw new Mediaexception(e.getMessage());
			}
			
		}
		return id;
	}
	@Override
	public String getAdminPwd() throws Mediaexception 
	{
		String selectQry="SELECT Admin_Password FROM Admin_Master";
		
		String pwd;
		try 
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			rs.next();
			pwd=rs.getString(1);
		}
		catch (Exception e) 
		{
			throw new Mediaexception(e.getMessage());
		}
		
		finally
		{
			try 
			{
				st.close();
				con.close();
				rs.close();
			}
			catch (SQLException e) 
			{
				throw new Mediaexception(e.getMessage());
			}
			
		}
		return pwd;
		
	}
	
	/*@Override
	public ArrayList<Integer> getAllUserids() throws Mediaexception 
	{
		
		ArrayList<Integer> userIdList=new ArrayList<Integer>();
		
		String selectQry="SELECT User_Id FROM User_Master";

		try 
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			while(rs.next())
			{
				userIdList.add(rs.getInt("User_Id"));
			}
		}
		catch (Exception e) 
		{
			throw new Mediaexception(e.getMessage());
		}
		
		finally
		{
			try 
			{
				st.close();
				con.close();
				rs.close();
			}
			catch (SQLException e) 
			{
				throw new Mediaexception(e.getMessage());
			}
			
		}
		return userIdList;
	}

	@Override
	public ArrayList<Integer> getAllAdminids() throws Mediaexception 
	{
		ArrayList<Integer> adminIdList=new ArrayList<Integer>();
		
		String selectQry="SELECT Admin_Id  FROM Admin_Master";

		try 
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			while(rs.next())
			{
				adminIdList.add(rs.getInt("Admin_Id"));
			}
		}
		catch (Exception e) 
		{
			throw new Mediaexception(e.getMessage());
		}
		
		finally
		{
			try 
			{
				st.close();
				con.close();
				rs.close();
			}
			catch (SQLException e) 
			{
				throw new Mediaexception(e.getMessage());
			}
			
		}
		return adminIdList;
	}*/
	
	
	
	

}
