package com.cg.service;

import java.sql.SQLException;

import com.cg.dto.UserDTO;

public interface RegisterService
{
	public int insertDetails(UserDTO user) throws SQLException;
}
