package com.cg.service;

import java.sql.SQLException;

import com.cg.dao.RegisterDao;
import com.cg.dao.RegisterDaoImpl;
import com.cg.dto.UserDTO;

public class RegisterServiceImpl implements RegisterService
{
	RegisterDao regDao;
	public RegisterServiceImpl() {
		regDao=new RegisterDaoImpl();
		
	}

	@Override
	public int insertDetails(UserDTO user) throws SQLException
	{
		// TODO Auto-generated method stub
		return regDao.insertDetails(user);
	}

}
