package com.cg.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;




import com.cg.dto.UserDTO;
import com.cg.service.RegisterService;
import com.cg.service.RegisterServiceImpl;

@WebServlet("/RegistrationController")
public class RegistrationController extends HttpServlet {
	private static final long serialVersionUID = 1L;
      RegisterService regSer=null;
  
    public RegistrationController() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	
	public void destroy() {
		// TODO Auto-generated method stub
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw=response.getWriter();
		regSer=new RegisterServiceImpl();
		String fnm=request.getParameter("txtfName");
		String lnm=request.getParameter("txtlName");
		String pwd=request.getParameter("txtPwd");
		String gender=request.getParameter("gender");
		String[] skill=request.getParameterValues("skill");
		String city=request.getParameter("city");
		int n=skill.length;
		String str=skill[0];
		if(n==1)
		{
			str=skill[0];
		}
		else
		{
			while(n>1)
			{
				str=str+skill[n-1];
				n=n-1;
			}
		}
		UserDTO user=new UserDTO(fnm,lnm,pwd,gender.charAt(0),str,city);
		int dataInsert;
		
		try
		{
			dataInsert=regSer.insertDetails(user);
			
			if(dataInsert==1)
			{
				response.sendRedirect("html/Success.html");
			}
			else
			{
				response.sendRedirect("html/Failure.html");
			}
		}
		catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		
	}

}
