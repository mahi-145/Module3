package com.cg.dao;

import java.sql.SQLException;

import com.cg.dto.UserDTO;

public interface RegisterDao
{
	public int insertDetails(UserDTO user) throws SQLException;
}
