package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;



import com.cg.dto.UserDTO;
import com.cg.util.DBUtil;

public class RegisterDaoImpl implements RegisterDao
{
	Connection con=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	int dataInserted=0;

	
	@Override
	public int insertDetails(UserDTO user) throws SQLException
	{
		con=DBUtil.getCon();
		System.out.println("Got Connection"+con);
		String insertQry="INSERT INTO RegisteredUsers VALUES(?,?,?,?,?,?)";
		pst=con.prepareStatement(insertQry);
		pst.setString(1, user.getFirstName());
		pst.setString(2, user.getLastName());
		pst.setString(3, user.getPassword());
		pst.setString(4, String.valueOf(user.getGender()));
		pst.setString(5, user.getSkillset());
		pst.setString(6, user.getCity());
		dataInserted=pst.executeUpdate();
		
		
		
		return dataInserted;
	}

}
