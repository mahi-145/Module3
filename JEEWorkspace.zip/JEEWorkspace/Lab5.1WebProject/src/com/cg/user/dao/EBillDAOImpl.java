package com.cg.user.dao;

public class EBillDAOImpl
{

}
