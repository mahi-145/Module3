package com.cg.user.dao;

public interface EBillDAO
{
	
}
