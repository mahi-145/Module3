package com.cg.web;

abstract class Animal
{
	public abstract void sound();
}
class Lion extends Animal 
{
	public void sound()
	{
		System.out.println("roar");
	}


	public static void main(String args[])
	{
		Animal obj=new Lion();
		obj.sound();
	}
}