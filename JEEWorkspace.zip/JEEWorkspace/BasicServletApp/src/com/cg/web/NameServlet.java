package com.cg.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(name = "NameServletName", urlPatterns = { "/NameServletMap" })
public class NameServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public NameServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	public void init(ServletConfig config) throws ServletException {
		System.out.println("NameServlet init Called");
	}

	
	public void destroy() {
		System.out.println("NameServlet destroy Called");
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String nm=request.getParameter("txtName");
		PrintWriter pw=response.getWriter();
		pw.print("<font color=blue><b>Welcome </b></font>"+nm);
	}

}
