package com.cg.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/URLRewriteServlet")
public class URLRewriteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ServletConfig cg=null;
	int count=0;
  
    public URLRewriteServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		cg=config;
	}

	
	public void destroy() {
		// TODO Auto-generated method stub
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String iid=request.getParameter("id");
		if(iid==null)
		{
			iid="1";
			count=Integer.parseInt(iid);
			count++;
			
		}
		else
		{
			count=Integer.parseInt(iid);
			count++;
		}
		PrintWriter pw=response.getWriter();
		pw.println("<b> I Visited: " +count+ "times.</b>");
		pw.println("<br/>Do You Want to visit again?");
		pw.println("<a href='/SessionProject/URLRewriteServlet?id="+count+"'>Click Here To Visit Again</a>");
		
	}

}
