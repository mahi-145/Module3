package com.cg.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class CartServlet
 */
@WebServlet("/CartServlet")
public class CartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CartServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw=response.getWriter();
		String book=request.getParameter("txtBook");
		HttpSession session=request.getSession(true);
		ArrayList<String> bookList=(ArrayList<String>)session.getAttribute("BookListObj");
		if(bookList==null)
		{
			bookList=new ArrayList<String>();
			bookList.add(book);
			session.setAttribute("BookListObj", bookList);
		}
		else
		{
			bookList.add(book);
			session.setAttribute("BookListObj", bookList);
		}
		pw.println("<br/>Is it a new session?: "+session.isNew());
		pw.println("<br/>Session id: "+session.getId());
		pw.println("<br/>MaxInterval: "+session.getMaxInactiveInterval());
		pw.println("<hr/>");
		pw.println("Items in Cart"+bookList);
		pw.println("<br/>Do U want to Purchase again?");
		pw.println("<a href='/SessionProject/BookCatalogServlet'>Go to Book Catalog</a>");
	}

}
