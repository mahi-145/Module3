package com.cg.customer.service;

import java.util.ArrayList;

import com.cg.customer.dao.CustomerDao;
import com.cg.customer.dao.CustomerDaoImpl;
import com.cg.customer.dto.BookingInformation;
import com.cg.customer.dto.FlightInformation;
import com.cg.customer.exception.CustomerException;

public class CustomerServiceImpl implements CustomerService 
{

	CustomerDao custDao=null;
	
	public CustomerServiceImpl()
	{
		custDao=new CustomerDaoImpl();
	}
	
	@Override
	public int bookTicket(BookingInformation bookInfo) throws CustomerException 
	{
		return custDao.bookTicket(bookInfo);
	}

	@Override
	public int generateBookingId() throws CustomerException 
	{
		return custDao.generateBookingId();
	}

	@Override
	public ArrayList<FlightInformation> getDetails()
			throws CustomerException
			{
		return custDao.getDetails();
	}

	@Override
	public int deleteBooking(int bId) throws CustomerException 
	{
		return custDao.deleteBooking(bId);
	}

	@Override
	public int updateBooking(BookingInformation bookInfo) throws CustomerException {
		// TODO Auto-generated method stub
		return custDao.updateBooking(bookInfo);
	}

}
