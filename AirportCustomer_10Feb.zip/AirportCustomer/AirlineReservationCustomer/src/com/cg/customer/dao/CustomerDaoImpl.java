package com.cg.customer.dao;

import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.cg.customer.dto.BookingInformation;
import com.cg.customer.dto.FlightInformation;
import com.cg.customer.exception.CustomerException;
import com.cg.customer.util.DbUtil;

public class CustomerDaoImpl implements CustomerDao
{

	Connection conn=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;


	@Override
	public int bookTicket(BookingInformation bookInfo) throws CustomerException 
	{
		String insertqry="Insert into bookinginformation(booking_id, cust_email, no_of_passengers, class_type, total_fare, creditcard_info, src_city, dest_city,flightno) values(?,?,?,?,?,?,?,?,?)";
		//	int dataAdded=0;
		int id=0;

		try
		{
			conn=DbUtil.getConn();
			pst=conn.prepareStatement(insertqry);
			id = generateBookingId();
			pst.setInt(1, id);
			pst.setString(2, bookInfo.getCustEmail());
			System.out.println(bookInfo.getCustEmail());
			pst.setInt(3, bookInfo.getNoOfPassengers());
			pst.setString(4, bookInfo.getClassType());
			pst.setFloat(5,  bookInfo.getFare());
			pst.setString(6, bookInfo.getCreditCard());
			pst.setString(7, bookInfo.getSource());
			pst.setString(8, bookInfo.getDestination());
			pst.setInt(9, bookInfo.getFlightNo());
			System.out.println(bookInfo.getCustEmail());
			pst.executeUpdate();

		}
		catch (Exception e) 
		{
			throw new CustomerException(e.getMessage());
		}
		finally
		{
			try
			{
				pst.close();
				conn.close();

			}
			catch(Exception e)
			{
				throw new CustomerException(e.getMessage());
			}
		}
		return id;
	}

	@Override
	public int generateBookingId() throws CustomerException
	{
		String query="select bookingid.NEXTVAL from dual";
		int generatedId=0;

		try
		{
			conn=DbUtil.getConn();
			st=conn.createStatement();
			rs=st.executeQuery(query);

			rs.next();
			generatedId=rs.getInt(1);
		}
		catch(Exception e)
		{
			throw new CustomerException(e.getMessage());
		}
		finally
		{
			try
			{
				rs.close();
				st.close();
				conn.close();
			}
			catch(Exception e)
			{
				throw new CustomerException(e.getMessage());
			}
		}

		return generatedId;
	}

	@Override
	public ArrayList<FlightInformation> getDetails()
			throws CustomerException 

			{
		ArrayList<FlightInformation> flightList=new ArrayList<FlightInformation>();
		String selQry="select * from flightinformation";

		FlightInformation fInfo=null;
		try
		{
			conn=DbUtil.getConn();
			pst=conn.prepareStatement(selQry);
			rs=pst.executeQuery();


			while(rs.next())
			{
				fInfo=new FlightInformation(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getInt(9),rs.getDouble(10),rs.getInt(11),rs.getDouble(12));
				flightList.add(fInfo);
			}


		}
		catch(Exception e)
		{
			throw new CustomerException(e.getMessage());
		}
		finally
		{
			try
			{
				conn.close();
				rs.close();
				pst.close();
			}
			catch(Exception e)
			{
				throw new CustomerException(e.getMessage());
			}
		}
		return flightList;
			}

	@Override
	public int deleteBooking(int bId) throws CustomerException 
	{

		String delQry="delete from bookinginformation where booking_id = ?";
		int dataDeleted;
		try
		{
			conn=DbUtil.getConn();
			pst=conn.prepareStatement(delQry);
			pst.setInt(1, bId);
			dataDeleted=pst.executeUpdate();
		}
		catch (Exception e) 
		{
			throw new CustomerException(e.getMessage());
		}
		finally
		{
			try 
			{
				conn.close();
				pst.close();
			}
			catch (SQLException e) 
			{
				throw new CustomerException(e.getMessage());
			}
		}
		return dataDeleted;
	}

	@Override
	public int updateBooking(BookingInformation bookInfo) throws CustomerException 
	{
		String updateQry="Update bookinginformation set cust_email=?, no_of_passengers=?, class_type=?, total_fare=?, creditcard_info=?, src_city=?, dest_city=?, flightno=? where booking_id = ?";
		int dataUpdated=0;
	

		try
		{
			conn=DbUtil.getConn();
			pst=conn.prepareStatement(updateQry);
			pst.setInt(9, bookInfo.getBookingId());
			pst.setString(1, bookInfo.getCustEmail());
			pst.setInt(2, bookInfo.getNoOfPassengers());
			pst.setString(3, bookInfo.getClassType());
			pst.setFloat(4,  bookInfo.getFare());
			pst.setString(5, bookInfo.getCreditCard());
			pst.setString(6, bookInfo.getSource());
			pst.setString(7, bookInfo.getDestination());
		    pst.setInt(8, bookInfo.getFlightNo());
		

			dataUpdated=pst.executeUpdate();
		}
		catch(Exception e)
		{
			throw new CustomerException(e.getMessage());
		}
		
		finally
		{
			try 
			{
				conn.close();
				pst.close();
			}
			catch (SQLException e) 
			{
				throw new CustomerException(e.getMessage());
			}
		}
		return dataUpdated;
		
	}
}






