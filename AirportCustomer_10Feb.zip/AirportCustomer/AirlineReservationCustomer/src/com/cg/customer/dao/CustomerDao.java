package com.cg.customer.dao;

import java.util.ArrayList;

import com.cg.customer.dto.BookingInformation;
import com.cg.customer.dto.FlightInformation;
import com.cg.customer.exception.CustomerException;

public interface CustomerDao
{
	public int bookTicket(BookingInformation bookInfo) throws CustomerException;
	public int generateBookingId() throws CustomerException;
	public ArrayList<FlightInformation> getDetails() throws CustomerException;
	public int deleteBooking(int bId) throws CustomerException;
	public int updateBooking(BookingInformation bookInfo) throws CustomerException;

	
}
