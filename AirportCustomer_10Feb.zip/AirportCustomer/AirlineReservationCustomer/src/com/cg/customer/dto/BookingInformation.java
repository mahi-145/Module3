package com.cg.customer.dto;

public class BookingInformation 
{
	private int bookingId;
	private int flightNo;
	private String custEmail;
	private int noOfPassengers;
	private String classType;
	private String creditCard;
	private float fare;
	private String source;
	private String destination;
	
	

	
	public int getBookingId()
	{
		return bookingId;
	}
	
	public void setBookingId(int bookingId) 
	{
		this.bookingId = bookingId;
	}

	public int getFlightNo() 
	{
		return flightNo;
	}

	public void setFlightNo(int flightNo) 
	{
		this.flightNo = flightNo;
	}

	public String getCustEmail() 
	{
		return custEmail;
	}

	public void setCustEmail(String custEmail) 
	{
		this.custEmail = custEmail;
	}
	
	public int getNoOfPassengers() 
	{
		return noOfPassengers;
	}
	
	public void setNoOfPassengers(int noOfPassengers) 
	{
		this.noOfPassengers = noOfPassengers;
	}
	public String getClassType() 
	{
		return classType;
	}

	public void setClassType(String classType) 
	{
		this.classType = classType;
	}
	
	

	
	public float getFare() {
		return fare;
	}

	public void setFare(float fare) {
		this.fare = fare;
	}

	public String getCreditCard() 
	{
		return creditCard;
	}
	
	public void setCreditCard(String creditCard) 
	{
		this.creditCard = creditCard;
	}
	
	public String getSource() 
	{
		return source;
	}
	
	public void setSource(String source) 
	{
		this.source = source;
	}
	
	public String getDestination() 
	{
		return destination;
	}
	
	public void setDestination(String destination) 
	{
		this.destination = destination;
	}

	
	@Override
	public String toString() {
		return "BookingInformation [bookingId=" + bookingId + ", flightNo="
				+ flightNo + ", custEmail=" + custEmail + ", noOfPassengers="
				+ noOfPassengers + ", classType=" + classType + ", creditCard="
				+ creditCard + ", fare=" + fare + ", source=" + source
				+ ", destination=" + destination + "]";
	}

	public BookingInformation(int bookingId, int flightNo, String custEmail,
			int noOfPassengers, String classType, String creditCard,
			float fare, String source, String destination) {
		super();
		this.bookingId = bookingId;
		this.flightNo = flightNo;
		this.custEmail = custEmail;
		this.noOfPassengers = noOfPassengers;
		this.classType = classType;
		this.creditCard = creditCard;
		this.fare = fare;
		this.source = source;
		this.destination = destination;
	}

	public BookingInformation() 
	{
		super();
		// TODO Auto-generated constructor stub
	}

	
	
	
	
	
}
