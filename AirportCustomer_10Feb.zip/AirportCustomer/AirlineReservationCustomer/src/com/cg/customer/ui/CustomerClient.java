package com.cg.customer.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.customer.dto.BookingInformation;
import com.cg.customer.dto.FlightInformation;
import com.cg.customer.exception.CustomerException;
import com.cg.customer.service.CustomerService;
import com.cg.customer.service.CustomerServiceImpl;

public class CustomerClient 
{
	static CustomerService custSer=null;
	static Scanner sc=null;

	public static void main(String[] args) 
	{
		custSer=new CustomerServiceImpl();
		sc=new Scanner(System.in);

		while(true)
		{
			System.out.println("*********Flight Reservation*********");
			System.out.println("Choose an operation");
			System.out.println("1. View All Flights");
			System.out.println("2. Book Flights");
			System.out.println("3. Update Booking ");
			System.out.println("4. Delete Booking ");
			System.out.println("0. Exit");
			System.out.println("***********");
			System.out.println("Please Enter a choice");


			int choice = sc.nextInt();
			switch(choice)
			{
			case 1: viewDetails();
				break;
			
			case 2: bookFlight();
			break;
			
			case 3: updateBooking();
				break;
			
			case 4: deleteBooking();
				break;
				
			default:System.out.println("Thank You for selecting us!!");
			System.exit(0);	
			break;
			}

		}

	}

	public static void updateBooking() 
	{
		System.out.println("Enter your booking Id");
		int bookId=sc.nextInt();
		int dataUpdated=0;
		String source=null;
		String destination=null;
		int noOfPassengers=0;
		int flightNo=0;
		String classType=null;
		String custEmail=null;
		String creditCard=null;
		float fare=0.0f;
		int choice=0;

		try
		{
			System.out.println("Please enter Source city");
			source=sc.next();
			System.out.println("Please enter Destination city");
			destination=sc.next();
			System.out.println("Please enter number of passengers");
			noOfPassengers=sc.nextInt();
			System.out.println("Enter the flight number");
			flightNo=sc.nextInt();
			System.out.println("Please specify class type:");
			System.out.println("1. Business");
			System.out.println("2. Economy");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1: fare=4000*noOfPassengers;
			break;

			case 2: fare=2000*noOfPassengers;
			break;
			}

			System.out.println("Please provide creditCard number");
			creditCard=sc.next();
			System.out.println("Please provide Email id");
			custEmail=sc.next();
			
			
			if(choice==1)
			{
				classType="Business";
			}
			else
			{
				classType="Economy";
			}

			BookingInformation bookInfo = new BookingInformation();
			bookInfo.setBookingId(bookId);
			bookInfo.setCustEmail(custEmail);
			bookInfo.setNoOfPassengers(noOfPassengers);
			bookInfo.setClassType(classType);
			bookInfo.setFare(fare);
			bookInfo.setCreditCard(creditCard);
			bookInfo.setSource(source);
			bookInfo.setDestination(destination);
			bookInfo.setFlightNo(flightNo);
			
			dataUpdated=custSer.updateBooking(bookInfo);

			if(dataUpdated==1)
			{
				System.out.println("Thank You, your booking has been updated successfully");
				
			}
			else
			{
				System.out.println("Sorry, This booking Id does not exist");
			}

		}
		catch(CustomerException e)
		{
			System.out.println(e.getMessage());
		}

		
	}

	public static void deleteBooking() 
	{
		System.out.println("Enter your Booking Id to delete");
		int bookId=sc.nextInt();
		int dataDeleted=0;
		try
		{
			dataDeleted=custSer.deleteBooking(bookId);
			if(dataDeleted==1)
			{
				System.out.println("Thank You, your booking has been cancelled succesfully");
				
			}
			else
			{
				System.out.println("Sorry, This booking Id does not exist");
			}
		}
		catch(CustomerException e)
		{
			System.out.println(e.getMessage());
		}
	}

	public static void viewDetails()
	{
		System.out.println("******  !!  Showing all the flight's Information !! *********");
//		int fNo=sc.nextInt();
		try
		{
			ArrayList<FlightInformation> fList=custSer.getDetails();

			if(fList.size()>0)
			{
				for(FlightInformation eList:fList)
				{
					System.out.println(eList);
				}
			}
			else
			{
				System.out.println("Sorry does not exist");
			}
		}
		catch (CustomerException e) 
		{
	
			System.out.println(("Sorry cannot show you information"));
		}

		
		
		
	}

	public static void bookFlight() 
	{
		String source=null;
		String destination=null;
		int noOfPassengers=0;
		int flightNo=0;
		String classType=null;
		String custEmail=null;
		String creditCard=null;
		float fare=0.0f;
		int choice=0;

		try
		{
			System.out.println("**************************");
			System.out.println("Welcome to Reservation Center");
			System.out.println("**************************");
			System.out.println("Please enter Source city");
			source=sc.next();
			System.out.println("Please enter Destination city");
			destination=sc.next();
			System.out.println("Please enter number of passengers");
			noOfPassengers=sc.nextInt();
			System.out.println("Enter the flight number");
			flightNo=sc.nextInt();
			System.out.println("Please specify class type:");
			System.out.println("1. Business");
			System.out.println("2. Economy");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1: fare=4000*noOfPassengers;
			break;

			case 2: fare=2000*noOfPassengers;
			break;
			}

			System.out.println("Please provide creditCard number");
			creditCard=sc.next();
			System.out.println("Please provide Email id");
			custEmail=sc.next();
			
			
			if(choice==1)
			{
				classType="Business";
			}
			else
			{
				classType="Economy";
			}

			BookingInformation bookInfo = new BookingInformation();
			bookInfo.setCustEmail(custEmail);
			bookInfo.setNoOfPassengers(noOfPassengers);
			bookInfo.setClassType(classType);
			bookInfo.setFare(fare);
			bookInfo.setCreditCard(creditCard);
			bookInfo.setSource(source);
			bookInfo.setDestination(destination);
			bookInfo.setFlightNo(flightNo);
			int id= custSer.bookTicket(bookInfo);
			if(id>0)
			{
				System.out.println("Thank You for Booking");
				System.out.println("Your Booking Id " + id );
				System.out.println("Please remember it for future references");

			}
			else
			{
				System.out.println("Sorry, flight cannot be booked");
			}

		}
		catch(CustomerException e)
		{
			e.printStackTrace();
			System.out.println(e.getMessage());
		}

	}


}
