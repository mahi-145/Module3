package com.cg.web.pms.dao;

import java.util.List;

import com.cg.web.pms.entities.Product;
import com.cg.web.pms.exception.ProductException;

public interface IProductDAO 
{
	public Product removeProduct(int id) throws ProductException;

	public List<Product> getAllProducts() throws ProductException;	
}
