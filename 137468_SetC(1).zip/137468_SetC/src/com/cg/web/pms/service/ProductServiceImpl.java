package com.cg.web.pms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.web.pms.dao.IProductDAO;
import com.cg.web.pms.entities.Product;
import com.cg.web.pms.exception.ProductException;

@Service
@Transactional //all methods are in transaction managed by container
public class ProductServiceImpl implements IProductService 
{
	@Autowired
	private IProductDAO productDAO;
	
	public IProductDAO getProductDAO() 
	{
		return productDAO;
	}
	public void setProductDAO(IProductDAO productDAO) 
	{
		this.productDAO = productDAO;
	}

	@Override
	public Product removeProduct(int id) throws ProductException 
	{
		return productDAO.removeProduct(id);
		
	}

	@Override
	public List<Product> getAllProducts() throws ProductException 
	{
		return productDAO.getAllProducts();
	}
}