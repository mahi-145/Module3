DROP TABLE Product CASCADE CONSTRAINTS;

CREATE TABLE Product
(
	product_id number(5) primary key,
	product_name varchar2(30),
	product_price Number(10),
	product_quantity number(5),
	description varchar2(40)
);

INSERT INTO Product VALUES (1001,'iPhone',45000,10,'Electronics Equipment From Apple');

INSERT INTO Product VALUES (1002,'Cartoon Shirt',345,15,'Kids wear 4 to 12 Years');

INSERT INTO Product VALUES (1003,'Sofa',20000,12,'HouseHold Furnitures');

SELECT * FROM Product;

COMMIT;

