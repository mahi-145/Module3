package com.cg.mpa.dto;

public class Mobile 
{
	private long mobId;
	private String mobName;
	private float mobPrice;
	private int mobQuantity;
	
	public long getMobId() 
	{
		return mobId;
	}
	
	public void setMobId(long mobId) 
	{
		this.mobId = mobId;
	}
	
	public String getMobName() 
	{
		return mobName;
	}
	
	public void setMobName(String mobName) 
	{
		this.mobName = mobName;
	}
	
	public float getMobPrice() 
	{
		return mobPrice;
	}
	
	public void setMobPrice(float mobPrice) 
	{
		this.mobPrice = mobPrice;
	}
	
	public int getMobQuantity() 
	{
		return mobQuantity;
	}
	
	public void setMobQuantity(int mobQuantity) 
	{
		this.mobQuantity = mobQuantity;
	}
	
	@Override
	public String toString() {
		return "Mobiles [mobId=" + mobId + ", mobName=" + mobName
				+ ", mobPrice=" + mobPrice + ", mobQuantity=" + mobQuantity
				+ "]";
	}
	
	public Mobile() 
	{
		super();
	}
	
	public Mobile(long mobId, String mobName, float mobPrice, int mobQuantity) 
	{
		super();
		this.mobId = mobId;
		this.mobName = mobName;
		this.mobPrice = mobPrice;
		this.mobQuantity = mobQuantity;
	}
}

	
	
	
	