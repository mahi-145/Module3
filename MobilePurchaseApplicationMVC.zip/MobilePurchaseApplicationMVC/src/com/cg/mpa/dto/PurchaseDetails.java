package com.cg.mpa.dto;

import java.time.LocalDate;

public class PurchaseDetails 
{
	private long purchaseId;
	private String cname;
	private String cMailId;
	private long phoneNo;
	private LocalDate cPurDate;
	private long mobileId;

	public long getPurchaseId() {
		return purchaseId;
	}
	public void setPurchaseId(long purchaseId) {
		this.purchaseId = purchaseId;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getcMailId() {
		return cMailId;
	}
	public void setcMailId(String cMailId) {
		this.cMailId = cMailId;
	}
	public long getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}
	public LocalDate getcPurDate() {
		return cPurDate;
	}
	public void setcPurDate(LocalDate cPurDate) {
		this.cPurDate = cPurDate.now();
	}
	public long getMobileId() {
		return mobileId;
	}
	public void setMobileId(long mobileId) {
		this.mobileId = mobileId;
	}
	public PurchaseDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	public PurchaseDetails(long purchaseId, String cname, String cMailId,
			long phoneNo, LocalDate cPurDate, long mobileId) {
		super();
		this.purchaseId = purchaseId;
		this.cname = cname;
		this.cMailId = cMailId;
		this.phoneNo = phoneNo;
		this.cPurDate = cPurDate;
		this.mobileId = mobileId;
	}
	@Override
	public String toString() {
		return "purchaseDetails [purchaseId=" + purchaseId + ", cname=" + cname
				+ ", cMailId=" + cMailId + ", phoneNo=" + phoneNo
				+ ", cPurDate=" + cPurDate + ", mobileId=" + mobileId + "]";
	}




}




