package com.cg.mpa.util;

import java.sql.Connection;

import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.cg.mpa.exception.MobileException;


public class DbUtil 
{
	public static Connection getConn() throws MobileException
	{
		Connection conn = null;
		InitialContext context;
	//	conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
		try 
		{
			context=new InitialContext();
			DataSource ds=(DataSource)context.lookup("java:/JDBC/OracleDS");
			conn=ds.getConnection();
		}
		catch (Exception e) 
		{
			throw new MobileException(e.getMessage());
		}
		return conn;
	}
}
