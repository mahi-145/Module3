package com.cg.mpa.dao;

public interface QueryMapper
{
	
	String SELECT_ALL_MOBILES="select * from mobiles";
	String SELECT_MOBILE="select mobileid, name, quantity, price from mobiles where mobileid=?";
	String SELECT_SEQUENCE="select s.NEXTVAL from dual";
	String INSERT_QUERY="insert into purchasedetails values(?,?,?,?,?,?)";
}
