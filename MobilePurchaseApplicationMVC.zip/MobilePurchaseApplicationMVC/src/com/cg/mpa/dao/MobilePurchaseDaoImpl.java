package com.cg.mpa.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.management.Query;

import com.cg.mpa.dto.Mobile;
import com.cg.mpa.dto.PurchaseDetails;
import com.cg.mpa.exception.MobileException;
import com.cg.mpa.util.DbUtil;

public class MobilePurchaseDaoImpl implements MobilePurchaseDao 
{
	Connection conn=null;
	Statement st=null;
	ResultSet rs=null;

	@Override
	public List<Mobile> getAllMobiles() throws MobileException
	{
		List<Mobile> mlist=new ArrayList<>();
		
		try
		{


			conn=DbUtil.getConn();
			st=conn.createStatement();
			rs=st.executeQuery(QueryMapper.SELECT_ALL_MOBILES);
			while(rs.next())
			{
				Mobile m=new Mobile();
				m.setMobId(rs.getLong("mobileid"));
				m.setMobName(rs.getString("name"));
				m.setMobPrice(rs.getFloat("price"));
				m.setMobQuantity(rs.getInt("quantity"));

				mlist.add(m);
			}
		}
		catch(SQLException e)
		{
			throw new MobileException("Problem in fetching mobilelist");
		}
		return mlist;
	}

	@Override
	public Mobile getMobile(long mId) throws MobileException 
	{
		conn=DbUtil.getConn();
		Mobile m=null;
		PreparedStatement pst;
		try {
			pst = conn.prepareStatement(QueryMapper.SELECT_MOBILE);
			pst.setLong(1, mId);
			rs=pst.executeQuery();
			if(rs.next())
			{
				m=new Mobile();
				m.setMobId(rs.getLong("mobileid"));
				m.setMobName(rs.getString("name"));
				m.setMobPrice(rs.getFloat("price"));
				m.setMobQuantity(rs.getInt("quantity"));
					
			}
			else
			{
				throw new MobileException("Mobile Not found");
			}

		} 
		
		catch (SQLException e) 
		{
			throw new MobileException("Problem in fetching mobile information");
		}
		
		return m;
	}

	@Override
	public long insertPurchaseDetails(PurchaseDetails pDetails)	throws MobileException
	{
		conn=DbUtil.getConn();
		pDetails.setPurchaseId(generatePurchaseId());
		try 
		{
			PreparedStatement pst=conn.prepareStatement(QueryMapper.INSERT_QUERY);
			pst.setLong(1,pDetails.getPurchaseId());
			pst.setString(2, pDetails.getCname());
			pst.setString(3,pDetails.getcMailId());
			pst.setLong(4,pDetails.getPhoneNo());
			pst.setDate(5, Date.valueOf(pDetails.getcPurDate()));
			pst.setLong(6,pDetails.getMobileId());
			pst.executeUpdate();
		}
		catch (SQLException e) 
		{
			throw new MobileException("Problem in inserting data");
		}
		return pDetails.getPurchaseId();
	}

	@Override
	public long generatePurchaseId() throws MobileException
	{
		long pid=0;
		conn=DbUtil.getConn();
		try 
		{
			st=conn.createStatement();
			rs=st.executeQuery(QueryMapper.SELECT_SEQUENCE);
			rs.next();
			pid=rs.getLong(1);
		}
		catch (SQLException e) 
		{
			throw new MobileException("Problem in generating purchase Id");
		}
		
		return pid;
		
	}

}


