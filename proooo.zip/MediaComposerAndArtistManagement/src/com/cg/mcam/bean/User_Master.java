package com.cg.mcam.bean;

import java.sql.Date;

public class User_Master
{
	private long user_Id;
	private String user_Password;
	private long Created_by;
	private Date Created_on;
	private long Updated_by;
	private Date Updated_on;


	public long getUser_Id() 
	{
		return user_Id;
	}
	public void setUser_Id(long user_Id)
	{
		this.user_Id = user_Id;
	}
	public String getUser_Password()
	{
		return user_Password;
	}
	public void setUser_Password(String user_Password) 
	{
		this.user_Password = user_Password;
	}
	public long getCreated_by() 
	{
		return Created_by;
	}
	public void setCreated_by(long created_by) 
	{
		this.Created_by = created_by;
	}
	public Date getCreated_on() {
		return Created_on;
	}
	public void setCreated_on(Date created_on) 
	{
		this.Created_on = created_on;
	}
	public long getUpdated_by() 
	{
		return Updated_by;
	}
	public void setUpdated_by(long updated_by) 
	{
		this.Updated_by = updated_by;
	}
	public Date getUpdated_on() 
	{
		return Updated_on;
	}
	public void setUpdated_on(Date updated_on) 
	{
		this.Updated_on = updated_on;
	}
	public User_Master()
	{
		super();

	}

	public User_Master(long user_Id, String user_Password, long Created_by,
			Date Created_on, long Updated_by, Date Updated_on)
	{
		super();
		this.user_Id = user_Id;
		this.user_Password = user_Password;
		this.Created_by = Created_by;
		this.Created_on = Created_on;
		this.Updated_by = Updated_by;
		this.Updated_on = Updated_on;
	}


	@Override
	public String toString()
	{
		return "User_Master [user_Id=" + user_Id + ", user_Password="
				+ user_Password + ", Created_by=" + Created_by
				+ ", Created_on=" + Created_on + ", Updated_by=" + Updated_by
				+ ", Updated_on=" + Updated_on + "]";
	}





}
