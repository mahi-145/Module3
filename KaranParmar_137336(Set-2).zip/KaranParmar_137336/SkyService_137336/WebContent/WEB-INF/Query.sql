CREATE TABLE SKYCustomers(custNum varchar2(15) primary key, basePack varchar2(20),
optionalPack varchar2(20));

insert into SKYCustomers values('C001','Dhamal Hindi',null);

insert into SKYCustomers values('C002','South Magic',null);

insert into SKYCustomers values('C003','Dhamal Hindi','Kids');

insert into SKYCustomers values('C004','Dhamal Hindi','Music');

insert into SKYCustomers values('C005','Western Best','Music');

insert into SKYCustomers values('C006','Dhamal Hindi',null);

insert into SKYCustomers values('C007','Dhamal Hindi','Kids');

select * from SKYCustomers;

commit;