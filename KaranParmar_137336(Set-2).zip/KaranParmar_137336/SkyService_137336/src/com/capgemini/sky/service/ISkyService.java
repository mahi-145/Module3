package com.capgemini.sky.service;

import java.util.List;

import com.capgemini.sky.bean.Sky;

public interface ISkyService {
	public List<Sky> getAllData();
	public Sky getServiceDetail(String customerNumber);
	
}
