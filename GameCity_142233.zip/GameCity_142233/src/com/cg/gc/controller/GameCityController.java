package com.cg.gc.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.cg.gc.dto.Games;
import com.cg.gc.dto.User;
import com.cg.gc.exception.GameException;
import com.cg.gc.service.GameService;
import com.cg.gc.service.GameServiceImpl;



//URL PATTERN for different functionalities of the controller
@WebServlet(urlPatterns={"/GameCityController","/buy","/Success"})   
public class GameCityController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public GameCityController() 
    {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String url=request.getServletPath();
		String targetUrl="";
		GameService gameSer=new GameServiceImpl();
		HttpSession session=request.getSession(false);
		System.out.println(url);
		switch(url)
		{
		case "/buy":
				String name=request.getParameter("uname");
				String address=request.getParameter("address");
				int amount=Integer.parseInt(request.getParameter("uamount")) - 100;
				
				User user=new User();
				user.setUserName(name);
				user.setAddress(address);
				user.setCardAmount(amount);
				
				//creating the session if not created
				if(session==null)
				{
					session=request.getSession(true);
				}
				
				try
				{
					int dataAdded=0;
					dataAdded = gameSer.purchaseCard(user);
					if(dataAdded>0)
					{
						session.setAttribute("cardAmount", amount);
						List<Games> gList=gameSer.getAllGames();
						request.setAttribute("glist", gList);
						targetUrl="Play.jsp";

					}
				}
				catch(GameException e)
				{
					request.setAttribute("error", e.getMessage());
					targetUrl="Error.jsp";
				}
				
			break;
		
		case "/Success":

				int cardAmount=Integer.parseInt(request.getParameter("crdAmt"));
				Games games=new Games();
				games.setName(request.getParameter("gName"));
				games.setAmount(Integer.parseInt(request.getParameter("gAmt")));
				
				if(games.getAmount()<cardAmount)
				{
					session.setAttribute("CardAmount", cardAmount-games.getAmount());
					session.setAttribute("GameName", games.getName());
					targetUrl="Success.jsp";

				}
				else
				{
					session.setAttribute("GameName", games.getName());
					targetUrl="TopUp.jsp";
				}
				

			break;
			
		}
		//RequestDispatcher for forwarding the request to new JSP page
		RequestDispatcher rd = request.getRequestDispatcher(targetUrl);
		rd.forward(request, response);
	}

}
