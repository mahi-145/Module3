package com.cg.gc.util;

import java.sql.Connection;

import javax.naming.InitialContext;
import javax.sql.DataSource;


import com.cg.gc.exception.GameException;

public class DbUtil 
{
	public static Connection getConn() throws GameException
	{
		Connection conn = null;
		InitialContext context;
	//	conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
		try 
		{
			context=new InitialContext();
			DataSource ds=(DataSource)context.lookup("java:/JDBC/OracleDS");
			conn=ds.getConnection();
		}
		catch (Exception e) 
		{
			throw new GameException(e.getMessage());
		}
		return conn;
	}

	
}
