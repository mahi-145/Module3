package com.cg.gc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import com.cg.gc.dto.Games;
import com.cg.gc.dto.User;
import com.cg.gc.exception.GameException;
import com.cg.gc.util.DbUtil;

public class GameDaoImpl implements GameDao
{
	Connection conn=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	
	
	@Override
	public int purchaseCard(User user) throws GameException 
	{
		conn=DbUtil.getConn();
		user.setUserId(generateUserId()); 
		try 
		{
			PreparedStatement pst=conn.prepareStatement(QueryMapper.SELECT_LIST_USERS);
			pst.setInt(1, user.getUserId());
			pst.setString(2, user.getUserName());
			pst.setString(3, user.getAddress());
			pst.setInt(4, user.getCardAmount());
			pst.executeUpdate();
		}
		catch(SQLException e)
		{
			throw new GameException("Problem in inserting user to Users Table");
		}
		return  user.getUserId();

		
		
	}

	@Override
	public int generateUserId() throws GameException 
	{
		int uId=0;
		conn=DbUtil.getConn();
		try
		{
			st=conn.createStatement();
			rs=st.executeQuery(QueryMapper.USER_ID_SEQUENCE);
			rs.next();
			uId=rs.getInt(1);
			
		}
		catch (SQLException e) 
		{
			throw new GameException("Problem in generating UserId");
		}
		
		return uId;
		
	}

	@Override
	public List<Games> getAllGames() throws GameException 
	{
		List<Games> gList=new ArrayList<>();
		
		try 
		{
			conn=DbUtil.getConn();
			st=conn.createStatement();
			rs=st.executeQuery(QueryMapper.FETCH_ALL_GAMES);
			while(rs.next())
			{
				Games game=new Games();
				game.setName(rs.getString("name"));
				game.setAmount(rs.getInt("amount"));
				gList.add(game);
			}
		}
		catch(SQLException e)
		{
			throw new GameException("Problem in fetching Game List");
		}

		
		return gList;
	}
	
	
	
}
