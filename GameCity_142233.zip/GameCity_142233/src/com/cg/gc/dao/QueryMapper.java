package com.cg.gc.dao;

public interface QueryMapper
{
	String SELECT_LIST_USERS="insert INTO users VALUES(?,?,?,?)";
	String FETCH_ALL_GAMES="select * FROM onlinegames";
	String USER_ID_SEQUENCE="select seq_users.NEXTVAL from dual";
	
}
