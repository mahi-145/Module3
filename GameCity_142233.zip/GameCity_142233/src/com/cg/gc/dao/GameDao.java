package com.cg.gc.dao;

import java.util.List;

import com.cg.gc.dto.Games;
import com.cg.gc.dto.User;
import com.cg.gc.exception.GameException;

public interface GameDao 
{
	int purchaseCard(User user) throws GameException;
	public int generateUserId() throws GameException;
	List<Games> getAllGames() throws GameException;
}
