package com.cg.gc.dto;

public class Games 
{
	private String name;
	private int amount;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "Games [name=" + name + ", amount=" + amount + "]";
	}
	public Games(String name, int amount) {
		super();
		this.name = name;
		this.amount = amount;
	}
	public Games() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
