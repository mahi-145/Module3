package com.cg.gc.service;

import java.util.List;

import com.cg.gc.dto.Games;
import com.cg.gc.dto.User;
import com.cg.gc.exception.GameException;

public interface GameService
{
	int purchaseCard(User user) throws GameException;
	List<Games> getAllGames() throws GameException;

	
}
