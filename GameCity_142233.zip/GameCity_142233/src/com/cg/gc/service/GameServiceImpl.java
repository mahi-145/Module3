package com.cg.gc.service;

import java.util.List;

import com.cg.gc.dao.GameDao;
import com.cg.gc.dao.GameDaoImpl;
import com.cg.gc.dto.Games;
import com.cg.gc.dto.User;
import com.cg.gc.exception.GameException;

public class GameServiceImpl implements GameService
{	
	GameDao gDao=new GameDaoImpl();

	@Override
	public int purchaseCard(User user) throws GameException 
	{
		return gDao.purchaseCard(user);
		
	}

	@Override
	public List<Games> getAllGames() throws GameException 
	{
		return gDao.getAllGames();
	}
	
	
}
