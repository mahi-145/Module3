package com.cg.mcam.bean;

import java.sql.Date;

public class Artist_Song_Assoc 
{

	private int artist_Id;
	private int song_id;
	private int Created_by;
	private Date Created_on;
	private int Updated_by;
	private Date Updated_on;
	
	public int getArtist_Id()
	{
		return artist_Id;
	}
	public void setArtist_Id(int artist_Id)
	{
		this.artist_Id = artist_Id;
	}
	public int getSong_id() 
	{
		return song_id;
	}
	public void setSong_id(int song_id)
	{
		this.song_id = song_id;
	}
	public int getCreated_by()
	{
		return Created_by;
	}
	public void setCreated_by(int created_by)
	{
		Created_by = created_by;
	}
	public Date getCreated_on()
	{
		return Created_on;
	}
	public void setCreated_on(Date created_on) 
	{
		Created_on = created_on;
	}
	public int getUpdated_by() 
	{
		return Updated_by;
	}
	public void setUpdated_by(int updated_by)
	{
		Updated_by = updated_by;
	}
	public Date getUpdated_on() 
	{
		return Updated_on;
	}
	public void setUpdated_on(Date updated_on) 
	{
		Updated_on = updated_on;
	}
	
	public Artist_Song_Assoc() 
	{
		super();
		
	}
	
	public Artist_Song_Assoc(int artist_Id, int song_id, int created_by,
			Date created_on, int updated_by, Date updated_on) 
	{
		super();
		this.artist_Id = artist_Id;
		this.song_id = song_id;
		Created_by = created_by;
		Created_on = created_on;
		Updated_by = updated_by;
		Updated_on = updated_on;
	}
	
	@Override
	public String toString() 
	{
		return "Artist_Song_Assoc [artist_Id=" + artist_Id + ", song_id="
				+ song_id + ", Created_by=" + Created_by + ", Created_on="
				+ Created_on + ", Updated_by=" + Updated_by + ", Updated_on="
				+ Updated_on + "]";
	}
	
	
	
}
