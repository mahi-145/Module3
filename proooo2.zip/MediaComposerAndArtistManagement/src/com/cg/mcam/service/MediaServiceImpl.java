package com.cg.mcam.service;


import java.util.ArrayList;

import com.cg.mcam.bean.Artist_Master;
import com.cg.mcam.bean.Composer_Master;
import com.cg.mcam.bean.Song_Master;
import com.cg.mcam.dao.MediaDao;
import com.cg.mcam.dao.MediaDaoImpl;
import com.cg.mcam.exception.MediaException;

public class MediaServiceImpl implements MediaService

{


	MediaDao medDao=null;
    public MediaServiceImpl()
    {
    	medDao=new MediaDaoImpl();
    }
	@Override
	public int addSongs(Song_Master sm) throws MediaException 
	{
	
		return medDao.addSongs(sm);
	}
	
	@Override
	public ArrayList<Song_Master> getAllSongs() throws MediaException 
	{
		
		return medDao.getAllSongs();
	}
	
	@Override
	public int deleteSong(int id) throws MediaException {
		
		return medDao.deleteSong(id);
	}
	
	@Override
	public int addComposer(Composer_Master cm) throws MediaException 
	{
		
		return medDao.addComposer(cm);
	}
	
	@Override
	public Song_Master getSong(int song_id) throws MediaException, Exception 
	{
		Song_Master sm2=new Song_Master();
		sm2=medDao.getSong(song_id);
		return sm2;
	}
	
	@Override
	public int addArtist(Artist_Master am) throws MediaException 
	{
		
		return medDao.addArtist(am);
	}
	
	@Override
	public Composer_Master getComposer(int composer_Id) throws MediaException 
	{
		
		return medDao.getComposer(composer_Id);
	}
	
	@Override
	public Artist_Master getArtist(int artist_Id) throws MediaException 
	{
		
		return medDao.getArtist(artist_Id);
	}
	
	
	
	

}
