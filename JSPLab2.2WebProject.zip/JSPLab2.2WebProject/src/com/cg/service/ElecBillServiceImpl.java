package com.cg.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.dao.ElecBillDao;
import com.cg.dao.ElecBillDaoImpl;
import com.cg.dto.Consumers;
import com.cg.dto.ElectricityBill;
import com.cg.exception.BillException;

public class ElecBillServiceImpl implements ElecBillService
{
ElecBillDao ebDao=new ElecBillDaoImpl();
	@Override
	public List<Consumers> getAllConsumers() throws BillException 
	{
		return ebDao.getAllConsumers();
	}
	@Override
	public Consumers searchConsumer(int consid) throws BillException 
	{
		return ebDao.searchConsumer(consid);
	}
	@Override
	public int addBillDetails(ElectricityBill eBill) throws BillException 
	{
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public List<ElectricityBill> getAllBills(long consNum) throws BillException 
	{
		return ebDao.getAllBills(consNum);
	}

}
