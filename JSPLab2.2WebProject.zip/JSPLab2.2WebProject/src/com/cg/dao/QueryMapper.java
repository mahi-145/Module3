package com.cg.dao;

public interface QueryMapper {
	String SELECT_ALL_CONSUMERS="SELECT * FROM consumers";
	String SELECT_CONSUMERS="SELECT * FROM consumers WHERE consumer_num=?";
	String SELECT_SEQUENCE="SELECT seq_bill_num.NEXTVAL from DUAL";
	String INSERT_QUERY="INSERT INTO billdetails VALUES(?,?,?,?,?,?)";
	String SELECT_BILL = "select * from billdetails where consumer_num=?";
}
