package com.cg.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.dto.Consumers;
import com.cg.dto.ElectricityBill;
import com.cg.exception.BillException;
import com.cg.service.*;

@WebServlet(urlPatterns={"/BillController",",/home","/List","/search","/showBill","/userInfo"})
public class BillController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public BillController() 
    {
        super();
       
    }

	public void init(ServletConfig config) throws ServletException
	{
		
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException
	{
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		String url=request.getServletPath();
		String targetUrl="";
		ElecBillService eSer=new ElecBillServiceImpl();
		switch(url)
		{
		case "/List":
			try
			{
				List<Consumers>clist;
				clist=eSer.getAllConsumers();
				request.setAttribute("clist",clist);
				targetUrl="List.jsp";
			}
			catch(BillException e)
			{
				request.setAttribute("error",e.getMessage());
				targetUrl="Error.jsp";
			}
			break;
		case "/home":
			targetUrl="Index.html";
			break;
		case "/search":
			try
			{
				String consId=request.getParameter("cnum");
				int consid=Integer.parseInt(consId);
				Consumers consumer=eSer.searchConsumer(consid);
				HttpSession sess=request.getSession(true);
				request.setAttribute("consumer",consumer);
				targetUrl="Show_Consumer.jsp";
			}
			catch(BillException e)
			{
				request.setAttribute("error",e.getMessage());
				targetUrl="Error.jsp";
			}
			break;
		case "/showBill":
			
			try
			{
				String consNo=request.getParameter("cno");
				long consNum=Long.parseLong(consNo);
				ElectricityBill ebill=(ElectricityBill) eSer.getAllBills(consNum);
				List<ElectricityBill>blist;
				blist=eSer.getAllBills(consNum);
				request.setAttribute("blist",blist);
				targetUrl="ShowBillDetails.jsp";
			}
			catch(BillException e)
			{
				request.setAttribute("error",e.getMessage());
				targetUrl="Error.jsp";
			}
		}
		RequestDispatcher disp=request.getRequestDispatcher(targetUrl);
		disp.forward(request,response);	
	}

}
