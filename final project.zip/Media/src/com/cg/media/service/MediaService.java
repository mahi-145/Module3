package com.cg.media.service;

import java.util.ArrayList;

import com.cg.media.bean.Artist_Master;
import com.cg.media.bean.Composer_Master;
import com.cg.media.bean.Song_Master;
import com.cg.media.exception.MediaException;


public interface MediaService 
{
	public int addComposer(Composer_Master cm) throws MediaException;
	public int addArtist(Artist_Master am) throws MediaException;
	public Composer_Master getComposer(int composer_Id) throws MediaException;	
	public Artist_Master getArtist(int artist_Id) throws MediaException;
	public int addSongs(Song_Master sm) throws MediaException;
	public Song_Master getSong(int song_id) throws MediaException;
	public ArrayList<Song_Master> getAllSongs() throws MediaException;
	
	public int updateComposer(int composer_id,Composer_Master cm) throws MediaException;
	public int updateArtist(int artist_id,Artist_Master am) throws MediaException;
	
	
	
	
	
	/***************************login******************************************/

	public int getUserId() throws MediaException;
	
	public String getUserPwd() throws MediaException;
	
	public int getAdminId() throws MediaException;
	
	public String getAdminPwd() throws MediaException;
	
	public boolean  validateUserId(int user_id) throws MediaException;
	
	public boolean  validateAdminId(int  adminId) throws MediaException;
	
	public boolean  validateUserPwd(String userPwd) throws MediaException;
	
	public boolean  validateAdminPwd(String  adminPwd) throws MediaException;
}
