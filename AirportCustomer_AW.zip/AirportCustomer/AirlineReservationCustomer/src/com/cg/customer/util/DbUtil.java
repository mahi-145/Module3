package com.cg.customer.util;


import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.cg.customer.exception.CustomerException;

public class DbUtil 
{
	static String dbunm=null;
	static String dbpwd=null;
	static String url=null;

	public static Connection getConn() throws CustomerException, SQLException, IOException
	{
		Properties dbInfoProps=DbUtil.getProp(); 
		Connection conn=null;
		
		url=dbInfoProps.getProperty("dbURL");
		dbunm=dbInfoProps.getProperty("dbUser");
		dbpwd=dbInfoProps.getProperty("dbPwd");
		if(conn==null)                        
		{

			conn=DriverManager.getConnection(url,dbunm,dbpwd);

		}
		System.out.println(conn);
		return conn;


	}

	private static Properties getProp() throws IOException, CustomerException
	{
		Properties props=null;	
		FileReader fr=null;

		props=new Properties();
		fr=new FileReader("resources/dbUtil.properties");
		props.load(fr);

		return props;
	}
		
	
	
}
