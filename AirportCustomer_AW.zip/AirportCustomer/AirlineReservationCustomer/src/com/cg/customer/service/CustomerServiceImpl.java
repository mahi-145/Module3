package com.cg.customer.service;

import com.cg.customer.bean.BookingInformation;
import com.cg.customer.dao.CustomerDao;
import com.cg.customer.dao.CustomerDaoImpl;
import com.cg.customer.exception.CustomerException;

public class CustomerServiceImpl implements CustomerService 
{

	CustomerDao custDao=null;
	
	public CustomerServiceImpl()
	{
		custDao=new CustomerDaoImpl();
	}
	
	@Override
	public int bookTicket(BookingInformation bookInfo) throws CustomerException 
	{
		return custDao.bookTicket(bookInfo);
	}

	@Override
	public int generateBookingId() throws CustomerException 
	{
		return custDao.generateBookingId();
	}

}
