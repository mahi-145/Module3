package com.cg.customer.service;

import com.cg.customer.bean.BookingInformation;
import com.cg.customer.exception.CustomerException;

public interface CustomerService
{
	public int bookTicket(BookingInformation bookInfo) throws CustomerException;
	public int generateBookingId() throws CustomerException;

	
	
}
