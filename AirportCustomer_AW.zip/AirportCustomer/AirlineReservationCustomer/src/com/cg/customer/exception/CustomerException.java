package com.cg.customer.exception;

public class CustomerException extends Exception
{

	public CustomerException(String msg)
	{
		super(msg);
	}

	
	
	
}
