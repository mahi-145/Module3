package com.cg.customer.dao;

import com.cg.customer.bean.BookingInformation;
import com.cg.customer.exception.CustomerException;

public interface CustomerDao
{
	public int bookTicket(BookingInformation bookInfo) throws CustomerException;
	public int generateBookingId() throws CustomerException;
	
}
