package com.cg.customer.dao;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.cg.customer.bean.BookingInformation;
import com.cg.customer.exception.CustomerException;
import com.cg.customer.util.DbUtil;

public class CustomerDaoImpl implements CustomerDao
{
	
	Connection conn=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	

	@Override
	public int bookTicket(BookingInformation bookInfo) throws CustomerException 
	{
		String insertqry="Insert into bookinginformation(booking_id, cust_email, no_of_passengers, class_type, total_fare, creditcard_info, src_city, dest_city) values(?,?,?,?,?,?,?,?)";
	//	int dataAdded=0;
		int id=0;

		try
		{
			conn=DbUtil.getConn();
			pst=conn.prepareStatement(insertqry);
			id = generateBookingId();
			pst.setInt(1, id);
			pst.setString(2, bookInfo.getCustEmail());
			System.out.println(bookInfo.getCustEmail());
			pst.setInt(3, bookInfo.getNoOfPassengers());
			pst.setString(4, bookInfo.getClassType());
			pst.setFloat(5,  bookInfo.getFare());
			pst.setString(6, bookInfo.getCreditCard());
			pst.setString(7, bookInfo.getSource());
			pst.setString(8, bookInfo.getDestination());
			System.out.println(bookInfo.getCustEmail());
			
			
			pst.executeUpdate();
	
		}
		catch (Exception e) 
		{
			throw new CustomerException(e.getMessage());
		}
		finally
		{
			try
			{
				pst.close();
				conn.close();
				
			}
			catch(Exception e)
			{
				throw new CustomerException(e.getMessage());
			}
		}

		
		return id;
	}

	@Override
	public int generateBookingId() throws CustomerException
	{
		String query="select bookingid.NEXTVAL from dual";
		int generatedId=0;
		
		try
		{
			conn=DbUtil.getConn();
			st=conn.createStatement();
			rs=st.executeQuery(query);

			rs.next();
			generatedId=rs.getInt(1);
		}
		catch(Exception e)
		{
			throw new CustomerException(e.getMessage());
		}
		finally
		{
			try
			{
				rs.close();
				st.close();
				conn.close();
			}
			catch(Exception e)
			{
				throw new CustomerException(e.getMessage());
			}
		}
		
		return generatedId;
	}
	
	
	
}
