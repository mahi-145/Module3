package com.cg.lims.service;

import java.util.ArrayList;

import com.cg.lims.Exception.RegistrationException;
import com.cg.lims.bean.BookTransaction;
import com.cg.lims.bean.BooksInventory;
import com.cg.lims.bean.BooksRegistration;
import com.cg.lims.dao.RegistrationDao;
import com.cg.lims.dao.RegistrationDaoImpl;

public class RegistrationServiceImpl implements RegistrationService
{
	RegistrationDao regDao=null;
	public RegistrationServiceImpl()
	{
		regDao=new RegistrationDaoImpl();
	}

	@Override
	public int addRegistrationDetails(BooksRegistration register)
			throws RegistrationException, Exception 
	{		
		return regDao.addRegistrationDetails(register);
	}

	@Override
	public boolean validateIds(String userId,String BookId) throws RegistrationException 
	{
		int flag=0;
		if(validateBookId(BookId))
		{
			if(validateUserId(userId))
			{
				flag=1;
			}
		}
		if(flag==1)
		{
			return true;
		}
		else
		{
			return false;
		}
		
	}
	private boolean validateUserId(String userId) throws RegistrationException
	{
		ArrayList<String> userIds=regDao.getUserId();
		int flag=0;
		for(String tempuserIds :userIds)
		{
		if(userId.equals(tempuserIds))
		{
			flag=1;
		}
		}
		if(flag==1)
		{
			return true;
		}
		else
		{
			throw new RegistrationException("Invalid User Id. Please check it");
		}
	}
	private boolean validateBookId(String BookId) throws RegistrationException
	{
		ArrayList<String> bookIds=regDao.getUserId();
		int flag=0;
		for(String tempbookIds :bookIds)
		{
		if(BookId.equals(tempbookIds))
		{
			flag=1;
		}
		}
		if(flag==1)
		{
			return true;
		}
		else
		{
			throw new RegistrationException("Invalid Book Id. Please check it");
		}
	}

	@Override
	public String generateRegistId() throws RegistrationException, Exception
	{		
		return regDao.generateRegistId();
	}

	@Override
	public int addBookInventory(BooksInventory bookInv)
			throws RegistrationException {
		return regDao.addBookInventory(bookInv);
	}

	@Override
	public int deleteBook(String bId) throws RegistrationException, Exception 
	{
		return regDao.deleteBook(bId);
	}

	@Override
	public int issueBook(BookTransaction register)
			throws RegistrationException, Exception {
		
		return regDao.issueBook(register);
	}
	
	public boolean validateRegId(String RegId) throws RegistrationException
	{
		ArrayList<String> RegIds=regDao.getRegId();
		int flag=0;
		for(String tempbookIds :RegIds)
		{
		if(RegId.equals(tempbookIds))
		{
			flag=1;
		}
		}
		if(flag==1)
		{
			return true;
		}
		else
		{
			throw new RegistrationException("Invalid Book Id. Please check it");
		}
	}


	



	


}
