package com.cg.lims.dao;


import java.sql.*;
import java.util.ArrayList;

import com.cg.lims.Exception.UserException;
import com.cg.lims.util.DBUtil;

public class UserDaoImpl implements UserDao
{
	Connection con=null;
	Statement st=null;
	ResultSet rs=null;
	PreparedStatement pst=null;

	@Override
	public ArrayList<String> getUserName() throws UserException,Exception
	{
		ArrayList<String> userNames=new ArrayList<String>();
		try
		{
		con=DBUtil.getCon();
		String selectQry="SELECT user_name FROM users";
		st=con.createStatement();
		rs=st.executeQuery(selectQry);
		while(rs.next())
		{
			String userName=rs.getString("user_name");
			userNames.add(userName);
		}
		}
		catch(Exception e)
		{
			throw new UserException(e.getMessage());
		}
		return userNames;
	}

	@Override
	public ArrayList<String> getUserPwd() throws Exception, UserException 
	{
		ArrayList<String> userPwds=new ArrayList<String>();
		try
		{
		con=DBUtil.getCon();
		String selectQry="SELECT password FROM users";
		st=con.createStatement();
		rs=st.executeQuery(selectQry);
		while(rs.next())
		{
			String userPwd=rs.getString("password");
			userPwds.add(userPwd);
		}
		}
		catch(Exception e)
		{
			 throw new UserException(e.getMessage());
		}
		return userPwds;
	
	}

	@Override
	public String getLibrarianValueByUserName(String userName)throws UserException 
	{
		String librarian=null;
		try
		{
		con=DBUtil.getCon();
		String selectQry="SELECT librarian FROM users WHERE user_name=?";
		pst=con.prepareStatement(selectQry);
		pst.setString(1, userName);
		rs=pst.executeQuery();
		rs.next();
		librarian=rs.getString("librarian");
		}
		catch(Exception e)
		{
			 throw new UserException(e.getMessage());
		}
		return librarian;
	}

}
